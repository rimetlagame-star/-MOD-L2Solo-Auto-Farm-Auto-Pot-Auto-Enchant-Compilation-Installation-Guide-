﻿# L2Solo – Auto Farm, Auto Pot & Auto Enchant

Custom mod compilation and installer for **L2Solo**, adding **Auto Farm**, **Auto Pot** (`.autopot`), and **Auto Enchant** (`.autoenchant`) via `L2Solo-Meus-Mods`, `INSTALAR_MODS.cmd`, and `instalar_mods.ps1`.

## How to Install
1. Make a **full backup** of your L2Solo server folder and saves/database before making any changes.
2. Copy the package files into your target server root folder (alongside `src`).
3. Run `INSTALAR_MODS.cmd` and follow the console output.
4. Start the server via the L2Solo Launcher and test in-game using a test character.

## Warnings & Risks
- Mods alter server scripts and gameplay mechanics; **startup/console errors**, **script conflicts**, or **unexpected in-game behavior** can happen depending on your server version or local edits.
- Keep backup copies (`.bak_*` created during local testing) outside the repository so nothing is lost or corrupted.
- Always test on a backup/test copy before applying to your main environment.
