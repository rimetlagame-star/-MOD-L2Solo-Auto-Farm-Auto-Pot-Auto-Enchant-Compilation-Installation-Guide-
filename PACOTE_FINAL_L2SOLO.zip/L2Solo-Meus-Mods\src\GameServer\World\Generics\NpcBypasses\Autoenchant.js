'use strict';

module.exports = function autoEnchantBypass(session, parts) {
    const AutoEnchant = invoke('GameServer/World/Generics/AutoEnchant');
    if (!AutoEnchant || typeof AutoEnchant.handleBypass !== 'function') return false;
    return AutoEnchant.handleBypass(session, parts);
};
