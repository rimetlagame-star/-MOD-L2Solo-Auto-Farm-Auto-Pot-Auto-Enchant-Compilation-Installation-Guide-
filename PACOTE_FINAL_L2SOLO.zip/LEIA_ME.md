# PACOTE FINAL - L2SOLO (.autofarm, .autopot, .autoenchant)

Tudo o que e necessario para testar, restaurar ou compartilhar esta dentro desta pasta.

## Como instalar ou testar
1. Copie **o conteudo** desta pasta (`L2Solo-Meus-Mods`, `INSTALAR_MODS.cmd` e `instalar_mods.ps1`) para a pasta raiz do servidor `L2Solo` (onde fica a pasta `src`).
2. De **dois cliques em `INSTALAR_MODS.cmd`**.
3. Reinicie o servidor e teste `.autofarm`, `.autopot` e `.autoenchant` no jogo.