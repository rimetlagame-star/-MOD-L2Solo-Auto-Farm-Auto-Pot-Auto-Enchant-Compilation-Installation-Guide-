'use strict';

function notifyModStep(session, stage, message) {
    try {
        const text = `[${stage}] ${message}`;
        if (session && !session.closed && typeof session.dataSendToMe === 'function') {
            const Res = invoke('GameServer/Network/Response');
            if (Res && typeof Res.creatureSay === 'function') {
                session.dataSendToMe(Res.creatureSay(0, 15, 'Mod', text));
            } else if (Res && typeof Res.systemMessage === 'function') {
                session.dataSendToMe(Res.systemMessage(text));
            }
        }
        console.info('ModStep :: %s', text);
    } catch (_) {}
}
const ItemTemplateIndex = require('../../Item/ItemTemplateIndex');
const DataCache = invoke('GameServer/DataCache');
const ServerResponse = invoke('GameServer/Network/Response');
const Enchant = invoke('GameServer/Enchant');
const EnchantRules = invoke('GameServer/Items/C4EnchantRules');

const TICK_MS = 350;
const TARGET_LEVELS = [4, 6, 8, 10, 12, 15, 16, 20];
const SCROLL_TYPES = ['normal', 'blessed', 'crystal'];
const TABS = [
    { key: 'weapon', label: 'Armas' },
    { key: 'armor', label: 'Armaduras' },
    { key: 'accessory', label: 'Joias' }
];
const sessions = new Map();

function charKey(session) {
    return String(session?.actor?.fetchId?.() || session?.accountId || '');
}

function itemTemplate(selfId) {
    return ItemTemplateIndex.findLast(DataCache.items, Number(selfId), itemTemplate)
        || ItemTemplateIndex.find(DataCache.items, Number(selfId))
        || null;
}

function itemName(item) {
    const tpl = itemTemplate(item?.fetchSelfId?.() ?? item?.selfId);
    return tpl?.template?.name || item?.model?.name || `Item #${item?.fetchSelfId?.() ?? item?.selfId ?? 0}`;
}

function itemIcon(item) {
    const tpl = itemTemplate(item?.fetchSelfId?.() ?? item?.selfId);
    const rawIcon = tpl?.template?.icon || tpl?.etc?.icon || item?.model?.icon || '';
    const clean = String(rawIcon || '').trim();
    if (!clean) return '';
    return clean.includes('.') ? clean : `icon.${clean}`;
}

function getEnchantableItems(session) {
    const items = session?.actor?.backpack?.fetchItems?.() || [];
    return items.filter((item) => {
        const cat = EnchantRules.categoryOf(item);
        const rank = EnchantRules.gradeOf(item);
        if (!cat || !rank || rank === 'NONE') return false;
        const fakeScroll = { grade: rank, target: cat === 'weapon' ? 'weapon' : 'armor' };
        return EnchantRules.validTarget(item, fakeScroll);
    });
}

function findMatchingScroll(session, targetItem, scrollType) {
    const items = session?.actor?.backpack?.fetchItems?.() || [];
    const grade = EnchantRules.gradeOf(targetItem);
    const wantedTarget = EnchantRules.categoryOf(targetItem) === 'weapon' ? 'weapon' : 'armor';

    for (const item of items) {
        const rule = EnchantRules.resolveScroll(item?.fetchSelfId?.() ?? item?.selfId);
        if (!rule) continue;
        if (String(rule.grade).toUpperCase() !== grade) continue;
        if (rule.target !== wantedTarget) continue;
        if (rule.scrollType !== scrollType) continue;
        if (Number(item.fetchAmount?.() ?? item.amount ?? 0) < 1) continue;
        return { item, rule };
    }
    return null;
}

function getConfig() {
    return EnchantRules.configWith(globalThis.options?.default?.Enchant || {});
}

function getSessionState(session) {
    const key = charKey(session);
    const candidates = getEnchantableItems(session);
    let state = sessions.get(key);

    if (!state) {
        const equippedWeapon = candidates.find((it) => it.fetchEquipped?.() && EnchantRules.categoryOf(it) === 'weapon');
        const defaultItem = equippedWeapon || candidates[0] || null;
        state = {
            selectedObjectId: defaultItem ? Number(defaultItem.fetchId()) : 0,
            activeTab: defaultItem ? (EnchantRules.categoryOf(defaultItem) || 'weapon') : 'weapon',
            targetLevel: 6,
            scrollType: 'normal',
            running: false,
            status: 'Pronto. Escolha arma, armadura ou joia.',
            attempts: 0,
            successes: 0,
            timer: null
        };
        sessions.set(key, state);
    }

    const stillExists = candidates.some((it) => Number(it.fetchId()) === Number(state.selectedObjectId));
    if (!stillExists) {
        state.selectedObjectId = candidates[0] ? Number(candidates[0].fetchId()) : 0;
    }
    return state;
}

function stopLoop(state, message) {
    if (state.timer) {
        clearTimeout(state.timer);
        state.timer = null;
    }
    state.running = false;
    if (message) state.status = message;
}

function escapeHtml(text) {
    return String(text || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function renderHtml(session) {
    const state = getSessionState(session);
    const candidates = getEnchantableItems(session);
    const currentItem = candidates.find((it) => Number(it.fetchId()) === Number(state.selectedObjectId)) || null;
    const config = getConfig();

    let itemLabel = 'Nenhum item selecionado';
    let currentIcon = '';
    let scrollLabel = '-';
    let scrollCount = 0;
    let chanceText = '-';

    if (currentItem) {
        const lvl = EnchantRules.enchantLevelOf(currentItem);
        const grade = EnchantRules.gradeOf(currentItem);
        const cat = EnchantRules.categoryOf(currentItem);
        const eqTag = currentItem.fetchEquipped?.() ? '[EQ] ' : '';
        itemLabel = `${eqTag}${itemName(currentItem)} (+${lvl}) [${grade}]`;
        currentIcon = itemIcon(currentItem);

        const foundScroll = findMatchingScroll(session, currentItem, state.scrollType);
        scrollCount = foundScroll ? Number(foundScroll.item.fetchAmount?.() ?? foundScroll.item.amount ?? 0) : 0;
        const expectedScrollName = state.scrollType === 'blessed'
            ? `Blessed Enchant (${grade})`
            : state.scrollType === 'crystal'
                ? `Crystal Enchant (${grade})`
                : `Scroll Enchant (${grade})`;
        scrollLabel = foundScroll ? itemName(foundScroll.item) : expectedScrollName;

        const chance = EnchantRules.isSafe(currentItem, lvl, config)
            ? 100
            : EnchantRules.chanceFor(cat, state.scrollType, config);
        chanceText = `${chance}% (Safe: ${cat === 'armor' && Number(currentItem.fetchSlot?.() || 0) === 15 ? config.safeMaxFull : config.safeMax})`;
    }

    const tabCells = TABS.map((t) => {
        const active = state.activeTab === t.key;
        const lbl = active ? `[${t.label}]` : t.label;
        return `<td><button value="${lbl}" action="bypass -h autoenchant tab ${t.key}" width=74 height=20 back="sek.cbui94" fore="sek.cbui92"></td>`;
    }).join('');

    const tabItems = candidates.filter((it) => EnchantRules.categoryOf(it) === state.activeTab).slice(0, 8);
    const listRows = tabItems.length
        ? tabItems.map((it) => {
            const oid = Number(it.fetchId());
            const selected = oid === Number(state.selectedObjectId);
            const lvl = EnchantRules.enchantLevelOf(it);
            const grade = EnchantRules.gradeOf(it);
            const eq = it.fetchEquipped?.() ? '*' : '';
            const shortName = itemName(it).slice(0, 22);
            const ico = itemIcon(it);
            const iconHtml = ico ? `<img src="${escapeHtml(ico)}" width=16 height=16> ` : '';
            const btnLabel = selected ? '[OK]' : 'Usar';
            return `<tr><td width=178>${iconHtml}<font color="${selected ? 'LEVEL' : 'FFFFFF'}">${eq}${escapeHtml(shortName)} (+${lvl}) [${grade}]</font></td><td width=46><button value="${btnLabel}" action="bypass -h autoenchant select ${oid}" width=44 height=18 back="sek.cbui94" fore="sek.cbui92"></td></tr>`;
        }).join('')
        : `<tr><td width=224><font color="888888">Sem itens desta categoria na bag.</font></td></tr>`;

    const levelCells = TARGET_LEVELS.map((lvl) => {
        const active = Number(state.targetLevel) === lvl;
        const label = active ? `[+${lvl}]` : `+${lvl}`;
        return `<td><button value="${label}" action="bypass -h autoenchant target ${lvl}" width=54 height=20 back="sek.cbui94" fore="sek.cbui92"></td>`;
    });

    const modeCells = SCROLL_TYPES.map((mode) => {
        const active = state.scrollType === mode;
        const title = mode === 'normal'
            ? (active ? '[Normal]' : 'Normal')
            : mode === 'blessed'
                ? (active ? '[Blessed]' : 'Blessed')
                : (active ? '[Crystal]' : 'Crystal');
        return `<td><button value="${title}" action="bypass -h autoenchant mode ${mode}" width=74 height=20 back="sek.cbui94" fore="sek.cbui92"></td>`;
    }).join('');

    const actionRow = state.running
        ? `<td><button value="PARAR" action="bypass -h autoenchant stop" width=224 height=24 back="sek.cbui94" fore="sek.cbui92"></td>`
        : `<td><button value="INICIAR" action="bypass -h autoenchant start" width=148 height=24 back="sek.cbui94" fore="sek.cbui92"></td><td><button value="Atualizar" action="bypass -h autoenchant open" width=74 height=24 back="sek.cbui94" fore="sek.cbui92"></td>`;

    const selectedHeaderIcon = currentIcon
        ? `<img src="${escapeHtml(currentIcon)}" width=32 height=32><br1>`
        : '';

    return `<html><title>Auto Enchant - L2Solo</title><body><center>
<font color="LEVEL">AUTO ENCHANT - L2SOLO</font><br1>
${selectedHeaderIcon}<font color="FFFFFF">${escapeHtml(itemLabel)}</font><br1>
<font color="B0B0B0">Scroll: </font><font color="99CCFF">${escapeHtml(scrollLabel)}</font> (<font color="LEVEL">${scrollCount}</font>)<br1>
<font color="B0B0B0">Chance: </font><font color="A8E6CF">${escapeHtml(chanceText)}</font><br>
<table width=224 cellpadding=1 cellspacing=1><tr>${tabCells}</tr></table>
<table width=224 cellpadding=1 cellspacing=1>${listRows}</table><br1>
<font color="LEVEL">Nivel Alvo:</font><br1>
<table width=224 cellpadding=1 cellspacing=1>
<tr>${levelCells.slice(0, 4).join('')}</tr>
<tr>${levelCells.slice(4, 8).join('')}</tr>
</table><br1>
<font color="LEVEL">Tipo de Scroll:</font><br1>
<table width=224 cellpadding=1 cellspacing=1><tr>${modeCells}</tr></table><br1>
<table width=224 cellpadding=1 cellspacing=1><tr>${actionRow}</tr></table><br1>
<font color="B0B0B0">Status: </font><font color="FFD700">${escapeHtml(state.status)}</font><br1>
<font color="888888">Tentativas: ${state.attempts} | Sucessos: ${state.successes}</font>
</center></body></html>`;
}

function sendPanel(session) {
    if (!session?.dataSendToMe) return;
    session.dataSendToMe(ServerResponse.npcHtml(0, renderHtml(session)));
}

function selectTargetFromScroll(session, objectId, scrollRule) {
    const state = getSessionState(session);
    const candidates = getEnchantableItems(session);
    const target = candidates.find((it) => Number(it.fetchId()) === Number(objectId));
    if (!target) return;
    state.selectedObjectId = Number(target.fetchId());
    state.activeTab = EnchantRules.categoryOf(target) || state.activeTab;
    if (scrollRule?.scrollType && SCROLL_TYPES.includes(scrollRule.scrollType)) {
        state.scrollType = scrollRule.scrollType;
    }
    state.status = `Selecionado: ${itemName(target)} (+${EnchantRules.enchantLevelOf(target)})`;
    sendPanel(session);
}

async function stepEnchant(session) {
    const state = getSessionState(session);
    if (!state.running) return;

    const actor = session?.actor;
    if (!actor || actor.isDead?.() || actor.fetchIsOnline?.() === false) {
        stopLoop(state, 'Parado: personagem indisponivel ou morto.');
        sendPanel(session);
        return;
    }

    if (Number(actor.fetchPrivateStoreType?.() || 0) !== 0 || actor.state?.fetchCasts?.() || actor.state?.fetchHits?.()) {
        state.timer = setTimeout(() => stepEnchant(session).catch(() => {}), TICK_MS);
        return;
    }

    const candidates = getEnchantableItems(session);
    const targetItem = candidates.find((it) => Number(it.fetchId()) === Number(state.selectedObjectId)) || null;
    if (!targetItem) {
        stopLoop(state, 'Parado: item alvo nao encontrado ou quebrou.');
        sendPanel(session);
        return;
    }

    const currentLevel = EnchantRules.enchantLevelOf(targetItem);
    if (currentLevel >= Number(state.targetLevel)) {
        stopLoop(state, `Concluido! Item chegou a +${currentLevel}.`);
        sendPanel(session);
        return;
    }

    const foundScroll = findMatchingScroll(session, targetItem, state.scrollType);
    if (!foundScroll) {
        stopLoop(state, `Parado: sem scrolls ${state.scrollType} do grade ${EnchantRules.gradeOf(targetItem)}.`);
        sendPanel(session);
        return;
    }

    session.activeEnchantItem = {
        itemId: foundScroll.item.fetchId(),
        selfId: foundScroll.item.fetchSelfId()
    };

    state.attempts += 1;
    const outcome = await Enchant.enchant(session, targetItem.fetchId(), {
        config: getConfig()
    });

    if (!outcome?.ok) {
        stopLoop(state, `Parado: falha ao encantar (${outcome?.result || 'erro'}).`);
        sendPanel(session);
        return;
    }

    if (outcome.result === 'success') {
        state.successes += 1;
        state.status = `Sucesso! +${currentLevel} -> +${outcome.enchant}`;
    } else if (outcome.result === 'blessed-fail') {
        state.status = `Blessed falhou: +${currentLevel} -> +0`;
    } else {
        stopLoop(state, `Item quebrou em +${currentLevel} (cristais: ${outcome.crystalAmount || 0}).`);
        sendPanel(session);
        return;
    }

    const updatedLevel = EnchantRules.enchantLevelOf(targetItem);
    if (updatedLevel >= Number(state.targetLevel)) {
        stopLoop(state, `Alvo +${state.targetLevel} atingido!`);
        sendPanel(session);
        return;
    }

    sendPanel(session);
    state.timer = setTimeout(() => stepEnchant(session).catch(() => {}), TICK_MS);
}

function startAutoEnchant(session) {
    const state = getSessionState(session);
    const candidates = getEnchantableItems(session);
    const targetItem = candidates.find((it) => Number(it.fetchId()) === Number(state.selectedObjectId)) || null;

    if (!targetItem) {
        state.status = 'Selecione um item encantavel valido.';
        sendPanel(session);
        return;
    }
    const lvl = EnchantRules.enchantLevelOf(targetItem);
    if (lvl >= Number(state.targetLevel)) {
        state.status = `Item ja esta em +${lvl} (alvo +${state.targetLevel}).`;
        sendPanel(session);
        return;
    }

    stopLoop(state);
    state.running = true;
    state.attempts = 0;
    state.successes = 0;
    state.status = `Iniciando +${lvl} -> +${state.targetLevel}...`;
    sendPanel(session);
    state.timer = setTimeout(() => stepEnchant(session).catch(() => {}), TICK_MS);
}

function handleBypass(session, rawBypass = '') {
    const parts = Array.isArray(rawBypass)
        ? rawBypass.map((x) => String(x)).filter(Boolean)
        : String(rawBypass || '').trim().split(/\s+/).filter(Boolean);
    const cmd = (parts[0] || '').toLowerCase();
    if (cmd !== 'autoenchant') return false;

    const sub = (parts[1] || 'open').toLowerCase();
    const state = getSessionState(session);

    if (sub === 'open') {
        sendPanel(session);
        return true;
    }
    if (sub === 'tab') {
        const t = (parts[2] || '').toLowerCase();
        if (TABS.some((x) => x.key === t)) {
            state.activeTab = t;
            state.status = `Aba: ${TABS.find((x) => x.key === t).label}.`;
        }
        sendPanel(session);
        return true;
    }
    if (sub === 'select') {
        const oid = Number(parts[2]);
        const candidates = getEnchantableItems(session);
        const found = candidates.find((it) => Number(it.fetchId()) === oid);
        if (found) {
            state.selectedObjectId = Number(found.fetchId());
            state.activeTab = EnchantRules.categoryOf(found) || state.activeTab;
            state.status = `Alvo: ${itemName(found)} (+${EnchantRules.enchantLevelOf(found)})`;
        }
        sendPanel(session);
        return true;
    }
    if (sub === 'target') {
        const parsed = Number(parts[2]);
        if (Number.isFinite(parsed) && parsed >= 1 && parsed <= 127) {
            state.targetLevel = Math.floor(parsed);
            state.status = `Nivel alvo: +${state.targetLevel}.`;
        }
        sendPanel(session);
        return true;
    }
    if (sub === 'mode') {
        const mode = (parts[2] || '').toLowerCase();
        if (SCROLL_TYPES.includes(mode)) {
            state.scrollType = mode;
            state.status = `Scroll: ${mode}.`;
        }
        sendPanel(session);
        return true;
    }
    if (sub === 'start') {
        startAutoEnchant(session);
        return true;
    }
    if (sub === 'stop') {
        stopLoop(state, 'Parado pelo jogador.');
        sendPanel(session);
        return true;
    }

    sendPanel(session);
    return true;
}

function handleCommand(session, text = '') {
    const raw = String(text || '').trim();
    if (!raw.toLowerCase().startsWith('.autoenchant')) return false;

    const args = raw.slice('.autoenchant'.length).trim().split(/\s+/).filter(Boolean);
    const state = getSessionState(session);

    if (args[0] && ['stop', 'parar'].includes(args[0].toLowerCase())) {
        stopLoop(state, 'Parado via comando.');
        sendPanel(session);
        return true;
    }
    if (args[0] && /^\+?\d+$/.test(args[0])) {
        const lvl = Number(args[0].replace(/^\+/, ''));
        if (lvl >= 1 && lvl <= 127) {
            state.targetLevel = lvl;
            startAutoEnchant(session);
            return true;
        }
    }

    sendPanel(session);
    return true;
}

module.exports = {
    handleCommand,
    handleBypass,
    selectTargetFromScroll,
    sendPanel
};
