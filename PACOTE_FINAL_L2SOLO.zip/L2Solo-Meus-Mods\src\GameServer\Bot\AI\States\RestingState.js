const Speech = invoke('GameServer/Bot/AI/BotSpeechTemplates');
const ServerResponse = invoke('GameServer/Network/Response');
const SpeckMath      = invoke('GameServer/SpeckMath');
const BotRoles       = invoke('GameServer/Bot/AI/BotRoles');
const BotClassPolicy = invoke('GameServer/Bot/AI/BotClassPolicy');
const RestPolicy     = invoke('GameServer/Bot/AI/RestPolicy');
const RestPotion     = invoke('GameServer/Bot/AI/RestPotion');
const PartyAwareness = invoke('GameServer/Bot/AI/PartyAwareness');
const PartyCompanionService = invoke('GameServer/Bot/AI/PartyCompanionService');
const PartyPulling = invoke('GameServer/Bot/AI/PartyPulling');
const EffectStore    = invoke('GameServer/Effects/EffectStore');
const BotRetreatPlanner = invoke('GameServer/Bot/AI/BotRetreatPlanner');
const BotRaidSafety = invoke('GameServer/Bot/AI/BotRaidSafety');
const DangerMoment = invoke('GameServer/Bot/AI/DangerMoment');
const EscapePolicy = invoke('GameServer/Bot/AI/BotEscapePolicy');
const SummonerTactics = invoke('GameServer/Bot/AI/SummonerTactics');
const BotPersona = invoke('GameServer/Bot/AI/BotPersona');

const REST_FOLLOW_WAKE_DISTANCE = 600;
const { EMERGENCY_RETREAT_DISTANCE } = invoke('GameServer/Bot/AI/DangerRule');
const MANA_REGEN_CAST_RETRY_MS = 8000;
const PARTY_REST_FORMATION_TOLERANCE = 45;

function point(actor) {
    return new SpeckMath.Point3D(actor.fetchLocX(), actor.fetchLocY(), actor.fetchLocZ());
}

function distanceToPartyFormation(session, bot, player) {
    const target = PartyCompanionService.formationTargetFor(session) || {
        locX: player.fetchLocX(),
        locY: player.fetchLocY()
    };
    const dx = bot.fetchLocX() - target.locX;
    const dy = bot.fetchLocY() - target.locY;
    return Math.sqrt((dx * dx) + (dy * dy));
}

function standUp(session, bot) {
    if (!bot.state.fetchSeated()) return false;
    bot.state.setSeated(false);
    session.dataSendToOthers(ServerResponse.sitAndStand(bot), bot);
    return true;
}

function recordWakeDecision(session, bot, action, reason, extra = {}) {
    session.roleDecision = {
        role: BotRoles.inferRole(bot),
        action,
        reason,
        at: Date.now(),
        ...extra
    };
}

function sitDown(session, bot) {
    if (bot.state.fetchSeated()) return false;
    bot.state.setSeated(true);
    session.dataSendToOthers(ServerResponse.sitAndStand(bot), bot);
    return true;
}

// The rest's posture (RestPolicy.sitsToRest): seated unless
// standing refills what the bot lacks faster (a Sorcerer's Clear Mind).
function restsSeated(session, bot) {
    const automation = bot.automation;
    if (typeof automation?.fetchRevMpAmount !== 'function') return true;
    const tick = (options) => ({ hp: automation.fetchRevHpAmount(bot, options), mp: automation.fetchRevMpAmount(bot, options) });
    return RestPolicy.sitsToRest(tick({ seated: true }), tick({ standing: true }),
        bot.fetchMaxHp() - bot.fetchHp(), bot.fetchMaxMp() - bot.fetchMp(), waitsForMana(session, bot));
}

// The party state is the fight mode's (BotClassPolicy.modeFor): a player's
// companion, a bot party with a member beside it.
function inParty(session, bot) {
    return BotClassPolicy.modeFor(bot, { session }) !== 'solo_pve';
}

// Does this rest last until MP is back (RestPolicy.restWaitsForMana)?
function waitsForMana(session, bot) {
    return RestPolicy.restWaitsForMana(bot, inParty(session, bot));
}

// Is the rest over (RestPolicy.restOver, the cold rest's rule): at the bot's
// rested line, or whole for a rest its next fight sent it to when it was
// already rested (session.restWhole, HuntingState.beginVoluntaryRecovery).
function rested(session, bot) {
    const party = inParty(session, bot);
    return RestPolicy.restOver({ hp: bot.fetchHp(), maxHp: bot.fetchMaxHp(), mp: bot.fetchMp(), maxMp: bot.fetchMaxMp() },
        { mana: RestPolicy.restWaitsForMana(bot, party), party, persona: BotPersona.of(session),
            whole: !party && session.restWhole === true, pet: SummonerTactics.petRestView(bot) });
}

function maybeCastManaRegeneration(session, bot, Generics) {
    const mpRatio = bot.fetchMp() / Math.max(1, bot.fetchMaxMp());
    if (mpRatio >= 0.8 || Date.now() < Number(session.nextManaRegenAt || 0)) return false;

    const skill = (bot.skillset?.fetchSkills?.() || [])
        .find((entry) => !entry.fetchPassive?.()
            && entry.fetchSemantic?.()?.effect === 'mana_regeneration'
            && entry.fetchTargetKind?.() === 'self');
    if (!skill || EffectStore.remainingMs(bot, 'mana_regeneration') > 0) return false;
    if (Number(bot.fetchMp()) < Number(skill.fetchConsumedMp?.() || 0) || bot.state.fetchCasts?.()) return false;

    standUp(session, bot);
    session.nextManaRegenAt = Date.now() + MANA_REGEN_CAST_RETRY_MS;
    Generics.skillExec(session, bot, { id: bot.fetchId(), selfId: skill.fetchSelfId(), ctrl: false });
    recordWakeDecision(session, bot, 'cast_mana_regeneration', 'recover_mp', { skillId: skill.fetchSelfId() });
    return true;
}

function needsRecovery(session, bot) {
    return RestPolicy.needsRetreat(bot,
        bot.fetchHp() / Math.max(1, bot.fetchMaxHp()),
        bot.fetchMp() / Math.max(1, bot.fetchMaxMp()),
        { locked: !!session.recoveryLocked, pet: SummonerTactics.petRestView(bot) });
}

function retreatFromThreat(session, bot, threat) {
    standUp(session, bot);
    session.plan = 'fleeing';
    session.recoveryLocked = true;
    session.fleeStart = Date.now();
    session.currentTargetId = undefined;
    session.incomingThreatId = undefined;
    session.incomingThreatAt = undefined;
    bot.unselect?.();
    BotRetreatPlanner.retreat(session, bot, threat, { distance: EMERGENCY_RETREAT_DISTANCE });
    recordWakeDecision(session, bot, 'retreat', 'critical_resources_under_attack', {
        targetId: threat.fetchId(),
        hpRatio: bot.fetchHp() / Math.max(1, bot.fetchMaxHp()),
        mpRatio: bot.fetchMp() / Math.max(1, bot.fetchMaxMp())
    });
}

module.exports = {
    maybeCastManaRegeneration,
    rested,
    tick(session, bot, Generics, BotAI) {
        invoke('GameServer/AfkTrade/TradeMeetingService').breakChanged(session, 1);
        if (session.followPlayerSession && session.partyCompanion === true) {
            const playerSession = session.followPlayerSession;
            const player = playerSession?.actor;

            if (!player || !player.fetchIsOnline()) {
                session.plan = 'hunting';
                session.roleDecision = null;
                BotAI.say(session, "Meu companheiro desconectou. Voltando a caçar.");
                return;
            }

            const distance = point(bot).distance(point(player));
            if (invoke('GameServer/Bot/AI/PlayerPartyRaid').tick(session, bot, Generics, BotAI)) return;
            const partyRaid = BotRaidSafety.syncPlayerPartyRaid(playerSession);
            if (partyRaid?.phase === 'opening') {
                delete session.explicitRestOrder;
                session.plan = 'following';
                session.currentTargetId = undefined;
                standUp(session, bot);
                recordWakeDecision(session, bot, 'prepare_raid', 'player_designated_raid_target', {
                    targetId: partyRaid.bossId,
                    openerId: partyRaid.openerId || null
                });
                return;
            }
            const threat = PartyAwareness.findThreatTargetingPartyProjected(playerSession);
            if (threat?.type === 'raid' && BotRaidSafety.retreat(session, bot, threat.actor, { distance: EMERGENCY_RETREAT_DISTANCE })) {
                recordWakeDecision(session, bot, 'retreat', 'raid_entity_protected', {
                    targetId: threat.actor.fetchId?.() || null
                });
                return;
            }
            const partySettings = PartyCompanionService.getSettings(playerSession);
            const leaderTargetId = PartyAwareness.leaderCombatTargetId(playerSession);
            PartyPulling.observeLeaderTarget(playerSession, partySettings, leaderTargetId);
            const pulling = PartyPulling.current(playerSession, partySettings);
            const heldPullTargetId = pulling.target && !pulling.engageable
                ? pulling.target.fetchId()
                : null;
            const threatIsHeldPull = Number(threat?.actor?.fetchId?.()) === Number(heldPullTargetId);
            const leaderTargetIsHeldPull = Number(leaderTargetId) === Number(heldPullTargetId);
            const combatTargetId = !threatIsHeldPull && threat?.actor?.fetchId?.()
                ? threat.actor.fetchId()
                : (!leaderTargetIsHeldPull ? leaderTargetId : undefined);
            const leaderSeated = player.state?.fetchSeated?.() === true;
            const recovered = rested(session, bot);

            // When the whole party rests, regroup first. FollowingState checks
            // the seated leader before its low-resource branch, so the bot
            // moves into formation and then sits there without oscillating.
            // A companion resting alone still finishes recovery in place.
            const shouldRegroupForPartyRest = !session.explicitRestOrder &&
                leaderSeated &&
                distance > 250 &&
                distanceToPartyFormation(session, bot, player) > PARTY_REST_FORMATION_TOLERANCE;
            const shouldFollowLeader = shouldRegroupForPartyRest || (recovered && (
                distance > REST_FOLLOW_WAKE_DISTANCE || !leaderSeated
            ));
            if (combatTargetId || shouldFollowLeader) {
                delete session.explicitRestOrder;
                session.plan = 'following';
                session.currentTargetId = combatTargetId || undefined;
                session.townGossip = false;
                standUp(session, bot);
                recordWakeDecision(
                    session,
                    bot,
                    combatTargetId ? 'assist_party' : 'follow_leader',
                    (threat && !threatIsHeldPull)
                        ? 'party_under_attack'
                        : (combatTargetId ? 'leader_target' : (distance > REST_FOLLOW_WAKE_DISTANCE ? 'leader_moved' : 'leader_stood_ready')),
                    threat && !threatIsHeldPull
                        ? { targetId: session.currentTargetId, protectedId: threat.targetId }
                        : { targetId: session.currentTargetId || null, distance: Math.round(distance) }
                );
                return;
            }
        }

        if (!session.followPlayerSession && session.partyCompanion !== true) {
            const threatScan = {};
            const threat = PartyAwareness.npcThreateningActor(session, undefined, threatScan);
            if (threat) {
                if (BotRaidSafety.retreat(session, bot, threat, { distance: EMERGENCY_RETREAT_DISTANCE })) {
                    recordWakeDecision(session, bot, 'retreat', 'raid_entity_protected', {
                        targetId: threat.fetchId?.() || null
                    });
                    return;
                }
                // attacked while resting takes the danger moment of a fight
                // (drink, fight back or flee); without one, the author's rule.
                const moment = DangerMoment.take(session, bot, threat, { near: threatScan.near });
                if (moment === 'drank') return;
                if ((moment ? moment === 'flee' : needsRecovery(session, bot))
                    && EscapePolicy.canRetreatFrom(session, bot, threat, threatScan.near)) {
                    retreatFromThreat(session, bot, threat);
                    return;
                }
                session.plan = 'hunting';
                session.currentTargetId = threat.fetchId();
                session.townGossip = false;
                standUp(session, bot);
                bot.select({ id: threat.fetchId() });
                recordWakeDecision(session, bot, 'defend_self', 'incoming_threat', {
                    targetId: threat.fetchId()
                });
                BotAI.executeCombat(session, bot, threat, Generics);
                return;
            }
        }

        if (session.townGossip) {
            // 3% chance per tick to attempt conversation when resting near other bots
            if (Math.random() < 0.03) {
                try {
                    const BotManager = invoke('GameServer/Bot/BotManager');
                    BotManager.checkAndStartConversation(session);
                } catch (err) {
                    console.error("Totalmente descansado! Pronto para te seguir de novo.", err);
                }
            }
            return; // Stay seated and do nothing else
        }

        const restingWithLeader = session.partyCompanion === true
            && session.followPlayerSession?.actor?.state?.fetchSeated?.() === true;
        if (rested(session, bot) && !restingWithLeader) {
            session.recoveryLocked = false;
            session.restWhole = false;
            delete session.explicitRestOrder;
            bot.state.setSeated(false);
            session.dataSendToOthers(ServerResponse.sitAndStand(bot), bot);
            // The rest's end is the body's stop: what waited for it wakes (Situations).
            invoke('GameServer/Bot/AI/DecisionEvents').stop(session);
            if (session.followPlayerSession && session.partyCompanion === true) {
                session.plan = 'following';
                BotAI.say(session, "Fully rested! Ready to follow you again.");
            } else {
                session.plan = 'hunting';
                BotAI.say(session, Speech.line('combat.rested'), { ambient: true, key: 'rested' });
            }
        } else {
            // skillExec marks the actor as casting immediately.  Do not sit
            // on the next brain tick while the native self-cast is still live.
            if (bot.state.fetchHits?.() || bot.state.fetchCasts?.()) return;
            // Alone, a bottle may shorten the rest (RestPotion); it stays seated.
            if (BotClassPolicy.modeFor(bot, { session }) === 'solo_pve'
                && RestPotion.tryBetweenFights(session, bot, () => SummonerTactics.petRestView(bot))) return;
            if (maybeCastManaRegeneration(session, bot, Generics)) return;
            if (restsSeated(session, bot)) sitDown(session, bot);
            else standUp(session, bot);
            // 3% chance per tick to attempt conversation when resting near other bots
            if (Math.random() < 0.03) {
                try {
                    const BotManager = invoke('GameServer/Bot/BotManager');
                    BotManager.checkAndStartConversation(session);
                } catch (err) {
                    console.error("Conversation check error:", err);
                }
            }
        }
    }
};
