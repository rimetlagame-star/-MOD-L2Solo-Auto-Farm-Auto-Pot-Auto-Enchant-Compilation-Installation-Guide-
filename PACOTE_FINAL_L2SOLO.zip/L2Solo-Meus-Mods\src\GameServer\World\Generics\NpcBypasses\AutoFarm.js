'use strict';
﻿
function notifyModStep(session, stage, message) {
    try {
        const text = `[${stage}] ${message}`;
        if (session && !session.closed && typeof session.dataSendToMe === 'function') {
            const Res = invoke('GameServer/Network/Response');
            if (Res && typeof Res.creatureSay === 'function') {
                session.dataSendToMe(Res.creatureSay(0, 15, 'Mod', text));
            } else if (Res && typeof Res.systemMessage === 'function') {
                session.dataSendToMe(Res.systemMessage(text));
            }
        }
        console.info('ModStep :: %s', text);
    } catch (_) {}
}
'use strict';

const DEFAULT_RANGE            = 1000;
const MIN_RANGE                = 100;
const MAX_RANGE                = 5000;
const FARM_SLOTS               = [0, 1, 2, 3];               // Priority: Slots 1, 2, 3 and 4 (F1-F4)
const FALLBACK_BAR_SLOTS       = [4, 5, 6, 7, 8, 9, 10, 11]; // Fallback when F1-F4 are empty
const DEBUFF_COOLDOWN_MS       = 20000;                      // Fallback (20s) when duration is not specified
const BASIC_ATTACK_EVERY_TICKS = 2;                          // Basic attack every N skills for melee/archer only

const KNOWN_DEBUFF_SKILL_IDS = new Set([
    116,  // Howl
    122,  // Hex
    127,  // Hamstring
    139,  // Guts / debuff variants
    271,  // Dance of Shadows
    352,  // Armor Crush
    402,  // Arrest
    412,  // Sand Cloud
    1064, // Sleep
    1069, // Sleep (NPC/mob)
    1071, // Touch of Death / debuff
    1074, // Rain of Fire
    1083, // Cursed Chaos
    1092, // Fear
    1097, // Dreaming Spirit
    1147, // Vampiric Touch
    1164, // Curse Weakness
    1169, // Curse Fear
    1170, // Anchor (Paralisia)
    1201, // Dryad Root (Root/Hold)
    1206, // Wind Shackle
    1222, // Curse Gloom
    1223, // Surrender To Wind
    1224, // Surrender To Earth
    1263, // Curse Discord
    1269, // Curse Disease
    1336, // Curse of Doom
    1358, // Block Wind Walk
    1359, // Block Shield
    1366, // Sway
    1394, // Trance
    1396  // Magical Backfire
]);

const DEBUFF_KEYWORDS = [
    'curse', 'debuff', 'paraly', 'anchor', 'root', 'hold', 'shackle',
    'slow', 'hex', 'stun', 'sleep', 'fear', 'bleed', 'poison', 'doom',
    'weakness', 'gloom', 'discord', 'disease', 'trance', 'arrest', 'stigma'
];

const ACTION_NAMES = Object.freeze({
    0: 'Sit/Stand',
    1: 'Walk/Run',
    2: 'Attack',
    3: 'Exchange',
    4: 'Next Target',
    5: 'Pick Up',
    6: 'Assist',
    10: 'Private Store Sell',
    12: 'Social: Greeting',
    13: 'Social: Victory',
    14: 'Social: Advance',
    15: 'Social: No',
    16: 'Social: Yes',
    17: 'Social: Bow',
    18: 'Social: Unaware',
    19: 'Social: Social Waiting',
    20: 'Social: Laugh',
    21: 'Social: Applause',
    22: 'Social: Dance',
    23: 'Social: Sorrow',
    24: 'Social: Charm',
    25: 'Social: Shyness',
    28: 'Private Store Buy',
    37: 'Dwarven Manufacture',
    51: 'General Manufacture'
});

function ensureState(session) {
    if (!session._autoFarm) {
        session._autoFarm = {
            enabled: false,
            attackEnabled: true,
            range: DEFAULT_RANGE,
            visionRange: DEFAULT_RANGE,
            anchor: null,
            slotCursor: 0,
            skillStreak: 0,
            lastTargetId: 0,
            appliedDebuffs: new Map()
        };
    } else if (!(session._autoFarm.appliedDebuffs instanceof Map)) {
        session._autoFarm.appliedDebuffs = new Map();
    }
    if (typeof session._autoFarm.pullOnly !== 'boolean') {
        session._autoFarm.pullOnly = false;
    }
    if (typeof session._autoFarm.attackEnabled !== 'boolean') {
        session._autoFarm.attackEnabled = true;
    }
    if (typeof session._autoFarm.visionRange !== 'number' || !Number.isFinite(session._autoFarm.visionRange)) {
        session._autoFarm.visionRange = clampRange(session._autoFarm.range ?? DEFAULT_RANGE);
    } else {
        session._autoFarm.visionRange = clampRange(session._autoFarm.visionRange);
    }
    if (!session._autoFarm.anchor || typeof session._autoFarm.anchor !== 'object') {
        session._autoFarm.anchor = null;
    }
    if (typeof session._autoFarm.skillStreak !== 'number') {
        session._autoFarm.skillStreak = 0;
    }
    return session._autoFarm;
}

function getSessionShortcuts(session) {
    if (Array.isArray(session?._shortcuts)) return session._shortcuts;
    if (Array.isArray(session?.shortcuts)) return session.shortcuts;
    if (Array.isArray(session?.actor?.shortcuts)) return session.actor.shortcuts;
    const id = Number(session?.actor?.fetchId?.() || 0);
    if (id && !session?._scLoading) {
        session._scLoading = true;
        Promise.resolve(invoke('Database')?._fetchShortcuts ? null : invoke('Database')?.fetchShortcuts?.(id))
            .then(r => { if (Array.isArray(r) && session) session._shortcuts = r.slice(); })
            .catch(() => {})
            .finally(() => { if (session) session._scLoading = false; });
    }
    return [];
}

function getActiveFarmSlotEntries(session) {
    const shortcuts = getSessionShortcuts(session);
    const primary = FARM_SLOTS
        .map((idx) => shortcuts.find((s) => Number(s?.slot ?? s?.index) === idx))
        .filter(Boolean);

    if (primary.length > 0) {
        return { entries: primary, usingFallback: false };
    }

    const fallback = FALLBACK_BAR_SLOTS
        .map((idx) => shortcuts.find((s) => Number(s?.slot ?? s?.index) === idx))
        .filter((sc) => {
            if (!sc) return false;
            const kind = Number(sc.kind ?? sc.type);
            const id = Number(sc.id ?? sc.itemId ?? sc.shortcutId);
            if (!(kind === 2 && id > 0)) return false;
            const skill = session?.actor?.skillset?.fetchSkill?.(id);
            const targetType = String(skill?.fetchTargetType?.() ?? skill?.targetType ?? '').toLowerCase();
            return targetType !== 'self' && targetType !== 'none';
        });

    return { entries: fallback, usingFallback: fallback.length > 0 };
}

function getActorCoords(actor) {
    try {
        if (!actor) return null;
        const m = actor.model;
        const st = actor.state;
        const x = Number(
            m?.locX ??
            actor.fetchLocX?.() ??
            st?.fetchX?.() ??
            actor.fetchX?.() ??
            actor.x ??
            NaN
        );
        const y = Number(
            m?.locY ??
            actor.fetchLocY?.() ??
            st?.fetchY?.() ??
            actor.fetchY?.() ??
            actor.y ??
            NaN
        );
        const z = Number(
            m?.locZ ??
            actor.fetchLocZ?.() ??
            st?.fetchZ?.() ??
            actor.fetchZ?.() ??
            actor.z ??
            0
        );
        if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
        return { x, y, z: Number.isFinite(z) ? z : 0 };
    } catch (_) {
        return null;
    }
}

function setAnchorFromActor(state, actor) {
    const coords = getActorCoords(actor);
    if (coords) {
        state.anchor = coords;
    }
    return state.anchor;
}

function distPoint2D(x1, y1, x2, y2) {
    const dx = Number(x1) - Number(x2);
    const dy = Number(y1) - Number(y2);
    if (!Number.isFinite(dx) || !Number.isFinite(dy)) return Infinity;
    return Math.hypot(dx, dy);
}

function getEntityCoords(entity) {
    const x = Number(entity?.state?.fetchX?.() ?? entity?.x ?? entity?.fetchX?.() ?? NaN);
    const y = Number(entity?.state?.fetchY?.() ?? entity?.y ?? entity?.fetchY?.() ?? NaN);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
    return { x, y };
}

function clampRange(value) {
    const num = Math.round(Number(value));
    if (!Number.isFinite(num)) return DEFAULT_RANGE;
    return Math.max(MIN_RANGE, Math.min(MAX_RANGE, num));
}

function getEntityId(entity) {
    return Number(entity?.fetchId?.() ?? entity?.id ?? entity?.objectId ?? 0);
}

function isMageActor(actor, slotEntries = []) {
    if (!actor) return false;

    if (actor.isMage?.() === true || actor.fetchIsMage?.() === true || actor.template?.isMage === true) {
        return true;
    }

    const className = String(
        actor.fetchClassName?.() ??
        actor.className ??
        actor.template?.className ??
        actor.profession?.name ??
        ''
    ).toLowerCase();

    const mageKeywords = [
        'mystic', 'wizard', 'sorcer', 'necromancer', 'warlock',
        'spellsinger', 'elemental', 'spellhowler', 'phantom',
        'cleric', 'bishop', 'prophet', 'elder', 'shaman', 'overlord', 'warcryer',
        'archmage', 'soultaker', 'arcana', 'mystic muse', 'storm screamer',
        'spectral master', 'cardinal', 'hierophant', 'eva', 'shillien', 'dominator', 'doomcryer'
    ];
    for (const kw of mageKeywords) {
        if (className.includes(kw)) return true;
    }

    for (const sc of slotEntries) {
        const kind = Number(sc?.kind ?? sc?.type);
        const id = Number(sc?.id ?? sc?.itemId ?? sc?.shortcutId);
        if (kind === 2 && id > 0) {
            const skill = actor.skillset?.fetchSkill?.(id);
            if (skill?.isMagic?.() === true || skill?.fetchIsMagic?.() === true || skill?.magic === true) {
                return true;
            }
            if (id >= 1000 && id < 4000) {
                return true;
            }
        }
    }

    return false;
}

function isDebuffOrParalysisSkill(actor, skillId) {
    const id = Number(skillId);
    if (!Number.isFinite(id) || id <= 0) return false;
    if (KNOWN_DEBUFF_SKILL_IDS.has(id)) return true;

    const skill = actor?.skillset?.fetchSkill?.(id);
    if (!skill) return false;

    const name = String(skill.fetchName?.() ?? skill.name ?? '').toLowerCase();
    const kind = String(skill.fetchKind?.() ?? skill.fetchType?.() ?? skill.kind ?? skill.type ?? '').toLowerCase();
    const isDebuffFlag = Boolean(
        skill.isDebuff?.() ||
        skill.fetchIsDebuff?.() ||
        skill.isParalyze?.() ||
        skill.fetchIsParalyze?.() ||
        skill.debuff
    );

    if (isDebuffFlag) return true;
    if (kind.includes('debuff') || kind.includes('paraly') || kind.includes('curse') || kind.includes('root')) {
        return true;
    }

    for (const kw of DEBUFF_KEYWORDS) {
        if (name.includes(kw)) return true;
    }

    return false;
}

function getTargetActiveEffects(target, now) {
    const list = [];
    if (!target) return list;

    try {
        const EffectStore = invoke('GameServer/Effects/EffectStore');
        if (typeof EffectStore?.prune === 'function') {
            EffectStore.prune(target);
        }
        if (typeof EffectStore?.list === 'function') {
            const stored = EffectStore.list(target);
            if (Array.isArray(stored)) {
                for (const eff of stored) {
                    if (!eff) continue;
                    const exp = Number(eff.expiresAt ?? 0);
                    if (exp > 0 && exp <= now) continue;
                    list.push(eff);
                }
            }
        }
    } catch (_) {}

    if (target.effects && typeof target.effects === 'object') {
        for (const eff of Object.values(target.effects)) {
            if (!eff) continue;
            const exp = Number(eff.expiresAt ?? 0);
            if (exp > 0 && exp <= now) continue;
            list.push(eff);
        }
    }

    return list;
}

function isDebuffPresentOnTarget(target, skillId, now) {
    const targetId = getEntityId(target);
    if (!targetId || !target) return false;

    const effects = getTargetActiveEffects(target, now);
    for (const eff of effects) {
        const effId = Number(eff.id ?? eff.skillId ?? eff.selfId ?? 0);
        if (effId > 0 && effId === Number(skillId)) {
            return true;
        }
        const effType = String(eff.type || '').toLowerCase();
        const effName = String(eff.name || eff.key || '').toLowerCase();
        if (effType === 'debuff' && effName && DEBUFF_KEYWORDS.some((kw) => effName.includes(kw))) {
            if (KNOWN_DEBUFF_SKILL_IDS.has(Number(skillId)) && KNOWN_DEBUFF_SKILL_IDS.has(effId)) {
                return true;
            }
        }
    }

    return false;
}

function cleanupDebuffTracker(state, currentTarget, now) {
    const currentTargetId = getEntityId(currentTarget) || 0;
    if (currentTargetId && state.lastTargetId && currentTargetId !== state.lastTargetId) {
        state.appliedDebuffs.clear();
    }
    state.lastTargetId = currentTargetId;

    for (const [key, entry] of state.appliedDebuffs.entries()) {
        const ts = typeof entry === 'object' ? Number(entry?.ts || 0) : Number(entry || 0);
        const expiresAt = typeof entry === 'object' ? Number(entry?.expiresAt || 0) : 0;
        const skillId = typeof entry === 'object' ? Number(entry?.skillId || 0) : 0;

        const expiredByTime = expiresAt > 0 ? now >= expiresAt : (now - ts) >= DEBUFF_COOLDOWN_MS;
        const stillInEffectStore = currentTarget && skillId > 0 ? isDebuffPresentOnTarget(currentTarget, skillId, now) : false;

        if (!stillInEffectStore && expiredByTime) {
            state.appliedDebuffs.delete(key);
        }
    }
}

function isDebuffAlreadyActiveOnTarget(state, target, skillId, now) {
    const targetId = getEntityId(target);
    if (!targetId) return false;

    if (isDebuffPresentOnTarget(target, skillId, now)) {
        return true;
    }

    const key = `${targetId}:${skillId}`;
    const entry = state.appliedDebuffs.get(key);
    if (!entry) return false;

    const ts = typeof entry === 'object' ? Number(entry?.ts || 0) : Number(entry || 0);
    const expiresAt = typeof entry === 'object' ? Number(entry?.expiresAt || 0) : 0;
    if (expiresAt > 0) {
        if (now < expiresAt) return true;
        state.appliedDebuffs.delete(key);
        return false;
    }

    if ((now - ts) < DEBUFF_COOLDOWN_MS) {
        return true;
    }

    state.appliedDebuffs.delete(key);
    return false;
}

function markDebuffAppliedOnTarget(actor, state, target, skillId, now) {
    const targetId = getEntityId(target);
    if (!targetId) return;

    const skill = actor?.skillset?.fetchSkill?.(skillId);
    const durationMs = Number(
        skill?.durationMs ??
        skill?.duration ??
        skill?.abnormalTime ??
        skill?.fetchDuration?.() ??
        0
    );
    const expiresAt = durationMs > 0 ? now + durationMs : now + DEBUFF_COOLDOWN_MS;

    state.appliedDebuffs.set(`${targetId}:${skillId}`, {
        skillId: Number(skillId),
        ts: now,
        expiresAt
    });
}

function isSkillOnCooldown(actor, skillId, now) {
    const skill = actor?.skillset?.fetchSkill?.(skillId);
    if (!skill) return false;
    const reuseEnd = Number(skill.reuseEndTime ?? skill.cooldownEnd ?? skill.nextUseTime ?? 0);
    if (reuseEnd > now) return true;
    if (typeof skill.isInReuse === 'function' && skill.isInReuse(now)) return true;
    if (typeof skill.fetchCooldownRemaining === 'function' && skill.fetchCooldownRemaining() > 0) return true;
    return false;
}

function selectTarget(actor, target, actionId = 0) {
    const targetId = getEntityId(target);
    if (!targetId) return;

    if (typeof actor.select === 'function') {
        actor.select({
            id: targetId,
            locX: actor.fetchLocX?.() || 0,
            locY: actor.fetchLocY?.() || 0,
            locZ: actor.fetchLocZ?.() || 0,
            actionId,
            ctrl: false
        });
    } else if (typeof actor.setTarget === 'function') {
        actor.setTarget(target);
    }
}

function performBasicAttack(actor, target = null) {
    if (!actor) return false;

    const targetId = getEntityId(target) || Number(actor.fetchDestId?.() || actor.targetId || 0);
    let triggered = false;

    if (typeof actor.basicAction === 'function') {
        actor.basicAction({
            actionId: 2,
            ctrl: 0,
            shift: 0
        });
        triggered = true;
    }

    if (targetId && typeof actor.select === 'function') {
        selectTarget(actor, target || { id: targetId }, 2);
        triggered = true;
    } else if (!triggered && typeof actor.attack === 'function' && target) {
        actor.attack(target);
        triggered = true;
    }

    return triggered;
}

function getSlotSummary(session) {
    const shortcuts = getSessionShortcuts(session);
    const actor = session?.actor;
    const { usingFallback } = getActiveFarmSlotEntries(session);
    const lines = [];

    for (const slotIdx of FARM_SLOTS) {
        const sc = shortcuts.find((s) => Number(s?.slot ?? s?.index) === slotIdx);
        const displaySlot = slotIdx + 1;
        if (!sc) {
            lines.push(`Slot ${displaySlot} (F${displaySlot}): <font color="888888">Vazio</font>`);
            continue;
        }
        const kind = Number(sc.kind ?? sc.type);
        const id = Number(sc.id ?? sc.itemId ?? sc.shortcutId);
        if (kind === 2) {
            const skill = actor?.skillset?.fetchSkill?.(id);
            const name = skill?.fetchName?.() || `Skill #${id}`;
            const tag = isDebuffOrParalysisSkill(actor, id) ? ' <font color="FF9966">[Debuff]</font>' : '';
            lines.push(`Slot ${displaySlot} (F${displaySlot}): <font color="66CCFF">${name}</font>${tag}`);
        } else if (kind === 3) {
            const label = ACTION_NAMES[id] || `Action #${id}`;
            lines.push(`Slot ${displaySlot} (F${displaySlot}): <font color="FFCC66">${label}</font>`);
        } else if (kind === 1) {
            lines.push(`Slot ${displaySlot} (F${displaySlot}): <font color="99FF99">Item #${id}</font>`);
        } else {
            lines.push(`Slot ${displaySlot} (F${displaySlot}): Tipo ${kind} (#${id})`);
        }
    }

    if (usingFallback) {
        lines.push('<font color="99FF99">(Usando skills da barra 5-12 como fallback)</font>');
    }
    return lines.join('<br1>');
}

function btn(label, action, width = 62, height = 24) {
    return `<button value="${label}" action="bypass -h ${action}" width=${width} height=${height} back="sek.cbui94" fore="sek.cbui92">`;
}

function render(session) {
    if (!session?.actor || session.closed) return;
    try {
        const ServerResponse = invoke('GameServer/Network/Response');
        const state = ensureState(session);
        const statusText = state.enabled
            ? '<font color="33FF66">LIGADO</font>'
            : '<font color="FF5555">DESLIGADO</font>';

        const visionRange  = clampRange(state.visionRange ?? state.range ?? DEFAULT_RANGE);
        const toggleLabel  = state.enabled ? '[ DESLIGAR AUTO-FARM ]' : '[ LIGAR AUTO-FARM ]';
        const toggleCmd    = state.enabled ? 'off' : 'on';
        const attackText   = state.attackEnabled
            ? '<font color="33FF66">ATACAR AO PEGAR TARGET (LIGADO)</font>'
            : '<font color="FF5555">SO TARGET - NAO ATACA (DESLIGADO)</font>';
        const attackCmd    = state.attackEnabled ? 'attack off' : 'attack on';
        const anchorText   = state.anchor
            ? `<font color="33FF66">FIXADA (${Math.round(state.anchor.x)}, ${Math.round(state.anchor.y)})</font>`
            : '<font color="FF5555">NAO FIXADA</font>';

        const pullOnly      = state.pullOnly === true;
        const pullText      = pullOnly
            ? '<font color="33FF66">ASSIST PULL (LIGADO)</font>'
            : '<font color="FF5555">ASSIST PULL (DESLIGADO)</font>';
        const assistPullRow = `Assist pull:<br1><b>${pullText}</b><br1><a action="bypass -h auto-farm pull">[ Alternar Assist Pull ]</a><br><br>`;
        const html = [
            '<html><title>Auto-Farm</title><body>',
            '<center>',
            '<font color="LEVEL">=== CONTROLE AUTO-FARM ===</font><br>',
            `Status: <b>${statusText}</b><br1>`,
            `<a action="bypass -h auto-farm ${toggleCmd}">${toggleLabel}</a><br><br>`,
            `Acao ao mirar: <b>${attackText}</b><br1>`,
            `<a action="bypass -h auto-farm ${attackCmd}">[ Alternar Atacar / So Target ]</a><br><br>`,
            `${assistPullRow}`,
            `Raio da regiao: <font color="LEVEL">${state.range}</font><br1>`,
            `Raio de visao: <font color="66CCFF">${visionRange}</font><br1>`,
            `<a action="bypass -h auto-farm visionstep -200">[ -200 Visao ]</a>   <a action="bypass -h auto-farm visionstep 200">[ +200 Visao ]</a><br1>`,
            `Regiao: <b>${anchorText}</b><br1>`,
            state.anchor
                ? '<a action="bypass -h auto-farm anchor">[ Fixar Regiao Aqui ]</a>   <a action="bypass -h auto-farm unanchor">[ Desfixar Regiao ]</a><br><br>'
                : '<a action="bypass -h auto-farm anchor">[ Fixar Regiao Aqui ]</a><br><br>',
            '<font color="LEVEL">--- Ajustar Range ---</font><br1>',
            '<table width=256 cellpadding=2 cellspacing=2>',
            '<tr>',
            `<td align="center">${btn('-200', 'auto-farm step -200', 60, 24)}</td>`,
            `<td align="center">${btn('600', 'auto-farm range 600', 60, 24)}</td>`,
            `<td align="center">${btn('1200', 'auto-farm range 1200', 60, 24)}</td>`,
            `<td align="center">${btn('+200', 'auto-farm step 200', 60, 24)}</td>`,
            '</tr>',
            '<tr>',
            `<td align="center">${btn('1500', 'auto-farm range 1500', 60, 24)}</td>`,
            `<td align="center">${btn('2000', 'auto-farm range 2000', 60, 24)}</td>`,
            `<td align="center">${btn('2500', 'auto-farm range 2500', 60, 24)}</td>`,
            `<td align="center">${btn('3500', 'auto-farm range 3500', 60, 24)}</td>`,
            '</tr>',
            '</table><br>',
            'Range exato (100 a 5000):<br1>',
            '<table cellpadding=2 cellspacing=2><tr>',
            '<td><edit var="rng" width=100 height=16 length="4"></td>',
            `<td align="center">${btn('Aplicar', 'auto-farm set $rng', 80, 24)}</td>`,
            '</tr></table><br>',
            '<font color="LEVEL">--- Barra 1 (F1 a F4) ---</font><br1>',
            getSlotSummary(session),
            '<br><br>',
            '<table cellpadding=2 cellspacing=2><tr>',
            `<td align="center">${btn('Atualizar Lista', 'auto-farm open', 140, 24)}</td>`,
            '</tr></table>',
            '</center>',
            '</body></html>'
        ].join('');

        session.dataSendToMe(ServerResponse.npcHtml(session.actor.fetchId(), html));
    } catch (_) {}
}

function handleBypass(session, parts) {
    if (!session?.actor || session.closed) return;
    try {
        const state = ensureState(session);
        const sub = String(Array.isArray(parts) ? (parts[1] || 'open') : 'open').toLowerCase();

        if (sub === 'on') {
            state.enabled = true;
            state.slotCursor = 0;
            state.skillStreak = 0;
            state.appliedDebuffs.clear();
            setAnchorFromActor(state, session.actor);
            try {
                const isSitting = Boolean(session.actor?.state?.fetchSit?.() ?? session.actor?.isSitting?.());
                if (isSitting && typeof session.actor?.basicAction === 'function') {
                    session.actor.basicAction({ actionId: 0, ctrl: 0, shift: 0 });
                }
            } catch (_) {}
        } else if (sub === 'off') {
            state.enabled = false;
        } else if (sub === 'attack') {
            const mode = String(parts?.[2] || '').toLowerCase();
            if (mode === 'on' || mode === 'true' || mode === '1') state.attackEnabled = true;
            else if (mode === 'off' || mode === 'false' || mode === '0') state.attackEnabled = false;
            else state.attackEnabled = !state.attackEnabled;
        } else if (sub === 'pull' || sub === 'pullonly') {
            const mode = String(parts?.[2] || '').toLowerCase();
            if (mode === 'on' || mode === 'true' || mode === '1') state.pullOnly = true;
            else if (mode === 'off' || mode === 'of' || mode === 'false' || mode === '0') state.pullOnly = false;
            else state.pullOnly = !state.pullOnly;
        } else if (sub === 'anchor') {
            setAnchorFromActor(state, session.actor);
        } else if (sub === 'unanchor' || sub === 'clearanchor') {
            state.anchor = null;
        } else if (sub === 'range' || sub === 'set') {
            if (parts?.[2] !== undefined && String(parts[2]).trim() !== '') {
                state.range = clampRange(parts[2]);
            }
        } else if (sub === 'step') {
            const delta = Number(parts?.[2] || 0);
            if (Number.isFinite(delta)) {
                state.range = clampRange(state.range + delta);
            }
        } else if (sub === 'vision' || sub === 'visionset') {
            if (parts?.[2] !== undefined && String(parts[2]).trim() !== '') {
                state.visionRange = clampRange(parts[2]);
            }
        } else if (sub === 'visionstep') {
            const delta = Number(parts?.[2] || 0);
            if (Number.isFinite(delta)) {
                state.visionRange = clampRange((state.visionRange ?? state.range) + delta);
            }
        }

        render(session);
    } catch (_) {}
}

function isPlayerOrFriendly(actor, candidate) {
    if (!candidate || candidate === actor) return false;
    if (candidate.fetchIsPlayer?.() === true || candidate.isPlayer?.() === true) return true;
    if (candidate.fetchAccountId?.() || candidate.accountId) return true;
    return false;
}

function isValidMonster(actor, candidate) {
    if (!candidate || candidate === actor) return false;
    if (isPlayerOrFriendly(actor, candidate)) return false;
    if (candidate.isDead?.() === true || candidate.state?.fetchDead?.() === true) return false;

    const hp = Number(candidate.fetchHp?.() ?? candidate.hp ?? 1);
    if (hp <= 0) return false;

    const attackable = candidate.fetchAttackable?.() ?? candidate.isAttackable?.();
    if (attackable === false) return false;

    return true;
}

function dist2D(a, b) {
    const ax = Number(a.fetchLocX?.() ?? a.locX ?? 0);
    const ay = Number(a.fetchLocY?.() ?? a.locY ?? 0);
    const bx = Number(b.fetchLocX?.() ?? b.locX ?? 0);
    const by = Number(b.fetchLocY?.() ?? b.locY ?? 0);
    const dx = ax - bx;
    const dy = ay - by;
    return Math.sqrt(dx * dx + dy * dy);
}

function pushItems(out, src, depth = 0) {
    if (!src || depth > 2) return;
    if (Array.isArray(src)) {
        for (const item of src) out.push(item);
        return;
    }
    if (src instanceof Map || src instanceof Set || typeof src.values === 'function') {
        for (const item of src.values()) out.push(item);
        return;
    }
    if (typeof src === 'object') {
        for (const key of Object.keys(src)) {
            const val = src[key];
            if (val && typeof val === 'object') {
                if (typeof val.fetchId === 'function' || typeof val.fetchLocX === 'function' || val.actor) {
                    out.push(val);
                } else if (depth < 2) {
                    pushItems(out, val, depth + 1);
                }
            }
        }
    }
}

function collectWorldCandidates(actor, World) {
    const list = [];
    pushItems(list, actor?.knownList);
    pushItems(list, actor?.knownActors);
    pushItems(list, actor?.visibleActors);
    pushItems(list, actor?.region?.npcs);
    pushItems(list, actor?.region?.actors);
    pushItems(list, World?.npc);
    pushItems(list, World?.npcs);
    pushItems(list, World?.mob);
    pushItems(list, World?.mobs);
    pushItems(list, World?.actors);
    pushItems(list, World?.regions);
    pushItems(list, World?.world);
    return list;
}

function resolveActivePullTarget(session, World) {
    try {
        const PartyPulling = invoke('GameServer/Bot/AI/PartyPulling');
        const CompanionSvc = invoke('GameServer/Bot/AI/PartyCompanionService');
        const candidateSessions = [];
        const addSession = (s) => {
            if (s && !candidateSessions.includes(s)) candidateSessions.push(s);
        };
        addSession(session);
        addSession(session?.followPlayerSession);
        addSession(session?.partyLeaderSession);
        addSession(session?.clanCommandParty?.commander);
        if (Array.isArray(World?.user?.sessions)) {
            for (const s of World.user.sessions) {
                if (!s) continue;
                if (s === session || s.followPlayerSession === session || s.partyLeaderSession === session) {
                    addSession(s);
                }
            }
        }
        for (const s of candidateSessions) {
            const settings = typeof CompanionSvc?.getSettings === 'function' ? CompanionSvc.getSettings(s) : null;
            const info = typeof PartyPulling?.current === 'function' ? PartyPulling.current(s, settings) : null;
            if (info?.enabled && info?.target && info?.engageable !== false) {
                return info.target;
            }
            const fallbackId = Number(s?.partyPullState?.targetId || 0);
            if (fallbackId > 0) {
                const npc = World?.npc?.byId?.get?.(fallbackId)
                    || (Array.isArray(World?.npc?.list) ? World.npc.list.find((n) => Number(n?.fetchId?.()) === fallbackId) : null)
                    || null;
                if (npc) return npc;
            }
        }
    } catch (_) {}
    return null;
}

function findNearestMonster(actor, range, forcedTarget = null) {
    const World = invoke('GameServer/World/World');
    let best = null;
    let bestDist = range;

    const raw = collectWorldCandidates(actor, World);
    for (const entry of raw) {
        const candidate = entry?.actor || entry?.target || entry;
        if (!isValidMonster(actor, candidate)) continue;
        if (forcedTarget && getEntityId(candidate) !== getEntityId(forcedTarget)) continue;
        const d = dist2D(actor, candidate);
        if (d <= bestDist) {
            best = candidate;
            bestDist = d;
        }
    }
    return best;
}

function resolveCurrentTarget(actor, range) {
    const destId = Number(actor.fetchDestId?.() || actor.targetId || 0);
    if (!destId) return null;

    const World = invoke('GameServer/World/World');
    let target = World?.npc?.byId?.get?.(destId)
        || (Array.isArray(World?.npc?.list) ? World.npc.list.find((n) => Number(n?.fetchId?.()) === destId) : null)
        || World?.registeredActorById?.(destId)?.actor
        || World?.registeredActorById?.(destId)?.session?.actor
        || null;

    if (!target) {
        for (const entry of collectWorldCandidates(actor, World)) {
            const candidate = entry?.actor || entry?.target || entry;
            if (getEntityId(candidate) === destId) {
                target = candidate;
                break;
            }
        }
    }

    if (!isValidMonster(actor, target)) return null;
    if (dist2D(actor, target) > range * 1.25) return null;
    return target;
}

function executeSlotShortcut(session, actor, state, sc, target, now) {
    const kind = Number(sc.kind ?? sc.type);
    const id = Number(sc.id ?? sc.itemId ?? sc.shortcutId);
    if (!Number.isFinite(id) || id <= 0) return false;

    if (kind === 2) {
        const isDebuff = isDebuffOrParalysisSkill(actor, id);

        if (isDebuff && isDebuffAlreadyActiveOnTarget(state, target, id, now)) {
            return false;
        }

        if (isSkillOnCooldown(actor, id, now)) {
            return false;
        }

        if (typeof actor.skillRequest === 'function') {
            actor.skillRequest({
                selfId: id,
                ctrl: 0,
                shift: 0
            });
            if (isDebuff) {
                markDebuffAppliedOnTarget(actor, state, target, id, now);
            }
            return true;
        }
        return false;
    }

    if (kind === 3 && typeof actor.basicAction === 'function') {
        actor.basicAction({
            actionId: id,
            ctrl: 0,
            shift: 0
        });
        return true;
    }

    if (kind === 1 && typeof actor.backpack?.useItem === 'function') {
        actor.backpack.useItem(session, id);
        return true;
    }

    return false;
}

function tick(session) {
    try {
        const actor = session?.actor;
        const state = session?._autoFarm;
        if (!actor || !state || !state.enabled || session.closed) return;

        const now = Date.now();

        if (actor.isDead?.() || actor.state?.fetchDead?.()) {
            state.enabled = false;
            state.skillStreak = 0;
            state.appliedDebuffs.clear();
            return;
        }

        if (actor.isCastingNow?.() || actor.state?.fetchCasting?.()) return;

        const range = clampRange(state.range);
        const visionRange = clampRange(state.visionRange ?? range);
        const effectiveRadius = Math.min(range, visionRange);
        if (!state.anchor) {
            setAnchorFromActor(state, actor);
        }
        const center = state.anchor || getActorCoords(actor);
        const actorCoords = getActorCoords(actor);
        const WorldRef = invoke('GameServer/World/World');
        const pullTarget = state.pullOnly ? resolveActivePullTarget(session, WorldRef) : null;
        let target = resolveCurrentTarget(actor, effectiveRadius);
        if (state.pullOnly) {
            const pullTargetId = getEntityId(pullTarget);
            if (!pullTargetId || !isValidMonster(actor, pullTarget)) {
                cleanupDebuffTracker(state, null, now);
                return;
            }
            if (target && getEntityId(target) !== pullTargetId) {
                target = null;
            }
        }

        if (target) {
            const tCoords = getEntityCoords(target);
            if (tCoords && center && distPoint2D(center.x, center.y, tCoords.x, tCoords.y) > effectiveRadius * 1.1) {
                target = null;
            }
            if (target && tCoords && actorCoords && distPoint2D(actorCoords.x, actorCoords.y, tCoords.x, tCoords.y) > visionRange) {
                target = null;
            }
        }

        let acquiredNewTarget = false;

        if (!target) {
            target = findNearestMonster(actor, effectiveRadius, state.pullOnly ? pullTarget : null);
            if (target) {
                const tCoords = getEntityCoords(target);
                if (tCoords && center && distPoint2D(center.x, center.y, tCoords.x, tCoords.y) > effectiveRadius) {
                    target = null;
                }
                if (target && tCoords && actorCoords && distPoint2D(actorCoords.x, actorCoords.y, tCoords.x, tCoords.y) > visionRange) {
                    target = null;
                }
            }
            if (!target) {
                cleanupDebuffTracker(state, null, now);
                return;
            }
            selectTarget(actor, target, 0);
            acquiredNewTarget = true;
        }

        cleanupDebuffTracker(state, target, now);

        if (state.attackEnabled === false) {
            return;
        }

        const { entries: slotEntries } = getActiveFarmSlotEntries(session);
        const isMage = isMageActor(actor, slotEntries);

        if (acquiredNewTarget && !isMage) {
            performBasicAttack(actor, target);
            return;
        }

        if (slotEntries.length === 0) {
            if (!isMage) {
                performBasicAttack(actor, target);
            }
            return;
        }

        if (!isMage && state.skillStreak >= BASIC_ATTACK_EVERY_TICKS) {
            state.skillStreak = 0;
            performBasicAttack(actor, target);
            return;
        }

        let firedAny = false;
        for (let i = 0; i < slotEntries.length; i++) {
            const idx = (state.slotCursor + i) % slotEntries.length;
            const sc = slotEntries[idx];
            if (executeSlotShortcut(session, actor, state, sc, target, now)) {
                state.slotCursor = (idx + 1) % slotEntries.length;
                state.skillStreak += 1;
                firedAny = true;
                break;
            }
        }

        if (!firedAny) {
            state.skillStreak = 0;
            if (!isMage) {
                performBasicAttack(actor, target);
            }
        }
    } catch (_) {}
}

handleBypass.render = render;
handleBypass.tick = tick;
handleBypass.ensureState = ensureState;

module.exports = handleBypass;

// --- AutoFarm Player Loop ---
const AUTOFARM_LOOP_MS = 350;
const autoFarmLoopTimer = setInterval(() => {
    try {
        const World = invoke('GameServer/World/World');
        const sessions = World?.user?.sessions;
        if (!sessions) return;
        for (const session of sessions) {
            if (session && !session.closed && session._autoFarm?.enabled) {
                tick(session);
            }
        }
    } catch (_) {}
}, AUTOFARM_LOOP_MS);
if (typeof autoFarmLoopTimer.unref === 'function') {
    autoFarmLoopTimer.unref();
}