# Tutorial do Instalador Clicavel (INSTALAR_MODS.cmd)

## Como usar
1. Copie para a pasta raiz do servidor `L2Solo` (onde fica a pasta `src`):
   - A pasta `L2Solo-Meus-Mods`
   - O arquivo `instalar_mods.ps1`
   - O arquivo `INSTALAR_MODS.cmd`
2. De **dois cliques em `INSTALAR_MODS.cmd`** (ele abre o PowerShell automaticamente).

## O que ele faz para nao corromper arquivos
- **[NOVO]**: cria arquivos que ainda nao existem no servidor.
- **[ATUALIZADO + BACKUP]**: salva backup com data antes de aplicar os arquivos dos mods.
- **[PROTEGIDO]**: em arquivos compartilhados como `Speak.js`, `NativeMenu.js` e `Enchant.js` que ja existem no servidor, **nao sobrescreve nem mistura texto cegamente**; salva uma copia de referencia `.mod_sugerido.js` ao lado para voce revisar/mesclar com seguranca.

3. Apos concluir, **reinicie o servidor** e teste `.autofarm`, `.autopot` e `.autoenchant` no jogo.