const ActorQueries = require('../../World/ActorSpatialQueries');
const BotRoles = invoke('GameServer/Bot/AI/BotRoles');
const RestPolicy = invoke('GameServer/Bot/AI/RestPolicy');
const BotBuffs = invoke('GameServer/Bot/AI/BotBuffs');
const TownPathfinder = invoke('GameServer/Bot/AI/TownPathfinder');
const PartyAwareness = invoke('GameServer/Bot/AI/PartyAwareness');
const PartyCompanionService = invoke('GameServer/Bot/AI/PartyCompanionService');
const PartyPulling = invoke('GameServer/Bot/AI/PartyPulling');
const PartyCombatState = invoke('GameServer/Bot/AI/PartyCombatState');
const EffectStore = invoke('GameServer/Effects/EffectStore');
const GearSkillHints = invoke('GameServer/Bot/AI/GearSkillHints');
const HotBotPolicyOverlay = invoke('GameServer/Bot/AI/HotBotPolicyOverlay');
const BotAmbientDirector = invoke('GameServer/Bot/AI/BotAmbientDirector');
const BotInferenceBudget = invoke('GameServer/Bot/AI/BotInferenceBudget');
const LangfuseTracing = invoke('GameServer/Bot/AI/LangfuseTracing');
const BotTargetScorer = invoke('GameServer/Bot/AI/BotTargetScorer');
const BotRaidSafety = invoke('GameServer/Bot/AI/BotRaidSafety');
const NpcObjectIndex = require('../../World/NpcObjectIndex');

function ratio(value, max) {
    if (!max) return 0;
    return Math.max(0, Math.min(1, value / max));
}

function distance2d(a, b) {
    if (!a || !b) return null;
    const dx = a.locX - b.locX;
    const dy = a.locY - b.locY;
    return Math.sqrt(dx * dx + dy * dy);
}

function actorLocation(actor) {
    if (!actor) return null;
    return {
        locX: actor.fetchLocX(),
        locY: actor.fetchLocY(),
        locZ: actor.fetchLocZ()
    };
}

function actorSummary(actor, fromActor) {
    if (!actor) return null;
    const loc = actorLocation(actor);
    return {
        id: actor.fetchId(),
        name: actor.fetchName(),
        level: actor.fetchLevel(),
        loc,
        distance: fromActor ? distance2d(loc, actorLocation(fromActor)) : null,
        dead: actor.state ? actor.state.fetchDead() : actor.isDead(),
        karma: typeof actor.fetchKarma === 'function' ? actor.fetchKarma() : 0
    };
}

function decisionSummary(decision, kind = 'decision') {
    if (!decision) return 'none';

    const score = Number.isFinite(Number(decision.score)) ? ` score ${decision.score}` : '';
    const reasons = Array.isArray(decision.reasons) && decision.reasons.length > 0
        ? ` / ${decision.reasons.slice(0, 3).join(', ')}`
        : decision.reason ? ` / ${decision.reason}` : '';

    if (kind === 'target') {
        return `${decision.targetName || decision.targetId || 'unknown'}${score}${reasons}`;
    }
    if (kind === 'combat') {
        const choice = decision.skillName || (decision.skillId ? `skill ${decision.skillId}` : decision.action);
        return `${choice || 'unknown'}${score}${reasons}`;
    }
    if (kind === 'pvp') {
        return `${decision.action || 'unknown'} vs ${decision.threatName || decision.threatId || 'threat'}${score}${reasons}`;
    }
    return `${decision.action || 'unknown'}${score}${reasons}`;
}

function partyMemberSummary(memberSession, leaderSession, bot) {
    const actor = memberSession?.actor;
    if (!actor) return null;

    const summary = actorSummary(actor, bot);
    if (!summary) return null;

    return {
        ...summary,
        role: BotRoles.inferRole(actor),
        leader: memberSession === leaderSession,
        self: actor === bot,
        hpPct: ratio(actor.fetchHp(), actor.fetchMaxHp()),
        mpPct: ratio(actor.fetchMp(), actor.fetchMaxMp()),
        stance: memberSession.botStay ? 'stay' : 'follow'
    };
}

function partyThreatSummary(leaderSession, bot) {
    const threat = PartyAwareness.findThreatTargetingPartyProjected(leaderSession);
    if (!threat?.actor) return null;

    return {
        type: threat.type,
        source: threat.source || null,
        targetId: threat.targetId || null,
        actor: actorSummary(threat.actor, bot)
    };
}

function findTarget(session, bot) {
    if (!session.currentTargetId) return null;

    const World = invoke('GameServer/World/World');
    const candidate = World.registeredActorById(session.currentTargetId)?.session;
    const userSession = candidate?.actor && candidate.actor.fetchId() === session.currentTargetId ? candidate : null;
    if (userSession && userSession.actor) {
        return { type: 'user', ...actorSummary(userSession.actor, bot) };
    }

    const npc = NpcObjectIndex.find(World, session.currentTargetId);
    if (npc) {
        if (BotRaidSafety.isProtectedRaidEntity(npc)) return null;
        return {
            type: 'npc',
            ...actorSummary(npc, bot),
            attackable: npc.fetchAttackable()
        };
    }

    return {
        type: 'unknown',
        id: session.currentTargetId
    };
}

function inferIntent(session, bot, vitals, target) {
    if (session.pvpDefense) return session.pvpDefense.action === 'fight' ? 'defend_self_and_party' : 'escape_player';
    if (bot.state.fetchDead()) return 'revive';
    if (session.clanHallVisit) return 'refresh_buffs';
    if (session.plan === 'resting') return 'recover';
    if (session.plan === 'shopping') return 'restock';
    if (session.plan === 'getting_buffed') {
        return session.resumeAfterBuff?.reason === 'party_town_respawn'
            ? 'return_to_party'
            : 'refresh_buffs';
    }
    if (session.plan === 'fleeing' || session.plan === 'pk_fleeing') return 'escape_threat';
    if (session.plan === 'merchant') return 'trade';
    if (session.plan === 'following') {
        if (target) return 'assist_leader';
        if (session.botStay) return 'hold_position';
        return 'follow_leader';
    }
    if (session.plan === 'pk_hunting') {
        return target ? 'hunt_player' : 'find_player';
    }
    if (RestPolicy.needsRest(bot, vitals.hpPct, vitals.mpPct)) return 'recover';
    return target ? 'fight_target' : 'find_target';
}

function collectBlockers(session, bot, vitals, party) {
    const blockers = [];

    if (bot.state.fetchDead()) blockers.push('dead');
    if (RestPolicy.needsRest(bot, vitals.hpPct, 1)) blockers.push('low_hp');
    if (RestPolicy.needsRest(bot, 1, vitals.mpPct)) blockers.push('low_mp');
    if (session.stuckTicks >= 3) blockers.push('stuck');
    if (party && party.leader && party.leader.distance > 1000) blockers.push('too_far_from_leader');
    if (session.plan === 'hunting' && session.noTargetTicks >= 3) blockers.push('no_targets_nearby');

    return blockers;
}

function nearbySnapshot(bot, session) {
    const World = invoke('GameServer/World/World');
    const loc = actorLocation(bot);
    let realPlayers = 0;
    let friendlyBots = 0;
    let hostilePlayers = 0;
    let attackableNpcs = 0;
    let eligibleAttackableNpcs = 0;
    const attackableNames = new Map();

    ActorQueries.near(World, bot, 1500).forEach((session) => {
        const actor = session.actor;
        if (!actor || actor === bot || !actor.fetchIsOnline()) return;
        if (distance2d(actorLocation(actor), loc) > 1500) return;

        if (session.accountId && session.accountId.startsWith('bot_')) {
            friendlyBots++;
        } else {
            realPlayers++;
        }

        if (typeof actor.fetchKarma === 'function' && actor.fetchKarma() > 0) {
            hostilePlayers++;
        }
    });

    World.fetchNpcsInRadius(bot.fetchLocX(), bot.fetchLocY(), 1500).forEach((npc) => {
        if (!BotRaidSafety.isProtectedRaidEntity(npc) && npc.fetchAttackable() && !npc.isDead()) {
            attackableNpcs++;
            const name = String(npc.fetchName?.() || 'Unknown NPC');
            attackableNames.set(name, Number(attackableNames.get(name) || 0) + 1);
            const levelGap = Number(npc.fetchLevel?.() || bot.fetchLevel()) - Number(bot.fetchLevel() || 1);
            if (levelGap >= BotTargetScorer.MIN_LEVEL_GAP && levelGap <= BotTargetScorer.MAX_LEVEL_ADVANTAGE) {
                eligibleAttackableNpcs++;
            }
        }
    });

    const attackableNpcNames = [...attackableNames.entries()]
        .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
        .slice(0, 3)
        .map(([name, count]) => ({ name, count }));
    const scan = session?.huntingTargetScan;
    // The hunting executor includes safe easier targets and can expand its
    // search within the selected field. Chat reads that actual scan, rather
    // than contradicting it with this older level-only 1500-unit count.
    if (session?.plan === 'hunting' && scan && Date.now() - scan.at < 10000
        && distance2d(loc, scan.loc) <= 128) {
        attackableNpcs = scan.attackableNpcs;
        eligibleAttackableNpcs = scan.eligibleAttackableNpcs;
    }
    const engaged = session?.plan === 'hunting' && NpcObjectIndex.find(World, session.currentTargetId);
    if (engaged && engaged.fetchAttackable?.() && !engaged.isDead?.()
        && !BotRaidSafety.isProtectedRaidEntity(engaged)) {
        attackableNpcs = Math.max(1, attackableNpcs);
        eligibleAttackableNpcs = Math.max(1, eligibleAttackableNpcs);
    }
    return { realPlayers, friendlyBots, hostilePlayers, attackableNpcs, eligibleAttackableNpcs, attackableNpcNames };
}

function tradeSnapshot(session, bot) {
    const store = bot.fetchPrivateStore && bot.fetchPrivateStore();
    const loot = session.lastLootRequest || null;
    const BotTradeService = invoke('GameServer/Bot/BotTradeService');
    const BotNegotiationService = invoke('GameServer/Bot/Economy/BotNegotiationService');
    const active = BotTradeService.activeTradeSummary(session);
    const negotiation = BotNegotiationService.activeSummary(session);

    return {
        active,
        negotiation,
        store: store ? {
            type: store.storeType === 3 ? 'buy' : 'sell',
            title: store.title || '',
            town: store.town || null,
            items: store.items ? store.items.length : 0
        } : null,
        shoppingTarget: session.shoppingTarget || null,
        last: session.lastTradeSummary || null,
        lootRequest: loot ? {
            playerName: loot.playerName,
            itemName: loot.itemName,
            amount: loot.amount,
            reason: loot.reason || null,
            demandScore: loot.demandScore || null,
            expiresAt: loot.expiresAt
        } : null
    };
}

function personaSnapshot(session) {
    const persona = invoke('GameServer/Bot/AI/BotPersona').of(session);
    if (!persona?.primaryDrive || !persona?.archetype || !persona?.traits) return null;

    return {
        primaryDrive: persona.primaryDrive,
        archetype: persona.archetype,
        traits: { ...persona.traits },
        textCard: persona.textCard || '',
        dialogueVoice: persona.dialogueVoice || ''
    };
}

const BotStatus = {
    getStatus(session) {
        const bot = session.actor;
        if (!bot) {
            return {
                available: false,
                reason: 'missing_actor'
            };
        }

        const vitals = {
            hp: bot.fetchHp(),
            maxHp: bot.fetchMaxHp(),
            hpPct: ratio(bot.fetchHp(), bot.fetchMaxHp()),
            mp: bot.fetchMp(),
            maxMp: bot.fetchMaxMp(),
            mpPct: ratio(bot.fetchMp(), bot.fetchMaxMp())
        };

        const role = BotRoles.inferRole(bot);
        const dead = bot.state.fetchDead();
        const ambient = BotAmbientDirector.snapshot(session);
        const target = findTarget(session, bot);
        const leaderSession = session.followPlayerSession && session.partyCompanion === true ? session.followPlayerSession : null;
        const partySettings = leaderSession ? PartyCompanionService.getSettings(leaderSession) : null;
        const pull = leaderSession ? PartyPulling.current(leaderSession, partySettings) : null;
        const combat = leaderSession ? PartyCombatState.combatState(leaderSession) : null;
        const isAssignedPuller = partySettings?.pullMode === 'bot' &&
            Number(partySettings.pullerId || 0) === Number(bot.fetchId());
        let party = leaderSession ? {
            leader: actorSummary(leaderSession.actor, bot),
            role,
            settings: partySettings,
            stance: isAssignedPuller ? 'pulling' : (session.botStay ? 'stay' : 'follow'),
            roleStance: BotRoles.partyRoleStance(role),
            autoTaunt: session.autoTaunt !== false,
            pull: pull?.enabled ? {
                mode: partySettings.pullMode,
                pullerId: pull.puller?.actor?.fetchId?.() || null,
                targetId: pull.target?.fetchId?.() || null,
                phase: pull.phase,
                paused: pull.paused || null,
                selectionScore: pull.selectionScore ?? null,
                selectionReasons: pull.selectionReasons || []
            } : null,
            decision: session.roleDecision || null,
            members: PartyAwareness.partySessions(leaderSession)
                .map((memberSession) => partyMemberSummary(memberSession, leaderSession, bot))
                .filter(Boolean),
            threat: partyThreatSummary(leaderSession, bot),
            combat: combat?.active ? {
                reason: combat.reason,
                targetId: combat.target?.fetchId?.() || null,
                targetName: combat.target?.fetchName?.() || null
            } : null,
            recovery: leaderSession.partyRecoveryCast && Number(leaderSession.partyRecoveryCast.expiresAt || 0) > Date.now()
                ? {
                    kind: 'recharge',
                    providerId: leaderSession.partyRecoveryCast.providerId,
                    targetId: leaderSession.partyRecoveryCast.targetId,
                    expiresAt: leaderSession.partyRecoveryCast.expiresAt
                }
                : null,
            revival: leaderSession.partyRevivalAttempt ? {
                providerId: leaderSession.partyRevivalAttempt.providerId,
                targetId: leaderSession.partyRevivalAttempt.targetId,
                source: leaderSession.partyRevivalAttempt.source,
                startedAt: leaderSession.partyRevivalAttempt.startedAt
            } : null
        } : null;

        if (!party && session.hotBackgroundPartyId) {
            const background = invoke('GameServer/Bot/AI/HotBackgroundParty');
            const leader = background.leader(session);
            party = { id: session.hotBackgroundPartyId, leader: actorSummary(leader.actor, bot),
                role: session.coldLifeState?.party?.role || role, stance: 'shared_hunt',
                members: background.roster(session).map(member => partyMemberSummary(member, leader, bot)),
                decision: session.lastDecision || null };
        }

        const status = {
            available: true,
            id: bot.fetchId(),
            name: bot.fetchName(),
            level: bot.fetchLevel(),
            classId: bot.fetchClassId(),
            mode: dead ? 'dead' : session.pvpDefense ? `pvp_${session.pvpDefense.action}` : session.plan || 'hunting',
            intent: undefined,
            role,
            roleDecision: dead ? null : session.roleDecision || null,
            decisions: {
                role: dead ? null : session.roleDecision || null,
                hunt: dead ? null : session.lastDecision || null,
                target: dead ? null : session.lastTargetEvaluation || null,
                combat: dead ? null : session.lastCombatDecision || null,
                pvp: dead ? null : session.lastPvpDecision || null
            },
            home: {
                region: session.homeRegion || null,
                visitor: !!session.visitor
            },
            loc: actorLocation(bot),
            vitals,
            target,
            party,
            spot: session.currentSpot || null,
            build: GearSkillHints.forCharacter(bot, { role }),
            movement: {
                moving: !!session.moveTimer || !!bot.state.fetchTowards(),
                towards: bot.state.fetchTowards() || false,
                speed: {
                    baseRun: Number(bot.fetchRunSpd?.()) || 0,
                    collectiveRun: Number(bot.fetchCollectiveRunSpd?.()) || 0,
                    baseWalk: Number(bot.fetchWalkSpd?.()) || 0,
                    collectiveWalk: Number(bot.fetchCollectiveWalkSpd?.()) || 0,
                    multiplier: (Number(bot.fetchRunSpd?.()) || 0) > 0
                        ? (Number(bot.fetchCollectiveRunSpd?.()) || 0) / Number(bot.fetchRunSpd?.())
                        : 1,
                    walking: bot.state.fetchWalkin?.() === true
                },
                trace: (invoke('GameServer/Bot/Population/PopulationConfig').developerDiagnostics === true) && Array.isArray(session.movementTrace) ? session.movementTrace.slice(-24) : null,
                stuckTicks: session.stuckTicks || 0,
                followTarget: session.lastFollowMoveTarget || null,
                followHeldAt: session.lastFollowMoveHeldAt || null,
                townRoute: session.townRoutePlan || null,
                pathfinding: session.lastPathfinding || null,
                pathSummary: (invoke('GameServer/Bot/Population/PopulationConfig').developerDiagnostics === true) ? TownPathfinder.describeDiagnostics(session.lastPathfinding?.townRoute) : null,
                retreat: session.lastRetreatPlan ? {
                    threatId: session.lastRetreatPlan.threatId,
                    to: session.lastRetreatPlan.to,
                    selectedAngle: session.lastRetreatPlan.selectedAngle,
                    movesAway: session.lastRetreatPlan.movesAway,
                    emergencyFallback: session.lastRetreatPlan.emergencyFallback,
                    safe: session.lastRetreatPlan.safe,
                    routeUsable: session.lastRetreatPlan.routeUsable,
                    hazardCount: session.lastRetreatPlan.hazardCount,
                    newAggroCount: session.lastRetreatPlan.newAggroCount,
                    endpointAggroCount: session.lastRetreatPlan.endpointAggroCount,
                    at: session.lastRetreatPlan.at
                } : null
            },
            buffs: BotBuffs.snapshot(bot),
            debuffs: EffectStore.activeDebuffs(bot).map((effect) => ({
                key: effect.key,
                name: effect.name,
                remainingSec: Math.round(EffectStore.remainingMs(bot, effect.key) / 1000)
            })),
            timers: {
                deathStartedAt: session.deathTimerStart || null,
                fleeStartedAt: session.fleeStart || null,
                shopStartedAt: session.shopTimer || null
            },
            nearby: nearbySnapshot(bot, session),
            trade: tradeSnapshot(session, bot),
            ambient,
            inference: BotInferenceBudget.snapshot(session),
            llm: invoke('GameServer/Bot/Population/PopulationConfig').developerDiagnostics === true ? {
                last: session.lastBrainTelemetry || null,
                context: session.lastBrainContextTelemetry || null,
                langfuse: LangfuseTracing.status()
            } : { enabled: false },
            persona: personaSnapshot(session),
            policy: HotBotPolicyOverlay.status(session),
            social: session.socialSummary || null,
            lastSocialEvent: session.lastSocialEvent || null,
            blockers: []
        };

        status.intent = inferIntent(session, bot, vitals, target);
        status.blockers = collectBlockers(session, bot, vitals, party);
        return status;
    },

    summarize(status) {
        if (!status || !status.available) return 'Bot status unavailable.';

        const hp = Math.round(status.vitals.hpPct * 100);
        const mp = Math.round(status.vitals.mpPct * 100);
        const target = status.target && status.target.name ? ` target=${status.target.name}` : '';
        const spot = status.spot && status.spot.name ? ` spot=${status.spot.name}` : '';
        const home = status.home && status.home.region ? ` home=${status.home.region}${status.home.visitor ? ':visitor' : ''}` : '';
        const social = status.social ? ` social=${status.social.playerName}:${status.social.relationship}/${status.social.trust}` : '';
        const ambient = status.ambient ? ` mood=${status.ambient.mood}/${status.ambient.intent}` : '';
        const inference = status.inference ? ` llm=${status.inference.requests}/${status.inference.maxRequests}` : '';
        const roleDecision = status.roleDecision ? ` decision=${status.roleDecision.action}/${status.roleDecision.reason}` : '';
        const targetDecision = status.decisions?.target ? ` targetScore=${status.decisions.target.score}` : '';
        const combatDecision = status.decisions?.combat
            ? ` combat=${status.decisions.combat.skillId || status.decisions.combat.action}/${status.decisions.combat.score ?? 'na'}`
            : '';
        const pvpDecision = status.decisions?.pvp
            ? ` pvp=${status.decisions.pvp.action}/${status.decisions.pvp.score ?? 'na'}`
            : '';
        const build = status.build ? ` build=${status.build.grade}/${status.build.weapon}/${status.build.armor}` : '';
        const path = status.movement?.pathfinding?.townRoute?.changedTarget ? ' path=town' : '';
        const buffs = status.buffs?.needsRefresh ? ' buffs=refresh' : '';
        const blockers = status.blockers.length > 0 ? ` blockers=${status.blockers.join(',')}` : '';

        return `${status.name}: mode=${status.mode} intent=${status.intent} role=${status.role}${home} hp=${hp}% mp=${mp}%${target}${spot}${ambient}${inference}${social}${roleDecision}${targetDecision}${combatDecision}${pvpDecision}${build}${path}${buffs}${blockers}`;
    }
};

BotStatus.ROLE_CLASSES = BotRoles.ROLE_CLASSES;
BotStatus.decisionSummary = decisionSummary;

module.exports = BotStatus;
