const ServerResponse = invoke('GameServer/Network/Response');
const ReceivePacket  = invoke('Packet/Receive');
const PopulationConfig = invoke('GameServer/Bot/Population/PopulationConfig');

const BOT_COMMAND_ALIASES = Object.freeze({
    '.b': '.bot',
    '.bf': '.botfriends',
    '.bp': '.botparty',
    '.bs': '.botstatus',
    '.bpath': '.botpath'
});

function expandBotCommandAlias(text) {
    const source = String(text || '');
    const command = source.match(/^\S+/)?.[0];
    const canonical = BOT_COMMAND_ALIASES[command];
    return canonical ? canonical + source.slice(command.length) : source;
}

function logPlayerChat(session, data) {
    if (PopulationConfig.developerDiagnostics !== true || PopulationConfig.devLogPlayerChat === false) return;
    if (!session?.actor || String(session.accountId || '').startsWith('bot_')) return;

    const name = session.actor.fetchName ? session.actor.fetchName() : session.accountId || 'unknown';
    const text = String(data.text || '').replace(/\s+/g, ' ').slice(0, 180);
    const target = data.target ? ` target="${String(data.target).slice(0, 40)}"` : '';
    console.info('PlayerChat :: %s kind=%s%s text="%s"', name, data.kind, target, text);
}

function speak(session, buffer) {
    let packet = new ReceivePacket(buffer);

    packet
        .readS()  // Text
        .readD(); // Kind

    if (packet.data[1] === 2) {
        packet.readS(); // Target name for private tell
    }

    return consume(session, {
        text: packet.data[0],
        kind: packet.data[1],
        target: packet.data[2],
    });
}

function findOnlineUserByName(name) {
    const lookup = String(name || '').trim().toLowerCase();
    if (!lookup) return null;

    const World = invoke('GameServer/World/World');
    return World.user.sessions.find((user) => (
        user?.actor &&
        user.actor.fetchIsOnline?.() === true &&
        !String(user.accountId || '').startsWith('bot_') &&
        user.actor.fetchName().toLowerCase() === lookup
    )) || null;
}

function echoPrivateTell(session, data, recipientName) {
    session.dataSendToMe(ServerResponse.speak({
        fetchId: () => session.actor.fetchId(),
        fetchName: () => `->${recipientName}`
    }, data));
}

function handlePrivateTell(session, data) {
    const World = invoke('GameServer/World/World');
    const target = String(data.target || '').trim();
    const text = String(data.text || '').trim();

    if (!target || !text) {
        session.dataSendToMe(ServerResponse.actionFailed());
        return;
    }

    const BotManager = invoke('GameServer/Bot/BotManager');
    const botSession = BotManager.findSessionByName(target);
    if (botSession) {
        echoPrivateTell(session, data, botSession.actor.fetchName());
        return World.messageBotByName(session, session.actor, target, text, 'client_tell');
    }

    const targetSession = findOnlineUserByName(target);
    if (targetSession) {
        const packet = ServerResponse.speak(session.actor, data);
        targetSession.dataSendToMe(packet);
        echoPrivateTell(session, data, targetSession.actor.fetchName());
        return Promise.resolve(true);
    }

    // Cold bots have no online actor, but their persistent life-state is still
    // a valid private-tell target. Resolve that identity before rejecting the
    // tell so the message can enter the same cold LLM dialogue path.
    const LifeState = invoke('GameServer/Bot/Population/BotLifeState');
    const actor = session.actor;
    return LifeState.findByName(target).then((state) => {
        // A character selected during the lookup does not send this tell.
        if (session.actor !== actor) return false;
        if (!state) {
            return World.messageBotByName(session, session.actor, target, text, 'client_tell');
        }

        echoPrivateTell(session, data, state.name || target);
        return World.messageBotByName(session, session.actor, target, text, 'client_tell');
    });
}

// Clan chat (kind 4): delivered to online clan members and the clan
// dialogue service only; its result is the result of consume.
function routeClanSpeech(session, data) {
    const clanId = Number(session.actor?.fetchClanId?.() || 0);
    if (!clanId) return;
    const packet = ServerResponse.speak(session.actor, data);
    const ClanService = invoke('GameServer/Clan/ClanService');
    ClanService.onlineSessions({ id: clanId }).forEach(member => {
        if (member.actor?.fetchIsOnline?.() !== false) member.dataSendToMe(packet);
    });
    // Clan speech must not leak into local delivery or the nearby-bot
    // dialogue router, which has no clan membership constraint.
    return invoke('GameServer/Bot/AI/ClanDialogueService').handlePlayerSpeak(session, data);
}

// Local chat commands (kind 0). Returns true when a command handled the
// line, false when it is ordinary speech that goes on to the broadcast.
function dispatchLocalCommand(session, data) {
    if (String(data.text || '').trim().toLowerCase() === '.menu') {
        invoke('GameServer/World/Generics/NpcBypasses/NativeMenu').open(session);
        return true;
    }
    const ArenaDuelService = invoke('GameServer/World/ArenaDuelService');
    if (String(data.text || '').trim().toLowerCase() === '.go') {
        ArenaDuelService.handleGo(session, data.text);
        return true;
    }
    const botCommandText = expandBotCommandAlias(data.text);

    if (invoke('GameServer/Bot/Economy/BuffService').command(session, String(data.text || '').trim())) return true;

    const itemsCommand = /^\.items(?:\s+(.*))?$/i.exec(String(data.text || '').trim());
    if (itemsCommand) {
        invoke('GameServer/World/Generics/NpcBypasses/NativeItems').open(session, itemsCommand[1] ?? null);
        return true;
    }

    if (data.text === '.admin') {
        invoke(path.actor).adminPanel(session, session.actor);
        return true;
    }
    if (data.text === '.sell') {
        invoke(path.world + 'NpcTalkResponse')(session, { link: 'sell-junk' });
        return true;
    }
    if (data.text === '.afksell' || data.text === '.afkbuy') {
        const AfkTrade = invoke('GameServer/AfkTrade/AfkTradeService');
        AfkTrade.begin(session, data.text === '.afksell' ? AfkTrade.SELL : AfkTrade.BUY)
            .catch((error) => utils.infoWarn('AfkTrade', 'command failed: %s', error.message));
        return true;
    }
    if (data.text === '.afkstop') {
        invoke('GameServer/AfkTrade/AfkTradeService').stop(session)
            .catch((error) => utils.infoWarn('AfkTrade', 'stop command failed: %s', error.message));
        return true;
    }
    if (invoke('GameServer/Bot/AI/PlayerPartyPreset').handleCommand(session, data.text)) return true;
    if (invoke('GameServer/Bot/AI/ClanCommandParty').handleCommand(session, data.text)) return true;

    if (data.text === '.leave') {
        const World = invoke('GameServer/World/World');
        World.dismissParty(session, session.actor);
        return true;
    }
    if (data.text.startsWith('.kick ')) {
        const name = data.text.substring(6).trim();
        const World = invoke('GameServer/World/World');
        World.oustPartyMember(session, session.actor, { name: name });
        return true;
    }
    if (botCommandText === '.bot' || data.text === '.companion') {
        const CompanionControl = invoke('GameServer/World/Generics/NpcBypasses/CompanionControl');
        CompanionControl.render(session, 0, { open: true });
        return true;
    }
    if (botCommandText === '.botparty') {
        const BotParty = invoke('GameServer/World/Generics/NpcBypasses/BotParty');
        BotParty.open(session);
        return true;
    }
    if (data.text.startsWith('/invite ') || data.text.startsWith('.invite ')) {
        const name = data.text.replace(/^\/invite\s+|^\.invite\s+/, '').trim();
        const World = invoke('GameServer/World/World');
        World.inviteBotByName(session, session.actor, name, undefined, 'chat_invite');
        return true;
    }
    if (/^\.joinparty(?:\s+.*)?$/i.test(String(data.text || '').trim())) {
        const name = String(data.text || '').trim().replace(/^\.joinparty\s*/i, '').trim();
        const World = invoke('GameServer/World/World');
        World.requestJoinBotPartyByName(session, session.actor, name, 'join_party_command');
        return true;
    }
    if (botCommandText === '.botfriends' || botCommandText.startsWith('.botfriends ')) {
        const BotFriends = invoke('GameServer/World/Generics/NpcBypasses/BotFriends');
        BotFriends.render(session, botCommandText.includes(' add') ? 'add' : 'friends', 0, null, { open: true });
        return true;
    }
    if (/^(\/tell|\.tell|\/w|\.w)\s+/i.test(data.text)) {
        const body = data.text.replace(/^(\/tell|\.tell|\/w|\.w)\s+/i, '').trim();
        const match = body.match(/^(\S+)\s+(.+)$/);
        const World = invoke('GameServer/World/World');
        World.messageBotByName(
            session,
            session.actor,
            match ? match[1] : '',
            match ? match[2] : '',
            'chat_tell'
        );
        return true;
    }
    if (data.text === '.uitest') {
        const UiTest = invoke('GameServer/World/Generics/NpcBypasses/UiTest');
        UiTest.render(session);
        return true;
    }
    if (botCommandText === '.botstatus' || botCommandText.startsWith('.botstatus ')) {
        const BotStatus = invoke('GameServer/World/Generics/NpcBypasses/BotStatus');
        const parts = botCommandText.split(/\s+/);
        BotStatus(session, ['bot-status', parts[1]]);
        return true;
    }
    if (botCommandText === '.botpath' || botCommandText.startsWith('.botpath ')) {
        const BotPath = invoke('GameServer/World/Generics/NpcBypasses/BotPath');
        const parts = botCommandText.split(/\s+/);
        BotPath(session, ['bot-path', parts[1]]);
        return true;
    }
    if (data.text === '/trade' || data.text === '.trade') {
        const BotManager = invoke('GameServer/Bot/BotManager');
        const BotTradeService = invoke('GameServer/Bot/BotTradeService');
        const targetSession = BotManager.findSessionById(session.actor.fetchDestId());
        const result = BotTradeService.startPlayerTrade(session, targetSession);

        if (!result.ok) {
            session.dataSendToMe(ServerResponse.actionFailed());
            return true;
        }

        session.dataSendToMe(ServerResponse.tradeStart(
            targetSession.actor,
            session.actor.backpack.fetchItems()
        ));
        return true;
    }
    return false;
}

// Shout and trade go to every connected player; any other kind goes to
// the speaker and the players around.
function broadcastSpeech(session, data) {
    if (data.kind === 1 || data.kind === 8) { // Shout / Trade
        const packet = ServerResponse.speak(session.actor, data);
        const World = invoke('GameServer/World/World');
        World.user.sessions.forEach((user) => {
            if (user.socket && typeof user.socket.write === 'function' && user.accountId.indexOf('bot_') !== 0) {
                user.dataSendToMe(packet);
            }
        });
    } else {
        session.dataSendToMeAndOthers(ServerResponse.speak(session.actor, data), session.actor);
    }
}

// Nearby bots hear the line through the BotManager dialogue entry.
function enterBotDialogue(session, data) {
    try {
        invoke('GameServer/Bot/BotManager').handlePlayerSpeak(session, data);
    } catch (err) {
        console.error("BotManager speak hook error:", err);
    }
}

function consume(session, data) {
    logPlayerChat(session, data);
    try {
        const rawText = String(data && data.text ? data.text : '').trim();
        const lowerText = rawText.toLowerCase();
        if (/^\.autopot(?:\s+.*)?$/i.test(rawText)) {
            console.info('ModStep :: [INICIO] AutoPot comando: %s', rawText);
            const ok = invoke('GameServer/World/Generics/NpcBypasses/AutoPotion').handleCommand(session, rawText);
            console.info('ModStep :: [FIM] AutoPot comando concluido (ok=%s)', Boolean(ok));
            return true;
        }
        if (/^\.autoenchant(?:\s+.*)?$/i.test(rawText)) {
            console.info('ModStep :: [INICIO] AutoEnchant comando: %s', rawText);
            const ok = invoke('GameServer/World/Generics/AutoEnchant').handleCommand(session, rawText);
            console.info('ModStep :: [FIM] AutoEnchant comando concluido (ok=%s)', Boolean(ok));
            return true;
        }
        if (lowerText === '.autofarm' || lowerText === '.farm') {
            console.info('ModStep :: [INICIO] AutoFarm comando: %s', rawText);
            invoke('GameServer/World/Generics/NpcBypasses/AutoFarm')(session, ['auto-farm']);
            console.info('ModStep :: [FIM] AutoFarm painel/acao despachada');
            return true;
        }
    } catch (err) {
        console.warn('ModStep :: [ERRO] Falha ao processar comando de mod em Speak.js: %s', err && err.message ? err.message : err);
        return true;
    }

    if (data.kind === 4) return routeClanSpeech(session, data);

    if (data.kind === 2) {
        handlePrivateTell(session, data);
        return;
    }

    if (data.kind === 0 && dispatchLocalCommand(session, data)) return; // TODO: Remove, temp solution

    broadcastSpeech(session, data);
    enterBotDialogue(session, data);
}

module.exports = speak;
module.exports.consume = consume;
module.exports.expandBotCommandAlias = expandBotCommandAlias;
