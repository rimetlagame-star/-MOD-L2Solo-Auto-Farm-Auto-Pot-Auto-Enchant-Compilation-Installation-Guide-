$ErrorActionPreference = "Stop"
$raiz = Split-Path -Parent $MyInvocation.MyCommand.Path
$pkgSrc = Join-Path $raiz "L2Solo-Meus-Mods\src"
$alvoSrc = Join-Path $raiz "src"
if (-not (Test-Path $pkgSrc)) { Write-Host "[ERRO] Pasta L2Solo-Meus-Mods\src nao encontrada ao lado deste instalador." -ForegroundColor Red; pause; exit 1 }
if (-not (Test-Path $alvoSrc)) { Write-Host "[ERRO] Pasta src do jogo nao encontrada aqui. Coloque o instalador na raiz do L2Solo." -ForegroundColor Red; pause; exit 1 }
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$compartilhados = @("Network\Request\Speak.js","World\Generics\NpcBypasses\NativeMenu.js","Enchant.js","Bot\AI\States\FollowingState.js","Bot\AI\States\RestingState.js","Bot\AI\BotStatus.js","Bot\AI\PlayerPartyRaid.js")
Get-ChildItem -Path $pkgSrc -Recurse -File | ForEach-Object {
  $rel = $_.FullName.Substring($pkgSrc.Length).TrimStart("\","/")
  $relNorm = $rel -replace "/","\\"
  $dst = Join-Path $alvoSrc $relNorm
  New-Item -ItemType Directory -Path (Split-Path -Parent $dst) -Force | Out-Null
  if (-not (Test-Path $dst)) {
    Copy-Item -Path $_.FullName -Destination $dst -Force
    Write-Host "[NOVO] $relNorm" -ForegroundColor Green
  } elseif ($compartilhados -contains $relNorm) {
    $origTxt = Get-Content -Path $dst -Raw -ErrorAction SilentlyContinue
    $modTxt = Get-Content -Path $_.FullName -Raw -ErrorAction SilentlyContinue
    if ($origTxt -eq $modTxt) {
      Write-Host "[IGUAL] $relNorm - sem alteracao" -ForegroundColor DarkGray
    } else {
      $candidato = "$dst.mod_sugerido.js"
      Copy-Item -Path $_.FullName -Destination $candidato -Force
      Write-Host "[PROTEGIDO] $relNorm ja existe -> salvo sugestao em $relNorm.mod_sugerido.js" -ForegroundColor Yellow
    }
  } else {
    Copy-Item -Path $dst -Destination "$dst.bak_$stamp" -Force
    Copy-Item -Path $_.FullName -Destination $dst -Force
    Write-Host "[ATUALIZADO + BACKUP] $relNorm" -ForegroundColor Cyan
  }
}
Write-Host "`nProcesso concluido! Reinicie o servidor antes de testar no jogo." -ForegroundColor Green
pause