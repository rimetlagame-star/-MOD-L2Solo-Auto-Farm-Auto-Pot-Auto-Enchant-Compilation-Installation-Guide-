'use strict';
﻿
function notifyModStep(session, stage, message) {
    try {
        const text = `[${stage}] ${message}`;
        if (session && !session.closed && typeof session.dataSendToMe === 'function') {
            const Res = invoke('GameServer/Network/Response');
            if (Res && typeof Res.creatureSay === 'function') {
                session.dataSendToMe(Res.creatureSay(0, 15, 'Mod', text));
            } else if (Res && typeof Res.systemMessage === 'function') {
                session.dataSendToMe(Res.systemMessage(text));
            }
        }
        console.info('ModStep :: %s', text);
    } catch (_) {}
}
'use strict';

const COOLDOWN_MS = 1200;
const TICK_MS = 800;

function defaultConfig() {
    return {
        enabled: false,
        hp: { enabled: true, pct: 70, slotNum: 10, itemSelfId: null, lastUse: 0 },
        mp: { enabled: true, pct: 50, slotNum: 11, itemSelfId: null, lastUse: 0 },
        cp: { enabled: true, pct: 80, slotNum: 12, itemSelfId: null, lastUse: 0 }
    };
}

function getConfig(session) {
    if (!session) return defaultConfig();
    if (!session._autoPotion) {
        session._autoPotion = defaultConfig();
    }
    return session._autoPotion;
}

function clampPct(val) {
    const n = Number(val);
    if (!Number.isFinite(n)) return 50;
    return Math.max(1, Math.min(100, Math.round(n)));
}

function sendHtml(session, html) {
    const actor = session?.actor;
    if (!session || session.closed || !actor || typeof session.dataSendToMe !== 'function') return;
    try {
        const Response = invoke('GameServer/Network/Response');
        const objId = typeof actor.fetchId === 'function' ? actor.fetchId() : 0;
        if (Response && typeof Response.npcHtml === 'function') {
            session.dataSendToMe(Response.npcHtml(objId, html));
        }
    } catch (_) {}
}

function describeItem(item) {
    if (!item) return 'Nenhuma (Auto)';
    const selfId = item.fetchSelfId?.();
    const name = item.fetchName?.() || item.template?.name || `Item #${selfId}`;
    const amount = item.fetchAmount?.() ?? 1;
    return `${name} (x${amount})`;
}

function isGearOrNonPotion(item) {
    if (!item) return true;
    if (typeof item.isWearable === 'function' && item.isWearable()) return true;
    const name = String(item?.fetchName?.() || item?.template?.name || '').toLowerCase();
    const nonPotionKeywords = [
        'shield', 'helm', 'helmet', 'armor', 'armour', 'tunic', 'stockings',
        'gauntlet', 'glove', 'boots', 'ring', 'earring', 'necklace', 'undergarment',
        'scroll', 'soulshot', 'spiritshot', 'arrow', 'recipe', 'adena', 'seal'
    ];
    return nonPotionKeywords.some((k) => name.includes(k));
}

function classifyPotion(item, stat) {
    if (!item || isGearOrNonPotion(item)) return false;
    const selfId = Number(item?.fetchSelfId?.() || 0);
    const name = String(item?.fetchName?.() || item?.template?.name || '').toLowerCase();
    if (stat === 'mp') {
        return selfId === 728 || name.includes('mana') || name.includes('mp');
    }
    if (stat === 'cp') {
        return name.includes('cp ') || name.startsWith('cp') || name.includes('combat point');
    }
    const isMpOrCp = selfId === 728 || name.includes('mana') || name.includes('mp') || name.includes('cp ') || name.startsWith('cp');
    if (isMpOrCp) return false;
    return name.includes('potion') || name.includes('healing') || name.includes('hp');
}

function findPotionItem(session, stat, cfgEntry) {
    const actor = session?.actor;
    const items = actor?.backpack?.fetchItems?.() || [];
    if (!Array.isArray(items) || items.length === 0) return null;

    if (cfgEntry.itemSelfId) {
        const bound = items.find((it) =>
            Number(it?.fetchSelfId?.()) === Number(cfgEntry.itemSelfId)
            && (it?.fetchAmount?.() ?? 0) > 0
            && classifyPotion(it, stat)
        );
        if (bound) return bound;
    }

    const matched = items.find((it) => (it?.fetchAmount?.() ?? 0) > 0 && classifyPotion(it, stat));
    return matched || null;
}

function getStatPercent(actor, stat) {
    if (!actor) return 100;
    if (stat === 'hp') {
        const cur = Number(actor.fetchHp?.() ?? 0);
        const max = Number(actor.fetchMaxHp?.() ?? 1);
        return max > 0 ? (cur / max) * 100 : 100;
    }
    if (stat === 'mp') {
        const cur = Number(actor.fetchMp?.() ?? 0);
        const max = Number(actor.fetchMaxMp?.() ?? 1);
        return max > 0 ? (cur / max) * 100 : 100;
    }
    if (stat === 'cp') {
        if (typeof actor.fetchCp !== 'function' || typeof actor.fetchMaxCp !== 'function') return 100;
        const cur = Number(actor.fetchCp() ?? 0);
        const max = Number(actor.fetchMaxCp() ?? 0);
        return max > 0 ? (cur / max) * 100 : 100;
    }
    return 100;
}

function tryUsePotionForStat(session, stat) {
    const actor = session?.actor;
    if (!actor || session.closed || actor.isDead?.()) return;
    const cfg = getConfig(session);
    if (!cfg.enabled) return;

    const entry = cfg[stat];
    if (!entry || !entry.enabled) return;

    const pct = getStatPercent(actor, stat);
    if (pct > entry.pct) return;

    const now = Date.now();
    if (now - (entry.lastUse || 0) < COOLDOWN_MS) return;

    const item = findPotionItem(session, stat, entry);
    if (!item || typeof actor.backpack?.useItem !== 'function') return;

    const itemId = item.fetchId?.();
    if (!itemId) return;

    entry.lastUse = now;
    actor.backpack.useItem(session, itemId);
}

function cyclePotionBinding(session, stat) {
    const cfg = getConfig(session);
    const entry = cfg[stat];
    const items = (session?.actor?.backpack?.fetchItems?.() || [])
        .filter((it) => (it?.fetchAmount?.() ?? 0) > 0 && classifyPotion(it, stat));
    if (!items.length) {
        entry.itemSelfId = null;
        return;
    }
    const currentIdx = items.findIndex((it) => Number(it?.fetchSelfId?.()) === Number(entry.itemSelfId));
    const nextIdx = (currentIdx + 1) % (items.length + 1);
    entry.itemSelfId = nextIdx === items.length ? null : Number(items[nextIdx].fetchSelfId());
}

function renderPanel(session) {
    const cfg = getConfig(session);
    const stats = [
        { key: 'hp', label: 'HP Potion', slot: 10 },
        { key: 'mp', label: 'MP Potion', slot: 11 },
        { key: 'cp', label: 'CP Potion', slot: 12 }
    ];

    const rows = stats.map(({ key, label, slot }) => {
        const e = cfg[key];
        const found = findPotionItem(session, key, e);
        const color = e.enabled ? '33FF66' : 'FF6666';
        const stateWord = e.enabled ? 'ON' : 'OFF';
        return `
        <tr>
            <td><font color="LEVEL">${label}</font> <font color="999999">[${slot}]</font></td>
            <td><font color="${color}">${stateWord}</font> <a action="bypass -h auto-potion toggle ${key}">[On/Off]</a></td>
            <td><font color="FFFFFF">${e.pct}%</font></td>
        </tr>
        <tr>
            <td colspan="3">
                <a action="bypass -h auto-potion pct ${key} ${clampPct(e.pct - 10)}">[-10]</a>
                <a action="bypass -h auto-potion pct ${key} ${clampPct(e.pct - 5)}">[-5]</a>
                <a action="bypass -h auto-potion pct ${key} ${clampPct(e.pct - 1)}">[-1]</a>
                <a action="bypass -h auto-potion pct ${key} ${clampPct(e.pct + 1)}">[+1]</a>
                <a action="bypass -h auto-potion pct ${key} ${clampPct(e.pct + 5)}">[+5]</a>
                <a action="bypass -h auto-potion pct ${key} ${clampPct(e.pct + 10)}">[+10]</a>
            </td>
        </tr>
        <tr>
            <td colspan="3">Item: <a action="bypass -h auto-potion cycle ${key}">${describeItem(found)}</a></td>
        </tr>`;
    }).join('');

    const masterColor = cfg.enabled ? '33FF66' : 'FF6666';
    const masterWord = cfg.enabled ? 'ON' : 'OFF';

    const html = `<html><body><center>
        <font color="LEVEL">Auto Potion (.autopot)</font><br1>
        Status: <font color="${masterColor}">${masterWord}</font> <a action="bypass -h auto-potion toggle all">[Ligar/Desligar]</a><br>
        <table width="270" cellpadding="1" cellspacing="1">${rows}</table><br>
        <font color="BBBBBB">.autopot hp 70 | .autopot mp 50 | .autopot cp 80</font>
    </center></body></html>`;

    sendHtml(session, html);
}

function handleCommand(session, rawArgs) {
    const args = String(rawArgs || '').trim().split(/\s+/).filter(Boolean);
    const cfg = getConfig(session);

    if (args.length === 0) {
        renderPanel(session);
        return true;
    }

    const first = args[0].toLowerCase();
    if (first === 'on' || first === 'off' || first === 'ligar' || first === 'desligar') {
        cfg.enabled = first === 'on' || first === 'ligar';
        renderPanel(session);
        return true;
    }

    if (['hp', 'mp', 'cp'].includes(first)) {
        const second = (args[1] || '').toLowerCase();
        if (second === 'on' || second === 'off' || second === 'ligar' || second === 'desligar') {
            cfg[first].enabled = second === 'on' || second === 'ligar';
        } else if (second !== '') {
            cfg[first].pct = clampPct(second.replace('%', ''));
            cfg[first].enabled = true;
        } else {
            cfg[first].enabled = !cfg[first].enabled;
        }
        renderPanel(session);
        return true;
    }

    renderPanel(session);
    return true;
}

function handleBypass(session, bypassInput) {
    const parts = Array.isArray(bypassInput)
        ? bypassInput.map((x) => String(x))
        : String(bypassInput || '').replace(/^bypass\s+-h\s+/i, '').trim().split(/\s+/);
    const action = (parts[1] || '').toLowerCase();
    const stat = (parts[2] || '').toLowerCase();
    const val = parts[3];
    const cfg = getConfig(session);

    if (action === 'toggle') {
        if (stat === 'all') {
            cfg.enabled = !cfg.enabled;
        } else if (cfg[stat]) {
            cfg[stat].enabled = !cfg[stat].enabled;
        }
    } else if (action === 'pct' && cfg[stat]) {
        cfg[stat].pct = clampPct(val);
        cfg[stat].enabled = true;
    } else if (action === 'cycle' && cfg[stat]) {
        cyclePotionBinding(session, stat);
    }

    renderPanel(session);
}

const potionLoop = setInterval(() => {
    try {
        const World = invoke('GameServer/World/World');
        const sessions = World?.user?.sessions;
        if (!sessions) return;
        for (const session of sessions) {
            if (!session?.actor || session.closed) continue;
            tryUsePotionForStat(session, 'hp');
            tryUsePotionForStat(session, 'mp');
            tryUsePotionForStat(session, 'cp');
        }
    } catch (_) {}
}, TICK_MS);

if (typeof potionLoop.unref === 'function') {
    potionLoop.unref();
}

function autoPotionEntry(session, input) {
    if (typeof input === 'string' && /^\s*\.autopot\b/i.test(input)) {
        return handleCommand(session, input);
    }
    return handleBypass(session, input);
}

autoPotionEntry.handleCommand = handleCommand;
autoPotionEntry.handleBypass = handleBypass;
autoPotionEntry.renderPanel = renderPanel;

module.exports = autoPotionEntry;