# Pacote de Mods: .autofarm, .autopot e .autoenchant (L2Solo)

Pasta do pacote: C:\Users\rimet\OneDrive\Desktop\meu l2\Meus mods\L2Solo-Meus-Mods

## Arquivos incluidos e onde colar
- src\GameServer\World\Generics\NpcBypasses\AutoFarm.js -> colar em <PASTA_DO_SERVIDOR>\src\GameServer\World\Generics\NpcBypasses\AutoFarm.js
- src\GameServer\World\Generics\NpcBypasses\AutoPotion.js -> colar em <PASTA_DO_SERVIDOR>\src\GameServer\World\Generics\NpcBypasses\AutoPotion.js
- src\GameServer\World\Generics\NpcBypasses\Autoenchant.js -> colar em <PASTA_DO_SERVIDOR>\src\GameServer\World\Generics\NpcBypasses\Autoenchant.js
- src\GameServer\World\Generics\AutoEnchant.js -> colar em <PASTA_DO_SERVIDOR>\src\GameServer\World\Generics\AutoEnchant.js
- src\GameServer\Network\Request\Speak.js -> colar em <PASTA_DO_SERVIDOR>\src\GameServer\Network\Request\Speak.js
- src\GameServer\World\Generics\NpcBypasses\NativeMenu.js -> colar em <PASTA_DO_SERVIDOR>\src\GameServer\World\Generics\NpcBypasses\NativeMenu.js
- src\GameServer\Enchant.js -> colar em <PASTA_DO_SERVIDOR>\src\GameServer\Enchant.js
- src\GameServer\Bot\AI\States\FollowingState.js -> colar em <PASTA_DO_SERVIDOR>\src\GameServer\Bot\AI\States\FollowingState.js
- src\GameServer\Bot\AI\States\RestingState.js -> colar em <PASTA_DO_SERVIDOR>\src\GameServer\Bot\AI\States\RestingState.js
- src\GameServer\Bot\AI\BotStatus.js -> colar em <PASTA_DO_SERVIDOR>\src\GameServer\Bot\AI\BotStatus.js
- src\GameServer\Bot\AI\PlayerPartyRaid.js -> colar em <PASTA_DO_SERVIDOR>\src\GameServer\Bot\AI\PlayerPartyRaid.js

## Como restaurar se atualizar ou sumir tudo
1. Abra a pasta raiz do servidor L2Solo (onde fica a pasta src).
2. Entre em C:\Users\rimet\OneDrive\Desktop\meu l2\Meus mods\L2Solo-Meus-Mods.
3. Copie a pasta src para dentro da raiz do servidor e substitua/mescle os arquivos.
4. Reinicie o servidor e teste .autofarm, .autopot e .autoenchant.