const FailureLog = require('../../../../FailureLog');
const refreshPartyMemberships = require('../../../World/PartyMembershipPublication');
const SpeckMath      = invoke('GameServer/SpeckMath');
const World          = invoke('GameServer/World/World');
const ServerResponse = invoke('GameServer/Network/Response');
const BotRoles       = invoke('GameServer/Bot/AI/BotRoles');
const SummonerTactics = invoke('GameServer/Bot/AI/SummonerTactics');
const BotBuffs       = invoke('GameServer/Bot/AI/BotBuffs');
const BotSkillCapabilities = invoke('GameServer/Bot/AI/BotSkillCapabilities');
const BotSupportPlanner = invoke('GameServer/Bot/AI/BotSupportPlanner');
const PartyAwareness = invoke('GameServer/Bot/AI/PartyAwareness');
const PartyCompanionService = invoke('GameServer/Bot/AI/PartyCompanionService');
const PartySupportMovement = invoke('GameServer/Bot/AI/PartySupportMovement');
const WorkflowTelemetry = invoke('GameServer/Bot/AI/BotWorkflowTelemetry');
const PartyPulling = invoke('GameServer/Bot/AI/PartyPulling');
const PartyRevivalService = invoke('GameServer/Bot/AI/PartyRevivalService');
const BotPartyChat  = invoke('GameServer/Bot/AI/BotPartyChat');
const EffectStore    = invoke('GameServer/Effects/EffectStore');
const ShotStock      = invoke('GameServer/Inventory/ShotStock');
const TradeService   = invoke('GameServer/Bot/TradeService');
const CompanionEquipmentShopping = invoke('GameServer/Bot/AI/CompanionEquipmentShopping');
const TownPathfinder = invoke('GameServer/Bot/AI/TownPathfinder');
const BotRetreatPlanner = invoke('GameServer/Bot/AI/BotRetreatPlanner');
const PartyClassTactics = invoke('GameServer/Bot/AI/PartyClassTactics');
const BotRaidSafety = invoke('GameServer/Bot/AI/BotRaidSafety');
const HotActorLodPolicy = invoke('GameServer/Bot/AI/HotActorLodPolicy');
const TownServiceCatalog = invoke('GameServer/Bot/Economy/TownServiceCatalog');
const ItemDisposition = invoke('GameServer/Bot/Economy/ItemDisposition');
const HotTownRebuff = invoke('GameServer/Bot/AI/HotTownRebuff');
const CompanionTownTransit = invoke('GameServer/Bot/AI/CompanionTownTransit');
const InventoryCleanup = require('../CompanionInventoryCleanup');
const HuntingVisibility = invoke('GameServer/Bot/AI/BotHuntingVisibility');

const FOLLOW_RUN_DISTANCE = 250;
const FOLLOW_RETARGET_DISTANCE = 900;
const FOLLOW_TARGET_DRIFT = 650;
const FOLLOW_TELEPORT_DISTANCE = 4500;
const FOLLOW_FORMATION_TOLERANCE = 45;
const STUCK_SAMPLE_INTERVAL_MS = 750;
// Aggression transfers threat; it must not consume every combat tick when
// the native transfer has not yet changed the monster's target.
const AGGRESSION_RETRY_MS = 5000;
const COMPANION_TOWN_ERRAND_RADIUS = 7500;
const COMPANION_TOWN_ERRAND_COOLDOWN_MS = 60000;
const COMPANION_EQUIPMENT_CHECK_COOLDOWN_MS = 5000;
const TOWN_CENTER_FALLBACK_RADIUS = 1500;
const STARTER_GUIDE_TOWN_RADIUS = 1500;
const CRITICAL_COMBAT_HP_RATIO = 0.25;
const PARTY_RETREAT_DISTANCE = 500;
const PARTY_RETREAT_RADIUS = 450;
const PARTY_RETREAT_REPATH_MS = 1500;
const SUPPORT_APPROACH_TIMEOUT_MS = 10000;
const SUPPORT_APPROACH_REPATH_MS = 1500;
const SUPPORT_TARGET_DRIFT = 120;

function timedFollowingStage(name, callback, items = 1) {
    if (invoke('GameServer/Bot/Population/PopulationConfig').developerDiagnostics !== true) return callback();
    const startedAt = performance.now();
    try {
        return callback();
    } finally {
        HotActorLodPolicy.recordSubsystem(`following.${name}`, performance.now() - startedAt, items);
    }
}

function ratio(value, max) {
    if (!max) return 0;
    return Math.max(0, Math.min(1, value / max));
}

function isBusy(bot) {
    return !!(bot.state.fetchTowards() || bot.state.fetchHits() || bot.state.fetchCasts());
}

function canAttemptPartyCorpseSummon(bot, partyThreat, leaderTargetId) {
    if (partyThreat || leaderTargetId || bot.state.fetchSeated?.() || isBusy(bot)) return false;

    const impairments = EffectStore.impairments(bot);
    return !impairments.disabled && !impairments.silenced && !impairments.magicMuted;
}

function preemptForPriorityHeal(session, bot) {
    if (bot.state?.fetchCasts?.()) return false;

    const towards = bot.state?.fetchTowards?.();
    const interruptibleMove = towards === 'melee' || towards === 'move';
    if (!bot.state?.fetchHits?.() && !interruptibleMove) return false;

    bot.attack?.clearTimers?.();
    bot.attack?.resetQueuedEvent?.();
    bot.state?.setHits?.(false);
    bot.automation?.abortAll?.(bot);
    session.currentTargetId = undefined;
    bot.unselect?.();
    return true;
}

function point(actor) {
    return new SpeckMath.Point3D(actor.fetchLocX(), actor.fetchLocY(), actor.fetchLocZ());
}

function loc(actor) {
    return { locX: actor.fetchLocX(), locY: actor.fetchLocY(), locZ: actor.fetchLocZ() };
}

function distance2d(a, b) {
    const dx = a.locX - b.locX;
    const dy = a.locY - b.locY;
    return Math.sqrt((dx * dx) + (dy * dy));
}

function beginNewbieGuideVisit(session, bot, playerSession, role, townVisit = null) {
    session.preBuffLocation = { locX: bot.fetchLocX(), locY: bot.fetchLocY(), locZ: bot.fetchLocZ() };
    session.preBuffPlan = 'following';
    session.resumeAfterBuff = {
        plan: 'following',
        followPlayerSession: playerSession,
        partyCompanion: true,
        botStay: session.botStay === true,
        stayLocation: session.stayLocation ? { ...session.stayLocation } : null,
        role,
        townVisitKey: townVisit?.key || null
    };
    session.plan = 'getting_buffed';
    session.currentTargetId = undefined;
    bot.unselect();
    bot.automation.abortAll(bot);
}

function townForCompanionErrand(player, BotAI) {
    const town = BotAI.getClosestTown?.(player.fetchLocX(), player.fetchLocY());
    if (!town) return null;

    const distance = distance2d(
        { locX: player.fetchLocX(), locY: player.fetchLocY() },
        { locX: town.x, locY: town.y }
    );
    if (distance > COMPANION_TOWN_ERRAND_RADIUS) return null;

    const playerLoc = {
        locX: player.fetchLocX(),
        locY: player.fetchLocY(),
        locZ: player.fetchLocZ()
    };
    // The town movement atlas is intentionally partial. Keep its precise
    // polygons where available, with a tight center fallback for towns known
    // to the respawn service. Starter villages outside that atlas are
    // recognized only beside their actual Newbie Guide, never by a broad
    // radius that also includes nearby farming fields.
    const guide = BotAI.getClosestNewbieGuide?.(player.fetchLocX(), player.fetchLocY());
    const besideStarterGuide = guide && distance2d(
        { locX: player.fetchLocX(), locY: player.fetchLocY() },
        guide
    ) <= STARTER_GUIDE_TOWN_RADIUS;
    const inTown = TownPathfinder.isInsideTown(playerLoc) || (
        distance <= TOWN_CENTER_FALLBACK_RADIUS
    ) || besideStarterGuide;

    return {
        town,
        distance,
        inTown
    };
}

function companionTownErrand(session, bot, player, BotAI) {
    const timestamp = Date.now();
    const errandOnCooldown = timestamp - Number(session.lastCompanionTownErrandAt || 0) < COMPANION_TOWN_ERRAND_COOLDOWN_MS;
    const townContext = townForCompanionErrand(player, BotAI);
    if (!townContext) return null;
    const { town, inTown } = townContext;

    // A player-led companion leaves its leader on its own only while the
    // leader is in town; in the field it fights without what it lacks until
    // the party goes to town.
    // A recalled companion (Regroup) does not restart its errand while the
    // formation holds.
    if (!inTown || PartyCompanionService.regroupActive(session.followPlayerSession)) return null;

    if (timestamp - Number(session.lastCompanionEquipmentCheckAt || 0) >= COMPANION_EQUIPMENT_CHECK_COOLDOWN_MS) {
        session.lastCompanionEquipmentCheckAt = timestamp;
        const purchase = CompanionEquipmentShopping.planErrand(session, bot, town);
        if (purchase) return purchase;
    }

    if (errandOnCooldown) return null;

    const buyer = TradeService.findBestBuyerForActor(bot, World.user?.sessions || [], {
        town,
        state: session.coldLifeState
    });
    const afkBuyer = TradeService.findAfkBuyerForActor(bot, town, session.coldLifeState);
    if (afkBuyer && (!buyer || Number(afkBuyer.score) >= Number(buyer.preview?.totalAdena || 0))) {
        return {
            kind: 'sell_resources',
            target: { ...invoke('GameServer/Bot/Economy/MarketOpportunity').offerTarget(afkBuyer.offer, town.name),
                sale: afkBuyer.sale }
        };
    }
    if (buyer) {
        return {
            kind: 'sell_resources',
            target: {
                actorId: buyer.actor.fetchId(),
                name: buyer.actor.fetchName(),
                locX: buyer.actor.fetchLocX(),
                locY: buyer.actor.fetchLocY(),
                locZ: buyer.actor.fetchLocZ(),
                town: buyer.store.town || town.name
            }
        };
    }

    const needsShots = ShotStock.needsActorRestock(bot, 0);
    const hasLoot = ItemDisposition.unreservedActorItems(
        session.coldLifeState,
        bot.backpack?.fetchItems?.() || []
    ).some((item) => !item.fetchEquipped?.()
        && Number(item.fetchSelfId?.() || 0) !== 57
        && !ShotStock.SHOT_IDS.includes(Number(item.fetchSelfId?.() || 0)));
    if (!needsShots && !hasLoot) return null;
    const shotPlan = needsShots ? ShotStock.planForActor(bot) : null;
    const target = townNpcTarget(town, bot, shotPlan?.selfId);
    if (!target) return null;
    return {
        kind: hasLoot ? 'sell_junk' : 'restock_shots',
        target
    };
}

function townNpcTarget(town, bot, selfId = 0) {
    if (ShotStock.SHOT_IDS.includes(Number(selfId))) return ShotStock.restockTarget(bot, town.name);
    const from = { locX: bot.fetchLocX(), locY: bot.fetchLocY(), locZ: bot.fetchLocZ() };
    const role = TownServiceCatalog.ROLES.GENERIC_MERCHANT;
    return TownServiceCatalog.targetFor(role, town.name, {
        selfId,
        from
    }) || TownServiceCatalog.targetNear(role, from, {
        selfId,
        maxDistance: Infinity
    });
}

function beginCompanionTownErrand(session, bot, playerSession, errand) {
    if (!errand?.target) return false;
    session.lastCompanionTownErrandAt = Date.now();
    session.preShopLocation = { locX: bot.fetchLocX(), locY: bot.fetchLocY(), locZ: bot.fetchLocZ() };
    session.resumeAfterShopping = {
        plan: 'following',
        followPlayerSession: playerSession,
        partyCompanion: true,
        botStay: session.botStay === true,
        stayLocation: session.stayLocation ? { ...session.stayLocation } : null
    };
    session.companionShopping = errand;
    session.shoppingTarget = errand.target;
    session.shoppingDoneAnnounced = false;
    session.plan = 'shopping';
    if (errand.kind === 'unload_inventory') session.shoppingServicePhase = 'warehouse';
    if (errand.kind === 'sell_unused_arrows') session.shoppingServicePhase = 'merchant';
    session.currentTargetId = undefined;
    bot.unselect();
    bot.automation.abortAll(bot);

    const detail = errand.kind === 'dual_component_withdrawal'
        ? 'vender esses recursos para ${errand.target.name}'
        : errand.kind === 'dual_sword_combine'
            ? `vender meu loot em ${errand.target.name}`
            : ['market_purchase', 'npc_equipment_purchase'].includes(errand.kind)
        ? `${errand.itemName} from ${errand.target.name}`
        : errand.kind === 'sell_resources'
            ? `vender flechas paradas para ${errand.target.name}`
            : errand.kind === 'sell_junk'
                ? `sell my loot at ${errand.target.name}`
                : errand.kind === 'unload_inventory'
                    ? `store excess weight with ${errand.target.name}`
                    : errand.kind === 'sell_unused_arrows'
                        ? `sell unused arrows to ${errand.target.name}`
                        : 'Vou ${detail} enquanto estamos aqui.';
    BotPartyChat.announce(session, {
        priority: 'informational',
        key: `town-errand:${bot.fetchId()}:${errand.kind}`,
        templates: [
            `Parada rapida na cidade: ${detail}.`,
            `Deixa eu ${detail}; nao demoro.`,
            `I'll ${detail} while we're here.`,
            `One town stop: ${detail}.`,
            `Let me ${detail}; I won't be long.`,
            `Handling a quick errand — ${detail}.`
        ]
    });
    return true;
}

function shouldKeepCurrentFollowMove(session, bot, player, leaderDistance) {
    const isMoving = !!session.moveTimer || bot.state.fetchTowards();
    if (!isMoving) return false;
    if ((session.stuckTicks || 0) >= 2) return false;
    if (
        bot.state.fetchTowards() === 'remote' &&
        Number(session.pendingSupportCast?.expiresAt || 0) > Date.now()
    ) {
        return true;
    }
    if (leaderDistance > FOLLOW_RETARGET_DISTANCE) return false;

    const target = session.lastFollowMoveTarget;
    if (!target) return false;
    if (['healer', 'buffer'].includes(BotRoles.inferRole(bot))) {
        const currentTarget = PartySupportMovement.followDestination(session, bot, followTargetFor(session, player));
        return !!currentTarget && distance2d(target, currentTarget) <= PartySupportMovement.TARGET_DRIFT;
    }
    return distance2d(target, loc(player)) <= FOLLOW_TARGET_DRIFT;
}

function stopFollowMove(session, bot) {
    const hadFollowMove = !!session.lastFollowMoveTarget;
    session.lastFollowMoveTarget = null;
    if (hadFollowMove && (session.moveTimer || bot.state?.fetchTowards?.()) &&
        !bot.state?.fetchHits?.() && !bot.state?.fetchCasts?.() && !session.pendingSupportApproach &&
        bot.state?.fetchTowards?.() !== 'remote') {
        bot.automation?.abortAll?.(bot);
    }
}

function stopSupportMelee(bot) {
    if (bot.state?.fetchCasts?.() || (!bot.state?.fetchHits?.() && bot.state?.fetchTowards?.() !== 'melee')) return;
    bot.attack?.clearTimers?.();
    bot.attack?.resetQueuedEvent?.();
    bot.state?.setHits?.(false);
    bot.automation?.abortAll?.(bot);
}

function standUp(session, bot) {
    if (!bot.state.fetchSeated()) return false;
    bot.state.setSeated(false);
    session.dataSendToOthers(ServerResponse.sitAndStand(bot), bot);
    return true;
}

function sitDown(session, bot) {
    if (bot.state.fetchSeated()) return false;
    bot.state.setSeated(true);
    session.dataSendToOthers(ServerResponse.sitAndStand(bot), bot);
    return true;
}

function roleDecisionSignature(decision) {
    return [
        decision?.role,
        decision?.action,
        decision?.reason,
        decision?.targetId,
        decision?.protectedId,
        decision?.threatSource,
        decision?.phase
    ].map((value) => value ?? '').join(':');
}

function recordRoleDecision(session, bot, action, reason, extra = {}) {
    const role = BotRoles.inferRole(bot);
    const previous = session.roleDecision;
    const current = {
        role,
        action,
        reason,
        at: Date.now(),
        ...extra
    };

    session.roleDecision = current;

    if (!(invoke('GameServer/Bot/Population/PopulationConfig').developerDiagnostics === true)) return;
    const signature = roleDecisionSignature(current);
    const shouldLog = !previous ||
        roleDecisionSignature(previous) !== signature ||
        current.at - (session.lastRoleDecisionLogAt || 0) > 10000;

    if (shouldLog) {
        session.lastRoleDecisionLogAt = current.at;
        const details = [
            current.targetId !== undefined && `target=${current.targetId}`,
            current.protectedId !== undefined && `protected=${current.protectedId}`,
            current.threatSource && `source=${current.threatSource}`,
            current.phase && `phase=${current.phase}`
        ].filter(Boolean).join(' ');
        if (invoke('GameServer/Bot/Population/PopulationConfig').developerDiagnostics === true) console.info("BotRole :: %s %s/%s (%s)%s", bot.fetchName(), action, reason, role, details ? ` ${details}` : '');
    }
}

function castSkillOn(session, bot, Generics, target, skill, ctrl, announcement = null) {
    session.currentTargetId = target.fetchId();
    bot.select({ id: target.fetchId() });
    if (announcement) {
        BotPartyChat.expectSkillResult(session, {
            target,
            skill,
            ...announcement
        });
    }
    Generics.skillExec(session, bot, { id: target.fetchId(), selfId: skill.fetchSelfId(), ctrl });
}

function clearPendingSupportApproach(session, bot, { abortMove = false } = {}) {
    if (!session.pendingSupportApproach) return false;
    session.pendingSupportApproach = undefined;
    if (abortMove && bot.state?.fetchTowards?.() && !bot.state?.fetchHits?.() && !bot.state?.fetchCasts?.()) {
        bot.automation?.abortAll?.(bot);
    }
    return true;
}

function supportCastRange(skill) {
    const skillDistance = Number(skill.fetchDistance?.()) || 0;
    const partyAura = ['party', 'ally'].includes(skill.fetchTargetKind?.()) && skillDistance < 0;
    return partyAura ? (Number(skill.fetchSemantic?.()?.radius) || Infinity) : Math.max(0, skillDistance);
}

function queueSupportSkillOn(session, bot, Generics, target, skill, ctrl, kind, announcement = null, { allowApproach = true } = {}) {
    const castRange = supportCastRange(skill);
    if (point(bot).distance(point(target)) <= castRange) {
        clearPendingSupportApproach(session, bot, { abortMove: true });
        castSkillOn(session, bot, Generics, target, skill, ctrl, announcement);
        return 'cast';
    }

    const now = Date.now();
    const targetLoc = loc(target);
    const destination = allowApproach
        ? PartySupportMovement.supportDestination(session, bot, target, castRange)
        : null;
    if (!destination) {
        clearPendingSupportApproach(session, bot, { abortMove: true });
        BotSupportPlanner.cancelSupportCast(session, bot);
        session.returnToPartyAfterSupport = true;
        return 'blocked';
    }
    const pending = session.pendingSupportApproach;
    const sameAction = pending &&
        Number(pending.targetId) === Number(target.fetchId()) &&
        Number(pending.skillId) === Number(skill.fetchSelfId());
    const targetDrift = sameAction && pending.targetLoc
        ? distance2d(pending.targetLoc, targetLoc)
        : Infinity;
    const shouldRepath = !sameAction ||
        !session.moveTimer ||
        !bot.state?.fetchTowards?.() ||
        targetDrift > SUPPORT_TARGET_DRIFT ||
        now - Number(pending.lastMoveAt || 0) >= SUPPORT_APPROACH_REPATH_MS;

    session.pendingSupportApproach = {
        targetId: target.fetchId(),
        skillId: skill.fetchSelfId(),
        ctrl,
        kind,
        announcement,
        startedAt: sameAction ? pending.startedAt : now,
        lastMoveAt: shouldRepath ? now : pending.lastMoveAt,
        targetLoc
    };

    if (shouldRepath) {
        session.lastFollowMoveTarget = null;
        bot.moveTo({ from: loc(bot), to: destination,
            routeGuard: PartySupportMovement.routeGuard(session, bot, destination) });
    }
    return 'approach';
}

function resumePendingSupportApproach(session, bot, Generics, leaderSession) {
    const pending = session.pendingSupportApproach;
    if (!pending) return null;

    const targetSession = PartyAwareness.partySessions(leaderSession).find((memberSession) => (
        Number(memberSession.actor?.fetchId?.()) === Number(pending.targetId)
    ));
    const target = targetSession?.actor;
    const skill = bot.skillset?.fetchSkill?.(pending.skillId);
    if (!target || target.isDead?.() || !skill || Date.now() - pending.startedAt > SUPPORT_APPROACH_TIMEOUT_MS) {
        clearPendingSupportApproach(session, bot, { abortMove: true });
        BotSupportPlanner.cancelSupportCast(session, bot);
        return { handled: false, expired: true };
    }

    const result = queueSupportSkillOn(
        session,
        bot,
        Generics,
        target,
        skill,
        pending.ctrl,
        pending.kind,
        pending.announcement
    );
    return { handled: result !== 'blocked', action: result, target, skill, kind: pending.kind };
}

function canAttemptAggression(session, target) {
    const previous = session.lastAggressionAttempt;
    const targetId = Number(target?.fetchId?.() || 0);
    const protectedId = Number(target?.fetchDestId?.() || 0);
    return !previous ||
        previous.targetId !== targetId ||
        previous.protectedId !== protectedId ||
        Date.now() - previous.at >= AGGRESSION_RETRY_MS;
}

function rememberAggressionAttempt(session, target) {
    session.lastAggressionAttempt = {
        targetId: Number(target.fetchId()),
        protectedId: Number(target.fetchDestId?.() || 0),
        at: Date.now()
    };
}

function canHealParty(bot, leaderSession) {
    const role = BotRoles.inferRole(bot);
    if (role === 'healer') return true;
    // A living healer owns this job; otherwise buffers cover it using only
    // their learned healing skills, without changing their party role.
    return role === 'buffer' && BotSkillCapabilities.healSkills(bot).length > 0
        && !PartyAwareness.partyActors(leaderSession).some((actor) => BotRoles.isHealer(actor));
}

function pendingSupportShouldYield(session, bot, leaderSession, pullerActor, partyThreat) {
    const pending = session.pendingSupportApproach;
    if (!pending) return false;

    const targetSession = PartyAwareness.partySessions(leaderSession).find((memberSession) => (
        Number(memberSession.actor?.fetchId?.()) === Number(pending.targetId)
    ));
    const target = targetSession?.actor;
    if (!target || target.isDead?.()) return true;

    const targetHpRatio = ratio(target.fetchHp(), target.fetchMaxHp());
    const targetMpRatio = ratio(target.fetchMp(), target.fetchMaxMp());
    const fallbackGroup = BotRoles.inferRole(bot) === 'buffer';
    const pendingHeal = ['top_off', 'group_heal', 'emergency_heal', 'self_preservation'].includes(pending.kind);
    if (pendingHeal && !canHealParty(bot, leaderSession)) return true;
    if (pendingHeal && targetHpRatio >= 0.70) return true;
    if (pendingHeal && !BotSkillCapabilities.selectHealSkill(bot, {
        target, group: pending.kind === 'group_heal', fallbackGroup
    })) return true;
    if (pending.kind === 'restore_mp' && targetMpRatio >= 0.55) return true;
    if (partyThreat && pending.kind === 'restore_mp') return true;
    if (partyThreat && String(pending.kind || '').startsWith('buff:')) return true;

    if (!canHealParty(bot, leaderSession)) return false;
    const canHealTarget = target => [false, true].some(emergency => {
        const skill = BotSkillCapabilities.selectHealSkill(bot, { target, emergency, fallbackGroup });
        return skill && bot.canUseSkill?.(skill) !== false && bot.fetchMp() >= skill.fetchConsumedMp();
    });
    const emergency = weakestPartyMember(leaderSession, bot, pullerActor, 900, canHealTarget);
    if (emergency?.hpRatio < 0.45) return (
        pending.kind !== 'emergency_heal' ||
        Number(pending.targetId) !== Number(emergency.actor.fetchId())
    );
    return ratio(bot.fetchHp(), bot.fetchMaxHp()) < 0.55 && canHealTarget(bot) &&
        Number(pending.targetId) !== Number(bot.fetchId());
}

function partyActorIds(leaderSession) {
    return new Set(PartyAwareness.combatActors(leaderSession)
        .map((actor) => actor.fetchId())
        .filter((id) => id !== null && id !== undefined));
}

function partyAggroMonsters(leaderSession) {
    return timedFollowingStage('partyAggro', () => {
        const ids = partyActorIds(leaderSession);
        if (ids.size === 0) return [];

        const seen = new Set();
        return PartyAwareness.combatActors(leaderSession).flatMap((actor) => (
            // Match PartyAwareness' full NPC combat envelope. A ranged mob can
            // continue attacking from beyond the old 900-unit support check.
            World.fetchNpcsInRadius(actor.fetchLocX(), actor.fetchLocY(), 1500)
        ))
            .filter((npc) => {
                const id = npc.fetchId?.() || npc;
                if (seen.has(id)) return false;
                seen.add(id);
                return true;
            })
            .filter((npc) => !BotRaidSafety.isProtectedRaidEntity(npc) || BotRaidSafety.isEngagedPlayerPartyRaidTarget(leaderSession, npc))
            .filter((npc) => npc.fetchAttackable() && !npc.isDead() && ids.has(npc.fetchDestId()));
    });
}

function unsafeSupportMoment(bot, activeMobs) {
    // A selected target is not combat. Both the leader and companions retain
    // target ids after inspecting a creature or after a completed cast; using
    // those ids here made an idle party wait forever to refresh its buffs.
    // Only an NPC actually targeting the party, or this bot's active native
    // action, is unsafe for support.
    return activeMobs > 0 || isBusy(bot);
}

function canRefreshPartyMusicDuringCombat(bot, action, partyThreat, partyRaid, botVitals, partyVitals, healerNeedsAction) {
    if (!BotSupportPlanner.isUrgentPartyMusicRefresh(action)) return false;
    if (isBusy(bot) || healerNeedsAction) return false;
    if (partyRaid?.phase === 'combat' || partyThreat?.type === 'player') return false;
    if (Number(partyThreat?.targetId || 0) === Number(bot.fetchId?.() || 0)) return false;
    if (Number(botVitals?.hpRatio || 0) < 0.70 || Number(partyVitals?.hpRatio || 0) < 0.70) return false;
    return true;
}

function partyMembersInSupportRange(leaderSession, bot, maxDistance = 900) {
    return PartyAwareness.partySessions(leaderSession)
        .filter((memberSession) => memberSession.actor && !memberSession.actor.isDead?.())
        .map((memberSession) => ({
            session: memberSession,
            actor: memberSession.actor,
            hpRatio: ratio(memberSession.actor.fetchHp(), memberSession.actor.fetchMaxHp()),
            mpRatio: ratio(memberSession.actor.fetchMp(), memberSession.actor.fetchMaxMp()),
            distance: point(bot).distance(point(memberSession.actor))
        }))
        .filter((entry) => entry.distance <= maxDistance);
}

function weakestPartyMember(leaderSession, bot, preferredActor = null, maxDistance = 900, eligible = () => true) {
    const members = partyMembersInSupportRange(leaderSession, bot, maxDistance)
        .filter((entry) => entry.actor !== bot && eligible(entry.actor))
        .sort((a, b) => a.hpRatio - b.hpRatio);
    const preferred = members.find((entry) => entry.actor === preferredActor);
    return preferred?.hpRatio < 0.95 ? preferred : (members[0] || null);
}

function weakestPartyVitals(leaderSession, bot) {
    return partyMembersInSupportRange(leaderSession, bot)
        .reduce((lowest, entry) => !lowest || entry.hpRatio < lowest.hpRatio ? entry : lowest, null);
}

function partySupportMembers(leaderSession, puller) {
    return PartyPulling.supportMembers(leaderSession, puller);
}

function announceUnexpectedNpcAdd(session, bot, leaderSession, partyThreat, leaderTargetId) {
    if (
        partyThreat?.type !== 'npc' ||
        partyThreat.source === 'party_pull' ||
        Number(partyThreat.actor?.fetchId?.() || 0) === Number(leaderTargetId || 0)
    ) {
        return false;
    }

    const protectedSession = PartyAwareness.partySessions(leaderSession).find((memberSession) => (
        Number(memberSession.actor?.fetchId?.() || 0) === Number(partyThreat.targetId || 0)
    ));
    const protectedActor = protectedSession?.actor;
    if (!protectedActor || protectedActor === bot) return false;

    const protectedRole = protectedSession === leaderSession ? 'leader' : BotRoles.inferRole(protectedActor);
    if (protectedRole !== 'leader' && protectedRole !== 'healer' && protectedRole !== 'buffer') return false;

    return BotPartyChat.announceNpcAdd(session, partyThreat.actor, protectedActor);
}

function moveToFollowTarget(session, bot, player) {
    const support = ['healer', 'buffer'].includes(BotRoles.inferRole(bot));
    const formation = followTargetFor(session, player);
    const followTarget = support ? PartySupportMovement.followDestination(session, bot, formation) : formation;
    // Formation positions are deliberately offset from the leader.  Comparing
    // only against the leader made a bot repeatedly path to its current
    // position once it had reached that offset.
    if (!followTarget || distance2d(loc(bot), followTarget) <= FOLLOW_FORMATION_TOLERANCE) {
        stopFollowMove(session, bot);
        return false;
    }
    session.lastFollowMoveTarget = followTarget;
    bot.moveTo({
        from: { locX: bot.fetchLocX(), locY: bot.fetchLocY(), locZ: bot.fetchLocZ() },
        to: followTarget,
        targetActor: player,
        ...(support ? { routeGuard: PartySupportMovement.routeGuard(session, bot, followTarget) } : {})
    });
    return true;
}

function retreatFromThreat(session, bot, threat, player, rooted) {
    const retreatGoal = session.lastRetreatPlan?.to;
    const goalNearParty = !retreatGoal || Math.hypot(retreatGoal.locX - player.fetchLocX(), retreatGoal.locY - player.fetchLocY()) <= PARTY_RETREAT_RADIUS + 1;
    const retreatInProgress = Date.now() < Number(session.partyRetreatUntil || 0) &&
        (!!session.moveTimer || bot.state?.fetchTowards?.()) && goalNearParty;
    session.currentTargetId = undefined;
    bot.unselect();
    bot.attack?.abortCast?.(session, bot);
    bot.attack?.clearTimers?.();
    bot.state?.setHits?.(false);

    // Damage wakeups can run this state several times before a 500-unit route
    // completes. Keep the existing escape movement instead of cancelling it
    // and returning without a replacement route on every cooldown tick.
    if (retreatInProgress) return true;
    const previous = session.lastRetreatPlan;
    if (Date.now() < Number(session.partyRetreatUntil || 0) && previous?.partyMovementAllowed === false
        && previous.threatId === threat.fetchId()
        && Math.hypot(previous.partyAnchor.locX - player.fetchLocX(), previous.partyAnchor.locY - player.fetchLocY()) < 64) return false;

    bot.automation?.abortAll?.(bot);
    if (rooted) return false;

    const retreat = BotRetreatPlanner.retreat(session, bot, threat, {
        distance: PARTY_RETREAT_DISTANCE,
        preferredPoint: player,
        partyAnchor: player,
        partyRadius: PARTY_RETREAT_RADIUS
    });
    session.partyRetreatUntil = Date.now() + PARTY_RETREAT_REPATH_MS;
    session.lastFollowMoveTarget = retreat.to;
    return retreat.partyMovementAllowed !== false;
}

function manaPriority(entry, pullerActor) {
    const role = BotRoles.inferRole(entry.actor);
    if (entry.actor === pullerActor) return 0;
    if (role === 'buffer') return 1;
    if (role === 'healer') return 2;
    if (role === 'mage') return 3;
    if (role === 'archer') return 4;
    return 5;
}

function rechargeThreshold(entry, pullerActor, emergencyTankOnly) {
    const role = BotRoles.inferRole(entry.actor);
    if (role === 'tank') return emergencyTankOnly ? 0.20 : (entry.actor === pullerActor ? 0.35 : 0.30);
    return 0.55;
}

function lowestManaPartyMember(leaderSession, bot, pullerActor = null, maxDistance = 900, { emergencyTankOnly = false } = {}) {
    return partyMembersInSupportRange(leaderSession, bot, maxDistance)
        .filter((entry) => entry.actor !== bot)
        .filter((entry) => BotRoles.needsPartyManaRecovery(entry.actor))
        .filter((entry) => !emergencyTankOnly || BotRoles.inferRole(entry.actor) === 'tank')
        .filter((entry) => entry.mpRatio < rechargeThreshold(entry, pullerActor, emergencyTankOnly))
        .sort((a, b) => (
            manaPriority(a, pullerActor) - manaPriority(b, pullerActor) ||
            a.mpRatio - b.mpRatio ||
            Number(a.actor.fetchId()) - Number(b.actor.fetchId())
        ))[0] || null;
}

function markPartyRecharge(leaderSession, bot, target, skill) {
    const castMs = Number(skill?.fetchCalculatedHitTime?.() || skill?.fetchHitTime?.() || 0);
    leaderSession.partyRecoveryCast = {
        providerId: bot.fetchId(),
        targetId: target.fetchId(),
        expiresAt: Date.now() + Math.max(1000, castMs + 1000)
    };
}

function returnToPartyAfterSupport(session, bot, player, target) {
    // A remote heal/buff may have made the support bot walk far away from the
    // formation.  The native cast owns that movement until the hit lands; the
    // next idle tick must head back to the leader instead of beginning combat
    // around the assisted target.
    if (point(target).distance(point(player)) > FOLLOW_RUN_DISTANCE) {
        session.returnToPartyAfterSupport = true;
    }
}

function activeBotPullTravel(session, pulling) {
    return pulling?.enabled === true &&
        pulling.puller?.session === session &&
        pulling.puller.kind === 'bot' &&
        ['approach', 'return'].includes(pulling.phase);
}

function pullBlockReason(session, botVitals, partyVitals, activeMobs, partySettings) {
    // pullMode is authoritative. autoTaunt is only a per-session mirror and
    // can briefly be stale after party/session lifecycle changes.
    if (partySettings?.pullMode === 'off' || session.autoTaunt === false) return 'manual_pull_off';
    if (session.botStay) return 'stay_order';
    if (session.currentTargetId) return 'already_assisting';
    if (partyVitals?.hpRatio < 0.65) return 'party_low_hp';
    if (botVitals.hpRatio < 0.55) return 'tank_low_hp';
    if (activeMobs >= 2) return 'active_mobs';
    return null;
}

function assistActionForRole(role) {
    if (role === 'archer' || role === 'mage') return 'ranged_assist';
    if (role === 'buffer') return 'buff_support';
    if (role === 'dagger') return 'flank_target';
    return 'assist_leader';
}

function supportCanMeleeAssist(bot, role) {
    return !BotRoles.isPartyCasterSupport(bot) &&
        (!['healer', 'buffer'].includes(role) || BotRoles.hasMeleeWeapon(bot));
}

function assistReasonForRole(role) {
    if (role === 'dagger') return 'close_assist';
    return 'leader_target';
}

function followTargetFor(session, player) {
    return PartyCompanionService.formationTargetFor(session) || {
        locX: player.fetchLocX(),
        locY: player.fetchLocY(),
        locZ: player.fetchLocZ()
    };
}

function deliverPurchasedResources(session, bot, playerSession) {
    const delivery = session.pendingResourceDelivery;
    if (!delivery) return false;
    if (delivery.playerSession !== playerSession || Number(delivery.playerId) !== Number(playerSession.actor?.fetchId?.())) {
        session.pendingResourceDelivery = undefined;
        return false;
    }
    if (delivery.tradeId && session.activeTrade?.id === delivery.tradeId) {
        recordRoleDecision(session, bot, 'deliver_resources', 'trade_pending_confirmation', { targetId: delivery.playerId });
        return true;
    }
    if (Number(delivery.retryAt || 0) > Date.now()) return false;
    if (point(bot).distance(point(playerSession.actor)) > 350) {
        if (!bot.state?.fetchTowards?.()) {
            bot.moveTo({ from: loc(bot), to: loc(playerSession.actor) });
        }
        recordRoleDecision(session, bot, 'deliver_resources', 'return_to_leader', { targetId: delivery.playerId });
        return true;
    }
    let partyThreat = null;
    try { partyThreat = PartyAwareness.findThreatTargetingPartyProjected(playerSession); } catch (error) { FailureLog.note('ai.follow_threat', error); }
    const leaderBusy = !!(
        playerSession.actor.state?.fetchHits?.() ||
        playerSession.actor.state?.fetchCasts?.() ||
        playerSession.actor.state?.fetchCombats?.()
    );
    if (partyThreat || leaderBusy) {
        const now = Date.now();
        if (now - Number(session.resourceTradeWaitAnnouncedAt || 0) > 15000) {
            session.resourceTradeWaitAnnouncedAt = now;
            BotPartyChat.announce(session, {
                priority: 'informational',
                key: `resource-delivery-wait:${bot.fetchId()}:${delivery.purchasedAt}`,
                templates: ['I have the supplies. I will open trade as soon as the party is safe.']
            });
        }
        recordRoleDecision(session, bot, 'deliver_resources', 'wait_for_safe_trade', { targetId: delivery.playerId });
        return false;
    }
    const trade = invoke('GameServer/Bot/BotTradeService').startBotTradeWithOffer(
        session,
        playerSession,
        delivery.objectId,
        delivery.amount,
        { workflowId: delivery.workflowId, supplyDelivery: true }
    );
    if (!trade.ok) {
        if (trade.reason === 'too_far') return false;
        delivery.retryAt = Date.now() + 10000;
        BotPartyChat.announce(session, {
            priority: 'informational',
            key: `resource-delivery-failed:${bot.fetchId()}:${delivery.purchasedAt}`,
            templates: [`Peguei os suprimentos. Abro trade assim que a party estiver segura.`]
        });
        if (invoke('GameServer/Bot/Population/PopulationConfig').developerDiagnostics === true) WorkflowTelemetry.recordSupply(delivery.workflowId, 'trade', {
            botId: bot.fetchId(),
            playerId: delivery.playerId,
            amount: delivery.amount
        }, 'failed', trade.reason || 'trade_open_failed', { terminal: false });
        return false;
    }
    delivery.tradeId = trade.trade?.id || trade.id || null;
    delivery.retryAt = undefined;
    BotPartyChat.announce(session, {
        priority: 'informational',
        key: `resource-delivery:${bot.fetchId()}:${delivery.purchasedAt}`,
        templates: [`Trouxe ${delivery.itemName}, mas nao consegui abrir trade (${trade.reason}).`]
    });
    if (invoke('GameServer/Bot/Population/PopulationConfig').developerDiagnostics === true) WorkflowTelemetry.recordSupply(delivery.workflowId, 'trade', {
        botId: bot.fetchId(),
        playerId: delivery.playerId,
        amount: delivery.amount,
        objectId: delivery.objectId
    }, 'pending', 'native_trade_open');
    recordRoleDecision(session, bot, 'deliver_resources', 'native_trade_open', { targetId: delivery.playerId });
    return true;
}

const FollowingState = {
    deliverPurchasedResources,
    canRefreshPartyMusicDuringCombat,
    canAttemptPartyCorpseSummon,

    tick(session, bot, Generics, BotAI) {
        // One companion tick: the phases below run in this order and share
        // the per-call ctx. A phase that returns true has ended the tick.
        const ctx = { session, bot, Generics, BotAI };
        if (FollowingState.tickLeaderPresence(ctx)) return;
        if (FollowingState.tickLeaderRevival(ctx)) return;
        if (FollowingState.tickPartyContext(ctx)) return;
        if (FollowingState.tickCorpseSummonAndDisable(ctx)) return;
        if (FollowingState.tickTravel(ctx)) return;
        if (FollowingState.tickPendingSupport(ctx)) return;
        if (FollowingState.tickInventoryCleanup(ctx)) return;
        if (FollowingState.tickRest(ctx)) return;
        if (FollowingState.tickBuffsAndErrands(ctx)) return;
        if (FollowingState.tickSupportAndHealing(ctx)) return;
        if (invoke('GameServer/Bot/AI/ClanCommandParty').handleMovement(session, bot)) return;
        if (FollowingState.tickDefenseAndPull(ctx)) return;
        FollowingState.tickCombat(ctx);
        FollowingState.tickLootAndLeaderTarget(ctx);
        FollowingState.tickIdleFollow(ctx);
    },

    // The companion still belongs to a party with an online leader.
    tickLeaderPresence(ctx) {
        const { session, BotAI } = ctx;
        const playerSession = session.followPlayerSession;
        const commandGroup = invoke('GameServer/Bot/AI/ClanCommandParty').groupFor(session);
        if (commandGroup && !invoke('GameServer/Bot/AI/ClanCommandParty').current(commandGroup)) {
            invoke('GameServer/Bot/AI/ClanCommandParty').dismiss(commandGroup);
            return true;
        }
        if (session.partyCompanion !== true) {
            session.plan = 'hunting';
            session.followPlayerSession = null;
            session.roleDecision = null;
            refreshPartyMemberships([session], invoke);
            return true;
        }

        if (!playerSession || !playerSession.actor || !playerSession.actor.fetchIsOnline()) {
            session.plan = 'hunting';
            session.roleDecision = null;
            BotAI.say(session, "My companion has disconnected. Heading back to hunt.");
            return true;
        }
        Object.assign(ctx, { playerSession });
        return false;
    },

    // Party raid hand-off, leader resurrection, waiting for it, purchased-resource delivery.
    tickLeaderRevival(ctx) {
        const { session, bot, Generics, BotAI, playerSession } = ctx;
        const player = playerSession.actor;
        if (invoke('GameServer/Bot/AI/PlayerPartyRaid').tick(session, bot, Generics, BotAI)) return true;
        if (player.isDead?.()) {
            // Do this before the provider is selected: a solo healer can be
            // the first and only companion tick after the leader dies.
            PartyPulling.cancelForRevival(playerSession);
        }
        // Resurrection is autonomous.  It must win over follow/catch-up and
        // over a stale pull target; chat is only conversation, never a switch
        // required to make companions revive their leader.
        const revival = timedFollowingStage('revival', () => (
            PartyRevivalService.tick(session, playerSession, Generics)
        ));
        if (revival.handled) {
            recordRoleDecision(session, bot, 'resurrect_party', revival.source || 'waiting', {
                targetId: revival.target?.fetchId?.() || revival.targetId || null
            });
            return true;
        }
        if (player.isDead?.()) {
            if (!revival.blockedBy) {
                session.currentTargetId = undefined;
                bot.unselect();
                bot.attack?.abortCast?.(session, bot);
                bot.attack?.clearTimers?.();
                bot.state?.setHits?.(false);
                bot.state?.setCasts?.(false);
                bot.automation?.abortAll?.(bot);
            }
            recordRoleDecision(
                session,
                bot,
                'wait_for_resurrection',
                revival.blockedBy ? `blocked_${revival.blockedBy}` : 'awaiting_resurrection',
                { targetId: player.fetchId() }
            );
            // During an actual fight, leave the normal combat branch active
            // so the living party can finish it. Once it clears, the next tick
            // immediately schedules the prioritized leader resurrection.
            if (!revival.blockedBy) return true;
        }
        if (!player.isDead?.() && deliverPurchasedResources(session, bot, playerSession)) return true;
        Object.assign(ctx, { player });
        return false;
    },

    // Role, distance, party settings, pull state and the threat this companion answers; protected raid retreat.
    tickPartyContext(ctx) {
        const { session, bot, playerSession, player } = ctx;
        const role = BotRoles.inferRole(bot);
        const distance = point(bot).distance(point(player));
        const leaderSeated = player.state?.fetchSeated?.() === true;
        const restFormationTarget = leaderSeated ? followTargetFor(session, player) : null;
        const restFormationDistance = restFormationTarget
            ? distance2d(loc(bot), restFormationTarget)
            : distance;
        const partySettings = PartyCompanionService.getSettings(playerSession);
        const combatMode = partySettings.combatMode || 'assist';
        const partyRaid = timedFollowingStage('raidContext', () => (
            BotRaidSafety.syncPlayerPartyRaid(playerSession)
        ));
        if (partyRaid) PartyPulling.cancel(playerSession);
        const selectedLeaderTargetId = PartyAwareness.leaderCombatTargetId(playerSession);
        // A player-designated pull is intentional even when the ordinary
        // combat posture is Protect or Passive.  Those modes should not make
        // the party ignore the leader's selected pull target.
        const configuredLeaderTargetId = combatMode === 'assist' || partySettings.pullMode === 'leader'
            ? selectedLeaderTargetId
            : undefined;
        let pulling = timedFollowingStage('pullContext', () => {
            PartyPulling.observeLeaderTarget(playerSession, partySettings, configuredLeaderTargetId);
            return PartyPulling.current(playerSession, partySettings);
        });
        if (partyRaid) {
            pulling = { enabled: false, target: null, puller: null, engageable: false, phase: null };
        }
        let rawPartyThreat = PartyAwareness.findThreatTargetingPartyProjected(playerSession);
        session.partyCombatLootReadyAt = 0;
        // The party projection may prefer the puller's mob. Personal incoming
        // hits or an NPC actively targeting this support still require defense.
        // Hate alone is insufficient: the tank may already own that attacker.
        const personalSupportThreat = ['healer', 'buffer'].includes(role)
            ? PartyAwareness.recentIncomingNpc(session, 1500)
                || World.fetchNpcsInRadius(bot.fetchLocX(), bot.fetchLocY(), 1500).find(npc =>
                    npc.fetchAttackable?.() && !npc.isDead?.()
                    && Number(npc.fetchDestId?.()) === Number(bot.fetchId()))
            : null;
        if (personalSupportThreat) rawPartyThreat = {
            type: BotRaidSafety.isProtectedRaidEntity(personalSupportThreat) ? 'raid' : 'npc',
            actor: personalSupportThreat, targetId: bot.fetchId(), source: 'personal_attack'
        };
        if (rawPartyThreat?.type === 'raid' && !BotRaidSafety.canEngagePlayerPartyRaid(
            session,
            rawPartyThreat.actor,
            playerSession
        )) {
            PartyPulling.cancel(playerSession);
            if (BotRaidSafety.retreat(session, bot, rawPartyThreat.actor)) {
                recordRoleDecision(session, bot, 'retreat', 'raid_entity_protected', {
                    targetId: rawPartyThreat.actor.fetchId?.() || null,
                    protectedId: rawPartyThreat.targetId || null
                });
            }
            return true;
        }
        if (rawPartyThreat?.type === 'raid') {
            // Engagement may have become authoritative after threat discovery.
            // The selected opener (opening) and matching party members (combat)
            // must flow through the ordinary assist path, never raid retreat.
            rawPartyThreat = { ...rawPartyThreat, type: 'npc' };
        }
        const holdingPulledTarget = pulling.target && !pulling.engageable;
        const rawThreatIsHeldPull = holdingPulledTarget &&
            Number(rawPartyThreat?.actor?.fetchId?.()) === Number(pulling.target.fetchId());
        // While the puller is away from camp, mobs attacking only that puller
        // are part of the delivery, not a signal for the whole formation to
        // run out. Once the puller returns (or becomes critical), ranged adds
        // remain normal threats and the party will go finish them.
        const pullerAwayFromCamp = PartyPulling.travellingPullerAwayFromCamp(playerSession, pulling);
        const rawThreatOnlyTargetsTravellingPuller = pullerAwayFromCamp &&
            Number(rawPartyThreat?.targetId || 0) === Number(pulling.puller?.actor?.fetchId?.() || 0) &&
            ratio(pulling.puller.actor.fetchHp(), pulling.puller.actor.fetchMaxHp()) >= CRITICAL_COMBAT_HP_RATIO;
        let partyThreat = personalSupportThreat ? rawPartyThreat : pulling.engageable && pulling.target
            ? {
                type: 'npc',
                actor: pulling.target,
                targetId: pulling.puller.actor.fetchId(),
                source: 'party_pull'
            }
            : (rawThreatIsHeldPull || rawThreatOnlyTargetsTravellingPuller || (combatMode === 'passive' && rawPartyThreat?.targetId !== bot.fetchId())
            ? null
            : rawPartyThreat);
        let partyAggroCache = null;
        const currentPartyAggroMonsters = () => {
            if (partyAggroCache === null) partyAggroCache = partyAggroMonsters(playerSession);
            return partyAggroCache;
        };
        const leaderTargetId = partyRaid?.phase === 'combat'
            ? Number(partyRaid.targetId || partyRaid.bossId)
            : (pulling.enabled ? undefined : configuredLeaderTargetId);
        Object.assign(ctx, { role, distance, leaderSeated, restFormationDistance, partySettings, partyRaid, pulling, personalSupportThreat, rawThreatOnlyTargetsTravellingPuller, partyThreat, currentPartyAggroMonsters, leaderTargetId });
        return false;
    },

    // Necromancer corpse summon, unexpected-add announcement, hard disable.
    tickCorpseSummonAndDisable(ctx) {
        const { session, bot, Generics, BotAI, playerSession, partyThreat, leaderTargetId } = ctx;
        // A necromancer may need one quiet tick after the party kills a mob:
        // the corpse is no longer a live party threat, but it is still a valid
        // TARGET_CORPSE_MOB for the next summon cast.
        if (canAttemptPartyCorpseSummon(bot, partyThreat, leaderTargetId)) {
            const corpse = SummonerTactics.corpseTarget(session, bot);
            if (corpse) {
                session.currentTargetId = corpse.fetchId();
                bot.select({ id: corpse.fetchId() });
                BotAI.executeCombat(session, bot, corpse, Generics);
                recordRoleDecision(session, bot, 'summon_corpse', 'corpse_available', {
                    targetId: corpse.fetchId(),
                    skillId: session.lastCombatDecision?.skillId || null
                });
                return true;
            }
        }
        announceUnexpectedNpcAdd(session, bot, playerSession, partyThreat, leaderTargetId);
        const impairments = EffectStore.impairments(bot);

        if (impairments.disabled) {
            clearPendingSupportApproach(session, bot, { abortMove: true });
            session.currentTargetId = undefined;
            bot.unselect();
            recordRoleDecision(session, bot, 'disabled', 'debuff_control');
            return true;
        }
        Object.assign(ctx, { impairments });
        // With no party threat, a summoner heals its pet below its line (PetHealRule).
        if (!partyThreat && !bot.state?.fetchCasts?.() && SummonerTactics.healPetBetweenFights(session, bot, Generics)) {
            recordRoleDecision(session, bot, 'heal_summon', 'between_fights');
            return true;
        }
        return false;
    },

    // Stuck sampling, standing up, rooted hold, karma town wait, gatekeeper transit, catch-up teleport.
    tickTravel(ctx) {
        const { session, bot, role, leaderSeated, restFormationDistance, pulling, partyThreat, leaderTargetId, impairments } = ctx;
        const group = invoke('GameServer/Bot/AI/ClanCommandParty').groupFor(session);
        const player = group ? group.commander.actor : ctx.player;
        const distance = point(bot).distance(point(player));
        if (group && session.botStay) return false;
        const currentLoc = { x: bot.fetchLocX(), y: bot.fetchLocY() };
        if (!session.lastTickLoc) {
            session.lastTickLoc = currentLoc;
            session.stuckTicks = 0;
        }

        const movedDist = Math.sqrt((currentLoc.x - session.lastTickLoc.x) ** 2 + (currentLoc.y - session.lastTickLoc.y) ** 2);
        session.lastTickLoc = currentLoc;

        const isMoving = !!session.moveTimer || bot.state.fetchTowards();
        const now = Date.now();
        const canSampleStuck = now - Number(session.lastStuckSampleAt || 0) >= STUCK_SAMPLE_INTERVAL_MS;
        if (isMoving && movedDist < 10 && canSampleStuck) {
            session.stuckTicks = (session.stuckTicks || 0) + 1;
            session.lastStuckSampleAt = now;
        } else if (!isMoving || movedDist >= 10) {
            session.stuckTicks = 0;
            session.lastStuckSampleAt = now;
        }

        const seatedTooFar = leaderSeated
            ? distance > FOLLOW_RUN_DISTANCE && restFormationDistance > FOLLOW_FORMATION_TOLERANCE
            : distance > FOLLOW_RUN_DISTANCE;
        if (bot.state.fetchSeated() && (partyThreat || leaderTargetId || seatedTooFar)) {
            session.plan = 'following';
            session.currentTargetId = partyThreat?.actor?.fetchId?.() || leaderTargetId || undefined;
            standUp(session, bot);
            recordRoleDecision(
                session,
                bot,
                partyThreat || leaderTargetId ? assistActionForRole(role) : 'follow_leader',
                partyThreat ? 'party_under_attack' : (leaderTargetId ? assistReasonForRole(role) : 'leader_moved')
            );
            return true;
        }

        if (impairments.rooted && !partyThreat && !leaderTargetId && distance > FOLLOW_RUN_DISTANCE) {
            recordRoleDecision(session, bot, 'hold_position', 'rooted');
            return true;
        }

        // Pulling has its own route recovery.  Generic stuck samples must not
        // teleport the assigned puller: between geodata waypoints they can
        // report no movement even though its server-stepped route is healthy.
        // A truly distant puller may still use the normal catch-up teleport.
        const pullerTravelling = activeBotPullTravel(session, pulling);
        // Neither a gatekeeper transit nor a catch-up teleport takes a
        // companion with karma into a town; it waits where it is.
        const waitsOutsideTown = PartyCompanionService.staysOutOfTown(bot, loc(player));
        if (waitsOutsideTown && !partyThreat) {
            if (session.lastFollowMoveTarget) {
                bot.automation?.abortAll?.(bot);
                session.lastFollowMoveTarget = null;
            }
            recordRoleDecision(session, bot, 'hold_position', 'karma_keeps_out_of_town');
            return true;
        }
        if (!waitsOutsideTown && (session.companionTownTransit || distance > FOLLOW_TELEPORT_DISTANCE)) {
            const transit = CompanionTownTransit.tick(session, bot, player);
            if (transit.handled) {
                session.stuckTicks = 0;
                recordRoleDecision(session, bot, 'follow_leader', 'intertown_gatekeeper', {
                    sourceTown: transit.transit?.sourceTown || null,
                    targetTown: transit.transit?.targetTown || null
                });
                return true;
            }
        }
        const separatedInsideTown = distance > FOLLOW_TELEPORT_DISTANCE
            && CompanionTownTransit.sameTown(bot, player);
        if (!waitsOutsideTown && !pullerTravelling
            && (session.stuckTicks >= 3 || (distance > FOLLOW_TELEPORT_DISTANCE && !separatedInsideTown))) {
            session.stuckTicks = 0;
            recordRoleDecision(session, bot, 'follow_leader', distance > FOLLOW_TELEPORT_DISTANCE ? 'catch_up' : 'unstuck');
            const TeleportTo = invoke('GameServer/Actor/Generics/TeleportTo');
            if (TeleportTo && typeof TeleportTo === 'function') {
                const targetLoc = {
                    ...followTargetFor(session, player)
                };
                TeleportTo(session, bot, targetLoc);
                BotPartyChat.announce(session, {
                    priority: 'informational',
                    key: `catch-up:${bot.fetchId()}`,
                    templates: ['Caught up.']
                });
            }
            return true;
        }
        return false;
    },

    // A support approach or cast already in progress.
    tickPendingSupport(ctx) {
        const { session, bot, Generics, playerSession, pulling, partyThreat, leaderTargetId, personalSupportThreat } = ctx;
        if (session.pendingSupportApproach && (personalSupportThreat || ctx.impairments?.rooted ||
            pendingSupportShouldYield(session, bot, playerSession, pulling.puller?.actor, partyThreat || leaderTargetId))) {
            clearPendingSupportApproach(session, bot, { abortMove: true });
            BotSupportPlanner.cancelSupportCast(session, bot);
        }
        const pendingSupport = resumePendingSupportApproach(session, bot, Generics, playerSession);
        if (pendingSupport?.handled) {
            const pendingKind = String(pendingSupport.kind || '');
            const pendingIsBuff = pendingKind.startsWith('buff:');
            const supportAction = pendingSupport.action === 'cast'
                ? (pendingIsBuff ? 'cast_support' : 'cast_heal')
                : 'move_for_support';
            recordRoleDecision(
                session,
                bot,
                supportAction,
                pendingIsBuff ? pendingKind.slice('buff:'.length) : pendingSupport.kind,
                { targetId: pendingSupport.target.fetchId(), skillId: pendingSupport.skill.fetchSelfId() }
            );
            return true;
        }
        return false;
    },

    // A seated party is a safe chance to unload, rather than a reason to
    // postpone it forever. Combat, revival and pending support still win.
    tickInventoryCleanup(ctx) {
        const { session, bot, BotAI, playerSession, partyThreat, leaderTargetId, pulling } = ctx;
        if (partyThreat || ctx.personalSupportThreat || session.pvpDefense || leaderTargetId || pulling?.target || isBusy(bot)
            || ratio(bot.fetchHp?.(), bot.fetchMaxHp?.()) < 0.30) return false;
        if (!(bot.fetchMaxLoad?.() > 0) || !require('../../Population/SurvivalFloor').bagMarks(bot).weight) return false;
        if (weakestPartyVitals(playerSession, bot)?.hpRatio < CRITICAL_COMBAT_HP_RATIO) return false;
        const playerLeader = InventoryCleanup.playerLeader(session);
        const travel = invoke('GameServer/Bot/AI/BotTownTravel');
        if (playerLeader && (PartyCompanionService.regroupActive(playerLeader) || travel.inCombat(session, bot))) return false;
        const errand = InventoryCleanup.errand(session, bot, BotAI);
        if (!errand || !InventoryCleanup.canContinue(session, bot, errand.kind, errand.target)) return false;
        if (bot.state.fetchSeated?.()) standUp(session, bot);
        beginCompanionTownErrand(session, bot, playerSession, errand);
        // A player's companion is already in town and can go straight to the NPC.
        if (!playerLeader) travel.request(session, bot, BotAI, 'Unloading inventory.', {
            allowCompanion: true, preserveShoppingTarget: true, destinationTown: errand.town,
            announce: false
        });
        recordRoleDecision(session, bot, 'town_errand', errand.kind, { town: errand.target.town });
        return true;
    },

    // Vitals, return after support, resting with the leader, low HP/MP recovery.
    tickRest(ctx) {
        const { session, bot, BotAI, playerSession, player, distance, leaderSeated, restFormationDistance, pulling, partyThreat, leaderTargetId, personalSupportThreat } = ctx;
        const botVitals = {
            hpRatio: ratio(bot.fetchHp(), bot.fetchMaxHp()),
            mpRatio: ratio(bot.fetchMp(), bot.fetchMaxMp())
        };
        const leaderVitals = {
            hpRatio: ratio(player.fetchHp(), player.fetchMaxHp()),
            mpRatio: ratio(player.fetchMp(), player.fetchMaxMp())
        };
        const partyVitals = timedFollowingStage('partyVitals', () => (
            weakestPartyVitals(playerSession, bot) || leaderVitals
        ));
        const botRecovering = botVitals.hpRatio < 0.95 || (
            BotRoles.shouldRestForMana(bot) && botVitals.mpRatio < 0.95
        );

        if (session.returnToPartyAfterSupport && !personalSupportThreat && !isBusy(bot)) {
            session.returnToPartyAfterSupport = false;
            session.currentTargetId = undefined;
            bot.unselect();
            if (distance > FOLLOW_RUN_DISTANCE) {
                moveToFollowTarget(session, bot, player);
                recordRoleDecision(session, bot, 'follow_leader', 'return_after_support');
                return true;
            }
        }

        if (!partyThreat && !leaderTargetId && leaderSeated) {
            session.currentTargetId = undefined;
            bot.unselect();

            if (distance > FOLLOW_RUN_DISTANCE && restFormationDistance > FOLLOW_FORMATION_TOLERANCE) {
                standUp(session, bot);
                recordRoleDecision(session, bot, 'rest_with_leader', 'move_near_sitting_leader');
                if (!shouldKeepCurrentFollowMove(session, bot, player, distance)) {
                    moveToFollowTarget(session, bot, player);
                }
                return true;
            }

            session.lastFollowMoveTarget = null;
            sitDown(session, bot);
            recordRoleDecision(session, bot, 'rest_with_leader', 'leader_sitting');
            return true;
        }

        if (!partyThreat && !leaderTargetId && bot.state.fetchSeated() && !leaderSeated && !botRecovering) {
            standUp(session, bot);
            recordRoleDecision(session, bot, 'follow_leader', 'leader_stood_ready');
            return true;
        }

        const isActiveBotPuller = pulling.enabled &&
            pulling.puller?.kind === 'bot' &&
            pulling.puller?.session === session &&
            !!pulling.target;
        const hotTownRebuffVisit = HotTownRebuff.syncVisit(session, bot, BotAI);
        // The puller is the one companion who must not sit while a living
        // pull target is still assigned. A held incoming target is hidden
        // from the camp until delivery, so without this guard low HP could
        // make the puller sit in front of the mob it is returning with.
        const needsMpRecovery = BotRoles.shouldRestForMana(bot) && botVitals.mpRatio < 0.15;
        if (!partyThreat && !leaderTargetId && !isActiveBotPuller && (botVitals.hpRatio < 0.30 || needsMpRecovery)) {
            session.plan = 'resting';
            delete session.explicitRestOrder;
            session.currentTargetId = undefined;
            bot.unselect();
            sitDown(session, bot);
            recordRoleDecision(session, bot, botVitals.hpRatio < 0.30 ? 'recover_hp' : 'save_mp', 'resting');
            BotPartyChat.announce(session, {
                priority: 'coordination',
                key: `recover-sit:${bot.fetchId()}`,
                templates: ['HP/MP is low. Sitting to recover.', 'Need a short sit for HP/MP.']
            });
            return true;
        }
        Object.assign(ctx, { botVitals, partyVitals, hotTownRebuffVisit });
        return false;
    },

    // Newbie buff refresh, town errands, town-visit rebuff, support loadout.
    tickBuffsAndErrands(ctx) {
        const { session, bot, BotAI, playerSession, player, role, pulling, partyThreat, currentPartyAggroMonsters, leaderTargetId, hotTownRebuffVisit } = ctx;
        let acted = false;
        let keepRoleDecision = false;

        const buffsNeedRefresh = BotBuffs.needsNewbieRefresh(bot);
        if (buffsNeedRefresh) {
            const unsafeToRefresh = unsafeSupportMoment(bot, currentPartyAggroMonsters().length);
            const leaderInTown = townForCompanionErrand(player, BotAI)?.inTown === true;
            const nearbyGuide = !!HotTownRebuff.nearGuide(player, BotAI);

            if (unsafeToRefresh) {
                recordRoleDecision(session, bot, 'refresh_buffs', 'wait_for_safe_moment', {
                    missingBuffs: BotBuffs.missingNewbieBuffs(bot, BotBuffs.REFRESH_THRESHOLD_MS)
                });
                keepRoleDecision = true;
            } else if (!nearbyGuide || !leaderInTown) {
                recordRoleDecision(session, bot, 'refresh_buffs', 'wait_for_newbie_guide_town', {
                    missingBuffs: BotBuffs.missingNewbieBuffs(bot, BotBuffs.REFRESH_THRESHOLD_MS)
                });
                keepRoleDecision = true;
            } else if (!HotTownRebuff.tripGuide(session, bot, BotAI)) {
                const reason = Number(session.newbieGuideRetryAt || 0) > Date.now() ? 'wait_for_newbie_guide_route' : 'newbie_guide_out_of_reach';
                recordRoleDecision(session, bot, 'refresh_buffs', reason, {
                    retryAt: session.newbieGuideRetryAt
                });
                keepRoleDecision = true;
            } else {
                beginNewbieGuideVisit(session, bot, playerSession, role, hotTownRebuffVisit);
                recordRoleDecision(session, bot, 'refresh_buffs', 'newbie_blessing', {
                    missingBuffs: BotBuffs.missingNewbieBuffs(bot, BotBuffs.REFRESH_THRESHOLD_MS)
                });
                BotPartyChat.announce(session, {
                    priority: 'coordination',
                    key: `newbie-rebuff:${bot.fetchId()}`,
                    templates: [
                        'Minha bencao precisa renovar. Ja volto para o grupo.',
                        'Falhou na checagem de buff; vou pegar bencao nova antes de voltar.',
                        'My blessing needs a refresh. Rejoining right after.',
                        'Stopping by the guide for fresh buffs, then returning.',
                        'Buff check failed; getting a new blessing before I come back.'
                    ]
                });
                return true;
            }
        }

        if (!partyThreat && !leaderTargetId && !isBusy(bot)) {
            const errand = timedFollowingStage('townErrand', () => (
                companionTownErrand(session, bot, player, BotAI)
            ));
            if (errand && InventoryCleanup.canContinue(session, bot, errand.kind, errand.target)) {
                beginCompanionTownErrand(session, bot, playerSession, errand);
                recordRoleDecision(session, bot, 'town_errand', errand.kind, {
                    town: errand.target.town,
                    itemId: errand.itemId || null
                });
                return true;
            }
        }

        if (!partyThreat
            && !leaderTargetId
            && !isBusy(bot)
            && HotTownRebuff.needsVisit(session, hotTownRebuffVisit)
            && HotTownRebuff.tripGuide(session, bot, BotAI)) {
            beginNewbieGuideVisit(session, bot, playerSession, role, hotTownRebuffVisit);
            recordRoleDecision(session, bot, 'refresh_buffs', 'town_visit_rebuff', {
                town: hotTownRebuffVisit.town
            });
            BotPartyChat.announce(session, {
                priority: 'informational',
                key: `town-visit-rebuff:${bot.fetchId()}:${hotTownRebuffVisit.key}`,
                templates: [
                    'Corres da cidade feitos. Renovando minha bencao antes de sair.',
                    'Vou aproveitar a parada na cidade para renovar os buffs.',
                    'Passada rapida no guia e fecho os corres da cidade.',
                    'I will use this town stop to renew my buffs.',
                    'Quick visit to the guide, then town business is finished.'
                ]
            });
            return true;
        }

        if (!partyThreat && !leaderTargetId && !isBusy(bot)) {
            BotSupportPlanner.reconcileLoadout(partySupportMembers(playerSession,pulling.puller),
                PartyPulling.supportProviders(playerSession));
        }
        Object.assign(ctx, { acted, keepRoleDecision });
        return false;
    },

    // Support plan, heal choice, rebuff requests, party buffs, healer actions.
    tickSupportAndHealing(ctx) {
        const { session, bot, Generics, playerSession, player, role, partyRaid, pulling, partyThreat, currentPartyAggroMonsters, leaderTargetId, impairments, botVitals, partyVitals, personalSupportThreat } = ctx;
        let { acted, keepRoleDecision } = ctx;
        const queueSupport = (target, skill, kind, announcement = null) => {
            const result = queueSupportSkillOn(session, bot, Generics, target, skill, false, kind, announcement,
                { allowApproach: !personalSupportThreat && !impairments.rooted });
            acted = result !== 'blocked';
            if (!acted) {
                keepRoleDecision = true;
                recordRoleDecision(session, bot, 'hold_position', 'unsafe_support_approach', { targetId: target.fetchId() });
            }
            return result;
        };
        const supportBuffTarget = timedFollowingStage('supportPlan', () => (
            BotSupportPlanner.nextAction(
                bot,
                partySupportMembers(playerSession, pulling.puller),
                PartyPulling.supportProviders(playerSession)
            )
        ));
        const healingSupport = canHealParty(bot, playerSession);
        const learnedHeals = healingSupport ? BotSkillCapabilities.healSkills(bot) : [];
        const selectHeal = (options = {}) => healingSupport
            ? BotSkillCapabilities.selectHealSkill(bot, { fallbackGroup: role === 'buffer', ...options }) : null;
        const rechargeSkill = role === 'healer' ? BotSkillCapabilities.manaRechargeSkill(bot) : null;
        const reachablePatient = target => {
            if (!learnedHeals.length) return true;
            return [selectHeal({ target }), selectHeal({ target, emergency: true })].filter(Boolean).some(skill => {
                const range = supportCastRange(skill);
                return point(bot).distance(point(target)) <= range ||
                    (!personalSupportThreat && !impairments.rooted &&
                        !!PartySupportMovement.supportDestination(session, bot, target, Math.max(0, range)));
            });
        };
        const woundedPartyMember = healingSupport
            ? weakestPartyMember(playerSession, bot, pulling.puller?.actor, 900, reachablePatient)
            : null;
        const woundedPartyCount = healingSupport
            ? partyMembersInSupportRange(playerSession, bot).filter((entry) => entry.hpRatio < 0.70).length
            : 0;
        const healTarget = woundedPartyMember?.actor || bot;
        const routineHealCandidate = selectHeal({ target: healTarget });
        const emergencyHealCandidate = selectHeal({ target: healTarget, emergency: true });
        const groupHealCandidate = healingSupport && woundedPartyCount >= 2
            ? selectHeal({ group: true, target: healTarget })
            : null;
        const canAffordHeal = (skill) => !!skill && bot.canUseSkill?.(skill) !== false && bot.fetchMp() >= skill.fetchConsumedMp();
        const routineHealSkill = routineHealCandidate;
        const emergencyHealSkill = canAffordHeal(emergencyHealCandidate) ? emergencyHealCandidate : routineHealCandidate;
        const groupHealSkill = canAffordHeal(groupHealCandidate) ? groupHealCandidate : null;
        const topOffHealSkill = groupHealSkill || routineHealSkill;
        const selfHealCandidate = selectHeal({ target: bot, emergency: true });
        const selfHealSkill = canAffordHeal(selfHealCandidate) ? selfHealCandidate : selectHeal({ target: bot });
        const safeManaPartyMember = role === 'healer' && rechargeSkill && !partyThreat && !leaderTargetId
            ? lowestManaPartyMember(playerSession, bot, pulling.puller?.actor)
            : null;
        // A tank remains a standing melee role, but below one taunt reserve it
        // becomes an emergency Recharge target even during combat. Healing
        // still wins below, and a healer currently being attacked will not
        // stop to channel mana into somebody else.
        const emergencyTankManaMember = role === 'healer' && rechargeSkill && partyThreat &&
            Number(partyThreat.targetId || 0) !== Number(bot.fetchId())
            ? lowestManaPartyMember(playerSession, bot, pulling.puller?.actor, 900, { emergencyTankOnly: true })
            : null;
        const manaPartyMember = emergencyTankManaMember || safeManaPartyMember;
        // Healing is the healer's first obligation.  Do not queue a regular
        // party buff and then overwrite it with a heal in this same AI tick.
        const healerNeedsAction = healingSupport && (
            (woundedPartyMember?.hpRatio < 0.45 && canAffordHeal(emergencyHealSkill)) ||
            (woundedPartyMember?.hpRatio < 0.70 && botVitals.mpRatio >= 0.35 && canAffordHeal(topOffHealSkill)) ||
            (botVitals.hpRatio < 0.55 && botVitals.mpRatio >= 0.25 && canAffordHeal(selfHealSkill))
        );
        if (healerNeedsAction && !impairments.silenced) {
            preemptForPriorityHeal(session, bot);
        }
        const healerCanCast = (skill) => canAffordHeal(skill) && !isBusy(bot) && !impairments.silenced;
        const urgentPartyMusicRefresh = canRefreshPartyMusicDuringCombat(
            bot,
            supportBuffTarget,
            partyThreat,
            partyRaid,
            botVitals,
            partyVitals,
            healerNeedsAction
        );
        const rebuff = !partyThreat && !leaderTargetId && !isBusy(bot)
            ? timedFollowingStage('rebuffPlan', () => (
                BotSupportPlanner.rebuffRequest(bot, PartyPulling.supportProviders(playerSession))
            ))
            : null;
        if (rebuff && rebuff.provider !== bot && Date.now() - (session.lastRebuffRequestAt || 0) > 90000) {
            session.lastRebuffRequestAt = Date.now();
            BotPartyChat.announce(session, {
                priority: 'coordination',
                key: `rebuff:${rebuff.provider.fetchId()}:${rebuff.skill.fetchSelfId()}`,
                templates: [
                    `${rebuff.provider.fetchName()}, refresh ${rebuff.skill.fetchName()} when safe?`,
                    `${rebuff.provider.fetchName()}, ${rebuff.skill.fetchName()} is fading.`
                ]
            });
        }
        // A routine buff must never take the action slot from a live party
        // threat. The target may be a social ranged add that is still outside
        // melee range, so let the normal defence branch react immediately.
        const supportBuffAllowed = (!partyThreat && !leaderTargetId) || urgentPartyMusicRefresh;
        if (!acted && supportBuffAllowed && supportBuffTarget && !healerNeedsAction) {
            const activeMobs = currentPartyAggroMonsters().length;
            if (unsafeSupportMoment(bot, activeMobs) && !urgentPartyMusicRefresh) {
                recordRoleDecision(session, bot, 'buff_party', 'wait_for_safe_moment', {
                    buff: supportBuffTarget.effect,
                    targetId: supportBuffTarget.target.fetchId(),
                    activeMobs
                });
                keepRoleDecision = true;
            } else if (impairments.silenced) {
                recordRoleDecision(session, bot, 'save_mp', 'silenced');
                keepRoleDecision = true;
            } else if (bot.fetchMp() < supportBuffTarget.skill.fetchConsumedMp() || botVitals.mpRatio < 0.35) {
                recordRoleDecision(session, bot, 'save_mp', 'low_mp_for_buff', {
                    buff: supportBuffTarget.effect,
                    targetId: supportBuffTarget.target.fetchId()
                });
                keepRoleDecision = true;
            } else {
                acted = true;
                // A queued cast is not a buff yet. The reservation begins in
                // Attack.remoteHit once the native cast has actually started.
                BotSupportPlanner.queueSupportCast(session, supportBuffTarget);
                const supportResult = queueSupport(
                    supportBuffTarget.target,
                    supportBuffTarget.skill,
                    `buff:${supportBuffTarget.effect}`
                );
                returnToPartyAfterSupport(session, bot, player, supportBuffTarget.target);
                if (acted) recordRoleDecision(session, bot, supportResult === 'cast' ? 'cast_support' : 'move_for_support', supportBuffTarget.effect, {
                    buff: supportBuffTarget.effect,
                    skillId: supportBuffTarget.skill.fetchSelfId(),
                    targetId: supportBuffTarget.target.fetchId()
                });
            }
        }

        if (!acted && healingSupport) {
            if (woundedPartyMember?.hpRatio < 0.45 && healerCanCast(emergencyHealSkill)) {
                acted = true;
                recordRoleDecision(session, bot, 'heal_party', 'emergency_heal', { targetId: woundedPartyMember.actor.fetchId() });
                queueSupport(woundedPartyMember.actor, emergencyHealSkill, 'emergency_heal', { kind: 'emergency_heal' });
                returnToPartyAfterSupport(session, bot, player, woundedPartyMember.actor);
            } else if (botVitals.hpRatio < 0.55 && botVitals.mpRatio >= 0.25 && healerCanCast(selfHealSkill)) {
                acted = true;
                recordRoleDecision(session, bot, 'heal_self', 'self_preservation', { targetId: bot.fetchId() });
                queueSupport(bot, selfHealSkill, 'self_preservation');
            } else if (woundedPartyMember?.hpRatio < 0.70 && botVitals.mpRatio >= 0.35 && healerCanCast(topOffHealSkill)) {
                acted = true;
                const groupHeal = topOffHealSkill?.fetchTargetKind?.() === 'party';
                recordRoleDecision(session, bot, 'heal_party', groupHeal ? 'group_heal' : 'top_off', {
                    targetId: woundedPartyMember.actor.fetchId(),
                    woundedCount: woundedPartyCount,
                    skillId: topOffHealSkill.fetchSelfId()
                });
                queueSupport(woundedPartyMember.actor, topOffHealSkill, groupHeal ? 'group_heal' : 'top_off');
                returnToPartyAfterSupport(session, bot, player, woundedPartyMember.actor);
            } else if (woundedPartyMember?.hpRatio < 0.70 && botVitals.mpRatio < 0.35) {
                recordRoleDecision(session, bot, 'save_mp', woundedPartyMember.hpRatio < 0.45 ? 'low_mp_emergency' : 'party_not_critical');
                if (woundedPartyMember.hpRatio < 0.45 && emergencyHealSkill && bot.fetchMp() < emergencyHealSkill.fetchConsumedMp()) {
                    BotPartyChat.announceHealManaShortage(session, woundedPartyMember.actor);
                }
                keepRoleDecision = true;
            } else if (impairments.silenced) {
                recordRoleDecision(session, bot, 'save_mp', 'silenced');
                keepRoleDecision = true;
            } else if (botVitals.mpRatio < 0.25) {
                recordRoleDecision(session, bot, 'save_mp', 'low_mp');
                keepRoleDecision = true;
            } else if (manaPartyMember && rechargeSkill && !isBusy(bot) && !healerNeedsAction) {
                acted = true;
                recordRoleDecision(session, bot, 'recharge_party', emergencyTankManaMember ? 'restore_tank_control_mp' : 'restore_mp', {
                    targetId: manaPartyMember.actor.fetchId(),
                    skillId: rechargeSkill.fetchSelfId()
                });
                queueSupport(manaPartyMember.actor, rechargeSkill, 'restore_mp');
                if (acted) markPartyRecharge(playerSession, bot, manaPartyMember.actor, rechargeSkill);
                returnToPartyAfterSupport(session, bot, player, manaPartyMember.actor);
            } else if (!routineHealSkill && !emergencyHealSkill && !groupHealSkill && woundedPartyMember?.hpRatio < 0.70) {
                recordRoleDecision(session, bot, 'cannot_heal', 'no_learned_heal');
                keepRoleDecision = true;
            }
        }
        Object.assign(ctx, { acted, keepRoleDecision });
        return false;
    },

    // Self-defense, critical-HP retreat, the bot puller, holding for a pull.
    tickDefenseAndPull(ctx) {
        const { session, bot, Generics, BotAI, playerSession, player, role, partySettings, personalSupportThreat, rawThreatOnlyTargetsTravellingPuller, impairments, botVitals, acted } = ctx;
        let { pulling, partyThreat, keepRoleDecision } = ctx;
        // Defense is distinct from routine assist and does not wait for 25% HP.
        // Priority heals above keep their action; an in-flight cast must finish
        // before control/escape, and repeated hit wakeups keep the escape route.
        if (!acted && personalSupportThreat && !bot.state.fetchCasts()) {
            const control = !isBusy(bot) ? PartyClassTactics.supportCrowdControl(bot, [personalSupportThreat], {
                selfDefense: true
            }) : null;
            if (control) {
                recordRoleDecision(session, bot, 'defend_self', control.reason, {
                    targetId: personalSupportThreat.fetchId(), skillId: control.skill.fetchSelfId()
                });
                castSkillOn(session, bot, Generics, control.target, control.skill, true);
                return true;
            }
            if (BotRoles.usesCasterWeaponCombat(bot) || !supportCanMeleeAssist(bot, role)) {
                const moved = retreatFromThreat(session, bot, personalSupportThreat, player, impairments.rooted);
                recordRoleDecision(session, bot, 'retreat', impairments.rooted ? 'personal_attack_rooted' : 'personal_attack_no_control', {
                    targetId: personalSupportThreat.fetchId(), moved
                });
                return true;
            }
        }

        // A critically wounded non-tank should stop feeding the attacker.
        // Healers still get the first action slot for a self/party heal; once
        // no cast was started, every fragile role creates distance while
        // remaining attached to the party lifecycle.
        if (
            !acted &&
            partyThreat?.actor &&
            role !== 'tank' &&
            botVitals.hpRatio < CRITICAL_COMBAT_HP_RATIO &&
            !bot.state.fetchCasts()
        ) {
            const moved = retreatFromThreat(session, bot, partyThreat.actor, player, impairments.rooted);
            recordRoleDecision(session, bot, 'retreat', impairments.rooted ? 'critical_hp_rooted' : 'critical_hp_under_attack', {
                targetId: partyThreat.actor.fetchId(),
                hpRatio: botVitals.hpRatio,
                moved
            });
            return true;
        }

        if (!acted && pulling.enabled && pulling.puller?.session === session && pulling.puller.kind === 'bot') {
            const pullAction = PartyPulling.tickBotPuller(session, bot, playerSession, partySettings, Generics, BotAI);
            pulling = PartyPulling.current(playerSession, partySettings);
            if (pullAction.handled) {
                const reason = pullAction.paused || pullAction.action || (pullAction.idle ? 'no_targets' : 'waiting');
                recordRoleDecision(session, bot, 'party_pull', reason, {
                    targetId: pullAction.target?.fetchId?.() || pulling.target?.fetchId?.() || null,
                    phase: pulling.phase || null
                });
                // An active party fight pauses selection/delivery of the next
                // pull, but it must not consume the puller's combat tick. Let
                // the ordinary party-assist branch below attack the current
                // threat; once the last mob dies, tickBotPuller resumes from
                // the preserved pull configuration on the following tick.
                if (pullAction.paused !== 'party_under_attack' || !partyThreat?.actor) return true;
            }
        }

        // Once the puller has returned to the formation, it can keep the
        // incoming mob occupied as soon as that mob reaches the puller's own
        // attack range. Do not wait for the stricter leader-centred camp
        // radius: it creates a visible idle window and can leave the tank
        // taking hits without responding.
        const pullerCanFightHeldTarget = !partyThreat &&
            pulling.enabled &&
            pulling.target &&
            pulling.puller?.kind === 'bot' &&
            pulling.puller?.session === session &&
            PartyPulling.actorCanEngage(bot, pulling.target);
        if (pullerCanFightHeldTarget) {
            partyThreat = {
                type: 'npc',
                actor: pulling.target,
                targetId: bot.fetchId(),
                source: 'party_pull_puller_range'
            };
        }

        const waitingForPullAtOwnRange = pulling.enabled && pulling.target && (
            pulling.puller?.session !== session && (
                !pulling.engageable || !PartyPulling.actorCanEngage(bot, pulling.target)
            )
        );
        if (!acted && waitingForPullAtOwnRange) {
            session.currentTargetId = undefined;
            bot.unselect();
            // The marked mob is intentionally not a chase target.  Keep the
            // formation on the player, then join combat once this particular
            // companion can strike from its own position.
            recordRoleDecision(session, bot, 'follow_leader', rawThreatOnlyTargetsTravellingPuller ? 'hold_for_pull' : (pulling.paused || 'hold_for_pull'), {
                targetId: pulling.target.fetchId(),
                pullerId: pulling.puller?.actor?.fetchId?.() || null
            });
            keepRoleDecision = true;
        }
        Object.assign(ctx, { pulling, partyThreat, keepRoleDecision });
        return false;
    },

    // Class tactics, tank protection and auto pull, crowd control, combat loot window, party assist.
    tickCombat(ctx) {
        const { session, bot, Generics, BotAI, playerSession, player, role, partySettings, partyRaid, pulling, partyThreat, currentPartyAggroMonsters, leaderTargetId, botVitals, partyVitals } = ctx;
        let { acted, keepRoleDecision } = ctx;
        const activePartyThreats = partyThreat ? currentPartyAggroMonsters() : [];
        const protectedSession = partyThreat?.targetId
            ? PartyAwareness.partySessions(playerSession).find((memberSession) => (
                Number(memberSession.actor?.fetchId?.()) === Number(partyThreat.targetId)
            ))
            : null;
        const protectedRole = protectedSession === playerSession
            ? 'leader'
            : (protectedSession?.actor ? BotRoles.inferRole(protectedSession.actor) : null);

        if (!acted && partyThreat?.actor && !isBusy(bot)) {
            const selfTactic = PartyClassTactics.selfAction(bot, {
                role,
                activeMobs: activePartyThreats.length,
                target: partyThreat.actor
            });
            if (selfTactic) {
                acted = true;
                recordRoleDecision(session, bot, 'class_tactic', selfTactic.reason, {
                    skillId: selfTactic.skill.fetchSelfId(),
                    activeMobs: activePartyThreats.length
                });
                castSkillOn(session, bot, Generics, selfTactic.target, selfTactic.skill, false);
            }
        }

        if (!acted && role === 'tank' && activePartyThreats.length >= 2 && !isBusy(bot)) {
            const Commands = invoke('GameServer/Bot/AI/ClanCommandParty');
            const massAggro = activePartyThreats.every(target => Commands.canTaunt(session, target))
                ? PartyClassTactics.tankMassAggroAction(bot, activePartyThreats) : null;
            if (massAggro) {
                acted = true;
                recordRoleDecision(session, bot, 'protect_party', massAggro.reason, {
                    skillId: massAggro.skill.fetchSelfId(),
                    activeMobs: activePartyThreats.length
                });
                castSkillOn(session, bot, Generics, massAggro.target, massAggro.skill, true);
            }
        }

        if (!acted && role === 'tank') {
            const nearbyNpcs = World.fetchNpcsInRadius(bot.fetchLocX(), bot.fetchLocY(), 800);
            const monsterToAggro = partyThreat?.type === 'npc'
                ? partyThreat.actor
                : nearbyNpcs.find((npc) => !BotRaidSafety.isProtectedRaidEntity(npc) && npc.fetchAttackable() && !npc.isDead() && partyActorIds(playerSession).has(npc.fetchDestId()));

            // Aggression is a transfer tool: use it only to take a mob away
            // from another party member. Once it is already attacking this
            // tank (including after a normal pull hit), continue normal combat
            // below instead of repeatedly taunting the same target.
            if (monsterToAggro && Number(monsterToAggro.fetchDestId?.()) !== Number(bot.fetchId())
                && invoke('GameServer/Bot/AI/ClanCommandParty').canTaunt(session, monsterToAggro)) {
                const skill = BotSkillCapabilities.aggressionSkill(bot);
                if (skill && bot.fetchMp() >= skill.fetchConsumedMp() && !isBusy(bot) && canAttemptAggression(session, monsterToAggro)) {
                    acted = true;
                    rememberAggressionAttempt(session, monsterToAggro);
                    recordRoleDecision(session, bot, 'protect_leader', 'leader_targeted', { targetId: monsterToAggro.fetchId() });
                    castSkillOn(session, bot, Generics, monsterToAggro, skill, true);
                } else if (!skill) {
                    recordRoleDecision(session, bot, 'cannot_taunt', 'no_learned_aggression');
                    keepRoleDecision = true;
                } else if (botVitals.mpRatio < 0.25) {
                    recordRoleDecision(session, bot, 'save_mp', 'low_mp_for_taunt');
                    keepRoleDecision = true;
                }
            }
        }

        if (!acted && role === 'tank' && activePartyThreats.length > 0 && !isBusy(bot)) {
            const stun = PartyClassTactics.tankStunAction(bot, activePartyThreats, { protectedRole });
            if (stun) {
                acted = true;
                recordRoleDecision(session, bot, 'protect_party', stun.reason, {
                    targetId: stun.target.fetchId(),
                    skillId: stun.skill.fetchSelfId()
                });
                castSkillOn(session, bot, Generics, stun.target, stun.skill, true);
            }
        }

        // Auto mode retains the lightweight tank fallback. Explicit Off is a
        // quiet order, not an "avoid overpull" failure that should overwrite
        // the tank's otherwise useful role status every tick.
        if (!acted && !partyRaid && role === 'tank' && partySettings.pullMode === 'auto') {
            const activeMobs = currentPartyAggroMonsters().length;
            const blockReason = PartyPulling.hasDeadPartyMember(playerSession)
                ? 'party_revival'
                : pullBlockReason(session, botVitals, partyVitals, activeMobs, partySettings);

            if (blockReason) {
                recordRoleDecision(session, bot, 'avoid_overpull', blockReason, { activeMobs });
                keepRoleDecision = true;
            } else {
                const nearbyNpcs = World.fetchNpcsInRadius(player.fetchLocX(), player.fetchLocY(), 900);
                const candidates = nearbyNpcs.filter(npc => !BotRaidSafety.isProtectedRaidEntity(npc)
                    && npc.fetchAttackable() && !npc.isDead() && npc.fetchDestId() === undefined
                    && point(bot).distance(point(npc)) < 900)
                    .sort((a, b) => point(bot).distance(point(a)) - point(bot).distance(point(b)));
                const targetMonster = HuntingVisibility.select(session, 'autoPull', bot, candidates).candidate;

                if (targetMonster) {
                    if (!isBusy(bot)) {
                        acted = true;
                        recordRoleDecision(session, bot, 'pull_target', 'safe_pull', {
                            targetId: targetMonster.fetchId(),
                            activeMobs
                        });
                        BotAI.executeCombat(session, bot, targetMonster, Generics, { basicAttackOnly: true });
                    }
                }
            }
        }

        if (!acted && partyThreat?.actor && ['mage', 'healer', 'buffer'].includes(role) && !isBusy(bot)) {
            const crowdControl = PartyClassTactics.supportCrowdControl(bot, activePartyThreats, {
                primaryTargetId: pulling.target?.fetchId?.() || leaderTargetId
            });
            if (crowdControl) {
                acted = true;
                recordRoleDecision(session, bot, 'control_add', crowdControl.reason, {
                    targetId: crowdControl.target.fetchId(),
                    skillId: crowdControl.skill.fetchSelfId()
                });
                castSkillOn(session, bot, Generics, crowdControl.target, crowdControl.skill, true);
            }
        }

        if (!acted && !isBusy(bot) && invoke('GameServer/Bot/AI/PartyCombatLootPolicy').idleSupport(bot)) {
            session.partyCombatLootReadyAt = Date.now();
        }

        if (!acted && partyThreat?.actor) {
            const target = partyThreat.actor;
            const targetId = target.fetchId();
            const holdSupportLine = !supportCanMeleeAssist(bot, role);
            if (holdSupportLine) {
                stopSupportMelee(bot);
                session.currentTargetId = undefined;
                bot.unselect();
                recordRoleDecision(session, bot, BotRoles.partyRoleStance(role), 'hold_support_line', {
                    targetId,
                    targetType: partyThreat.type,
                    protectedId: partyThreat.targetId,
                    threatSource: partyThreat.source || 'targeting_party'
                });
                keepRoleDecision = true;
            } else {
                // A combat-capable party member owns this tick even if an
                // earlier hit, cast, or approach is still in flight. Support
                // roles that hold their line may still follow the formation.
                acted = true;
            }

            if (!holdSupportLine && session.currentTargetId !== targetId) {
                if (bot.state?.fetchTowards?.() && !bot.state?.fetchHits?.() && !bot.state?.fetchCasts?.()) {
                    bot.automation?.abortAll?.(bot);
                }
                session.currentTargetId = targetId;
                bot.select({ id: targetId });
                recordRoleDecision(session, bot, assistActionForRole(role), 'party_under_attack', {
                    targetId,
                    targetType: partyThreat.type,
                    protectedId: partyThreat.targetId,
                    threatSource: partyThreat.source || 'targeting_party'
                });
            }

            if (!holdSupportLine) {
                invoke('GameServer/Bot/AI/PartyArcherCombatPolicy').reviewAutoAttack(session, bot, target, {
                    pvp: partyThreat.type === 'player'
                });
            }
            if (!holdSupportLine && !isBusy(bot)) {
                const basicAttackOnly = role === 'healer' || role === 'buffer';
                if (partyThreat.type === 'player') {
                    BotAI.executePvPCombat(session, bot, target, Generics, { basicAttackOnly });
                } else {
                    BotAI.executeCombat(session, bot, target, Generics, {
                        basicAttackOnly,
                        playerPartyRaidLeaderSession: playerSession
                    });
                }
            }
        }
        Object.assign(ctx, { acted, keepRoleDecision });
    },

    // Pending sweep loot and the leader's selected target (asynchronous lookup).
    tickLootAndLeaderTarget(ctx) {
        const { session, bot, Generics, BotAI, playerSession, player, role, partyThreat, leaderTargetId } = ctx;
        let { acted, keepRoleDecision } = ctx;
        if (!acted && !partyThreat
            && invoke('GameServer/Bot/AI/PendingSweep').tick(session, bot, Generics, BotAI)) acted = true;

        if (!acted) {
            const playerTargetId = leaderTargetId;
            if (playerTargetId && playerTargetId !== bot.fetchId() && playerTargetId !== player.fetchId() && !supportCanMeleeAssist(bot, role)) {
                stopSupportMelee(bot);
                session.currentTargetId = undefined;
                bot.unselect();
                recordRoleDecision(session, bot, BotRoles.partyRoleStance(role), 'hold_support_line', { targetId: playerTargetId });
                keepRoleDecision = true;
            } else if (playerTargetId && playerTargetId !== bot.fetchId() && playerTargetId !== player.fetchId()) {
                acted = true;
                World.fetchUser(playerTargetId).then((user) => {
                    if (PartyAwareness.leaderCombatTargetId(playerSession, { allowPlayerRaid: true }) !== playerTargetId) return;
                    if (session.currentTargetId && session.currentTargetId !== playerTargetId) return;
                    const targetIsTeammate = PartyAwareness.isCombatAlly(playerSession, user);

                    const isAttackablePvPTarget = user.fetchKarma() > 0 || user.fetchPvpFlag() > 0;

                    if (!user.state.fetchDead() && !targetIsTeammate && isAttackablePvPTarget) {
                        if (session.botStay && session.stayLocation) {
                            const stayDist = new SpeckMath.Point3D(session.stayLocation.locX, session.stayLocation.locY, session.stayLocation.locZ)
                                .distance(new SpeckMath.Point3D(user.fetchLocX(), user.fetchLocY(), user.fetchLocZ()));
                            if (stayDist > 900) {
                                recordRoleDecision(session, bot, 'hold_position', 'stay_order');
                                return;
                            }
                        }

                        if (session.currentTargetId !== playerTargetId) {
                            session.currentTargetId = playerTargetId;
                            bot.select({ id: playerTargetId });
                            recordRoleDecision(session, bot, assistActionForRole(role), 'pvp_target', { targetId: playerTargetId });
                        }
                        invoke('GameServer/Bot/AI/PartyArcherCombatPolicy').reviewAutoAttack(session, bot, user, { pvp: true });
                        if (isBusy(bot) || !supportCanMeleeAssist(bot, role)) {
                            return;
                        }
                        BotAI.executePvPCombat(session, bot, user, Generics, {
                            basicAttackOnly: role === 'healer' || role === 'buffer'
                        });
                    } else {
                        if (session.currentTargetId === playerTargetId) {
                            session.currentTargetId = undefined;
                            bot.unselect();
                        }
                    }
                }).catch(() => {
                    World.fetchNpc(playerTargetId).then((npc) => {
                        if (PartyAwareness.leaderCombatTargetId(playerSession, { allowPlayerRaid: true }) !== playerTargetId) return;
                        if (session.currentTargetId && session.currentTargetId !== playerTargetId) return;
                        if ((!BotRaidSafety.isProtectedRaidEntity(npc) || BotRaidSafety.canEngagePlayerPartyRaid(session, npc, playerSession)) && npc.fetchAttackable() && !npc.isDead()) {
                            if (session.botStay && session.stayLocation) {
                                const stayDist = new SpeckMath.Point3D(session.stayLocation.locX, session.stayLocation.locY, session.stayLocation.locZ)
                                    .distance(new SpeckMath.Point3D(npc.fetchLocX(), npc.fetchLocY(), npc.fetchLocZ()));
                                if (stayDist > 900) {
                                    recordRoleDecision(session, bot, 'hold_position', 'stay_order');
                                    return;
                                }
                            }

                            if (session.currentTargetId !== playerTargetId) {
                                session.currentTargetId = playerTargetId;
                                bot.select({ id: playerTargetId });
                                recordRoleDecision(session, bot, assistActionForRole(role), assistReasonForRole(role), { targetId: playerTargetId });
                            }
                            invoke('GameServer/Bot/AI/PartyArcherCombatPolicy').reviewAutoAttack(session, bot, npc);
                            if (isBusy(bot) || !supportCanMeleeAssist(bot, role)) {
                                return;
                            }
                            BotAI.executeCombat(session, bot, npc, Generics, {
                                basicAttackOnly: role === 'healer' || role === 'buffer',
                                playerPartyRaidLeaderSession: playerSession
                            });
                        } else {
                            if (session.currentTargetId === playerTargetId) {
                                session.currentTargetId = undefined;
                                bot.unselect();
                            }
                        }
                    }).catch(() => {
                        if (session.currentTargetId === playerTargetId) {
                            session.currentTargetId = undefined;
                            bot.unselect();
                        }
                    });
                });
            } else {
                session.currentTargetId = undefined;
                bot.unselect();
            }
        }
        Object.assign(ctx, { acted, keepRoleDecision });
    },

    // Stay order, keeping formation range, ready stance.
    tickIdleFollow(ctx) {
        if (invoke('GameServer/Bot/AI/ClanCommandParty').followLeader(ctx.session, ctx.bot)) return true;
        const { session, bot, playerSession, player, role, distance, impairments, acted, keepRoleDecision } = ctx;
        if (!session.currentTargetId && !acted) {
            if (session.botStay && session.stayLocation) {
                session.lastFollowMoveTarget = null;
                const stayDist = point(bot).distance(new SpeckMath.Point3D(
                    session.stayLocation.locX,
                    session.stayLocation.locY,
                    session.stayLocation.locZ
                ));
                if (!keepRoleDecision) {
                    recordRoleDecision(session, bot, 'hold_position', 'stay_order');
                }
                if (stayDist > 100) {
                    bot.moveTo({
                        from: { locX: bot.fetchLocX(), locY: bot.fetchLocY(), locZ: bot.fetchLocZ() },
                        to: { locX: session.stayLocation.locX, locY: session.stayLocation.locY, locZ: session.stayLocation.locZ }
                    });
                }
            } else if (distance > FOLLOW_RUN_DISTANCE || PartyCompanionService.regroupActive(playerSession)) {
                if (impairments.rooted) {
                    recordRoleDecision(session, bot, 'hold_position', 'rooted');
                    return true;
                }
                if (!keepRoleDecision) {
                    recordRoleDecision(session, bot, 'follow_leader', 'keep_range');
                }
                const followTarget = followTargetFor(session, player);
                if (distance2d(loc(bot), followTarget) <= FOLLOW_FORMATION_TOLERANCE) {
                    stopFollowMove(session, bot);
                } else {
                    if (shouldKeepCurrentFollowMove(session, bot, player, distance)) {
                        session.lastFollowMoveHeldAt = Date.now();
                        return true;
                    }
                    moveToFollowTarget(session, bot, player);
                }
            } else {
                if (session.lastFollowMoveTarget && ['healer', 'buffer'].includes(role) &&
                    shouldKeepCurrentFollowMove(session, bot, player, distance)) {
                    session.lastFollowMoveHeldAt = Date.now();
                    return true;
                }
                stopFollowMove(session, bot);
                if (!keepRoleDecision) {
                    recordRoleDecision(session, bot, BotRoles.partyRoleStance(role), 'ready');
                }
            }
        }
    }
};

module.exports = FollowingState;
